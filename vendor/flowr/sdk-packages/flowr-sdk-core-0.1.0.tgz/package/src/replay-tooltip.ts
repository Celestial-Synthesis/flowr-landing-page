/**
 * Anchored highlight + tooltip rendered inside a Shadow DOM root.
 *
 * Draws a fixed-position overlay that highlights the target element and
 * a tooltip card next to it. Auto-flips above/below based on viewport.
 *
 * Visual surface (`.wr-highlight`, `.wr-tooltip`, `.wr-tooltip.is-above`)
 * is sourced from the shared `wr-styles` module so the extension and the
 * SDK cannot drift apart visually.
 */

import { WR_HIGHLIGHT_AND_TOOLTIP_CSS } from "./wr-styles";

export type AnchoredTooltipOptions = {
  targetRect: { top: number; left: number; width: number; height: number };
  targetElement?: Element | null;
  title: string;
  body: string;
  actionLabel: string | null;
  onAction?(): void;
};

export type AnchoredTooltipHandle = {
  destroy(): void;
};

export type ReplayOverlayMessageHandle = {
  destroy(): void;
  setMessage(message: string, placement?: ReplayOverlayPlacement): void;
};

export type ReplayOverlayPlacement = "top" | "bottom";

const SDK_OVERLAY_CSS = `
  .flowr-overlay-host {
    position: fixed; inset: 0;
    pointer-events: none;
    z-index: 2147483647;
  }
  .wr-highlight {
    /* Force visible inside the SDK overlay (the extension fades in via JS). */
    opacity: 1;
    transition: top .15s ease, left .15s ease, width .15s ease, height .15s ease;
  }
  .wr-tooltip {
    pointer-events: auto;
  }
  .wr-tooltip .t-title {
    font-size: 11px;
    font-weight: 700;
    color: #8d2e3a;
    text-transform: uppercase;
    letter-spacing: .04em;
    margin-bottom: 4px;
    text-align: center;
  }
  .wr-tooltip .t-body {
    font-size: 13px;
    color: #5a1c24;
    line-height: 1.4;
  }
  .wr-tooltip .t-action {
    margin: 10px auto 0;
    padding: 8px 10px;
    display: flex;
    width: fit-content;
    max-width: 100%;
    align-items: center;
    justify-content: center;
    border: none;
    border-radius: 8px;
    background: #8d2e3a;
    color: #ffffff;
    font-weight: 600;
    font-size: 13px;
    text-align: center;
    cursor: pointer;
    font-family: inherit;
  }
  .wr-tooltip .t-action:active {
    transform: scale(0.95);
  }
  .flowr-replay-overlay {
    position: fixed;
    top: 16px;
    left: 50%;
    transform: translateX(-50%);
    max-width: min(360px, calc(100vw - 24px));
    padding: 12px 14px;
    border-radius: 12px;
    background: rgba(90, 28, 36, 0.94);
    color: #ffffff;
    box-shadow: 0 12px 32px rgba(10, 10, 10, 0.3);
    font: 13px "Segoe UI", system-ui, -apple-system, Roboto, sans-serif;
    line-height: 1.45;
    text-align: center;
  }
  .flowr-replay-overlay[data-placement="bottom"] {
    top: auto;
    bottom: 16px;
  }
`;

const STYLE = `${WR_HIGHLIGHT_AND_TOOLTIP_CSS}\n${SDK_OVERLAY_CSS}`;

const STYLE_ID = "flowr-anchored-tooltip-style";

const ensureStyle = (root: ShadowRoot): void => {
  if (root.getElementById(STYLE_ID)) return;
  const style = document.createElement("style");
  style.id = STYLE_ID;
  style.textContent = STYLE;
  root.appendChild(style);
};

export const mountAnchoredTooltip = (
  root: ShadowRoot,
  opts: AnchoredTooltipOptions,
): AnchoredTooltipHandle => {
  ensureStyle(root);

  const host = document.createElement("div");
  host.className = "flowr-overlay-host";
  root.appendChild(host);

  const highlight = document.createElement("div");
  highlight.className = "wr-highlight";
  highlight.setAttribute("data-flowr-replay-highlight", "");
  host.appendChild(highlight);

  const tooltip = document.createElement("div");
  tooltip.className = "wr-tooltip";
  tooltip.setAttribute("data-flowr-tooltip", "");

  const title = document.createElement("div");
  title.className = "t-title";
  title.textContent = opts.title;
  tooltip.appendChild(title);

  const body = document.createElement("div");
  body.className = "t-body";
  body.textContent = opts.body;
  tooltip.appendChild(body);

  if (opts.actionLabel) {
    const action = document.createElement("button");
    action.type = "button";
    action.className = "t-action";
    action.textContent = opts.actionLabel;
    action.addEventListener("click", () => opts.onAction?.());
    tooltip.appendChild(action);
  }

  host.appendChild(tooltip);

  const getTargetRect = () =>
    opts.targetElement instanceof Element
      ? opts.targetElement.getBoundingClientRect()
      : opts.targetRect;

  const applyPosition = () => {
    const targetRect = getTargetRect();
    highlight.style.top = `${targetRect.top}px`;
    highlight.style.left = `${targetRect.left}px`;
    highlight.style.width = `${Math.max(targetRect.width, 4)}px`;
    highlight.style.height = `${Math.max(targetRect.height, 4)}px`;

    const tooltipHeight = tooltip.offsetHeight || 120;
    const tooltipWidth = tooltip.offsetWidth || 320;
    const desiredTop = targetRect.top + targetRect.height + 12;
    const fitsBelow = desiredTop + tooltipHeight + 12 < window.innerHeight;
    tooltip.classList.toggle("is-above", !fitsBelow);
    tooltip.style.top = fitsBelow
      ? `${desiredTop}px`
      : `${Math.max(targetRect.top - tooltipHeight - 12, 12)}px`;
    tooltip.style.left = `${Math.max(
      Math.min(targetRect.left, window.innerWidth - tooltipWidth - 12),
      12,
    )}px`;
  };

  applyPosition();

  let frameId: number | null = null;
  if (opts.targetElement) {
    const tick = () => {
      applyPosition();
      frameId = window.requestAnimationFrame(tick);
    };
    frameId = window.requestAnimationFrame(tick);
  }

  return {
    destroy: () => {
      if (frameId !== null) {
        window.cancelAnimationFrame(frameId);
      }
      host.remove();
    },
  };
};

export const mountReplayOverlayMessage = (
  root: ShadowRoot,
  message: string,
  placement: ReplayOverlayPlacement = "top",
): ReplayOverlayMessageHandle => {
  ensureStyle(root);

  const host = document.createElement("div");
  host.className = "flowr-overlay-host";
  host.setAttribute("data-flowr-replay-overlay", "");
  root.appendChild(host);

  const card = document.createElement("div");
  card.className = "flowr-replay-overlay";
  card.dataset.placement = placement;
  card.textContent = message;
  host.appendChild(card);

  return {
    destroy: () => {
      host.remove();
    },
    setMessage: (nextMessage: string, nextPlacement: ReplayOverlayPlacement = placement) => {
      card.dataset.placement = nextPlacement;
      card.textContent = nextMessage;
    },
  };
};
