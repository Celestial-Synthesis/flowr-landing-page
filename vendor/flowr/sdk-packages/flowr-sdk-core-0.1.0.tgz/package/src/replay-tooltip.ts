/**
 * Anchored highlight + tooltip rendered inside a Shadow DOM root.
 *
 * Draws a fixed-position overlay that highlights the target element and
 * a tooltip card next to it. Auto-flips above/below based on viewport.
 *
 * Visual surface (`.wr-highlight`, `.wr-tooltip`, `.wr-tooltip.is-above`)
 * is sourced from the shared `wr-styles` module so the extension and the
 * SDK cannot drift apart visually.
 */

import { WR_HIGHLIGHT_AND_TOOLTIP_CSS } from "./wr-styles";

export type AnchoredTooltipOptions = {
  targetRect: { top: number; left: number; width: number; height: number };
  targetElement?: Element | null;
  title: string;
  body: string;
  actionLabel: string | null;
  onAction?(): void;
};

type ReplayTargetRect = DOMRect | AnchoredTooltipOptions["targetRect"];

export type ReplayHighlightOptions = Pick<
  AnchoredTooltipOptions,
  "targetRect" | "targetElement"
> & {
  onPositionUpdate?(targetRect: ReplayTargetRect): void;
};

export type AnchoredTooltipHandle = {
  destroy(): void;
};

export type ReplayOverlayMessageHandle = {
  destroy(): void;
  setMessage(message: string, placement?: ReplayOverlayPlacement): void;
};

export type ReplayOverlayPlacement = "top" | "bottom" | "left" | "right";

const SDK_OVERLAY_CSS = `
  .flowr-overlay-host {
    position: fixed; inset: 0;
    pointer-events: none;
    z-index: 2147483647;
  }
  .wr-highlight[data-flowr-replay-highlight] {
    /* Force visible inside the SDK overlay (the extension fades in via JS).
     * Recorder SDKs share this ShadowRoot with authoring UI whose highlight
     * starts hidden via display:none, so replay must also restore display. */
    display: block;
    opacity: 1;
    transition: opacity .2s ease;
    background: transparent;
    backdrop-filter: none;
    box-shadow: none;
  }
  .flowr-replay-mask {
    position: fixed;
    pointer-events: none;
    background: rgba(10, 10, 10, 0.45);
    z-index: 2147483645;
  }
  .wr-tooltip {
    pointer-events: auto;
  }
  .wr-tooltip .t-title {
    font-size: 11px;
    font-weight: 700;
    color: #8d2e3a;
    text-transform: uppercase;
    letter-spacing: .04em;
    margin-bottom: 4px;
    text-align: center;
  }
  .wr-tooltip .t-body {
    font-size: 13px;
    color: #5a1c24;
    line-height: 1.4;
  }
  .wr-tooltip .t-action {
    margin: 10px auto 0;
    padding: 8px 10px;
    display: flex;
    width: fit-content;
    max-width: 100%;
    align-items: center;
    justify-content: center;
    border: none;
    border-radius: 8px;
    background: #8d2e3a;
    color: #ffffff;
    font-weight: 600;
    font-size: 13px;
    text-align: center;
    cursor: pointer;
    font-family: inherit;
  }
  .wr-tooltip .t-action:active {
    transform: scale(0.95);
  }
  .flowr-replay-overlay {
    position: fixed;
    top: 16px;
    left: 50%;
    transform: translateX(-50%);
    max-width: min(360px, calc(100vw - 24px));
    padding: 12px 14px;
    border-radius: 12px;
    background: rgba(90, 28, 36, 0.94);
    color: #ffffff;
    box-shadow: 0 12px 32px rgba(10, 10, 10, 0.3);
    font: 13px "Segoe UI", system-ui, -apple-system, Roboto, sans-serif;
    line-height: 1.45;
    text-align: center;
  }
  .flowr-replay-overlay[data-placement="bottom"] {
    top: auto;
    bottom: 16px;
  }
  .flowr-replay-overlay[data-placement="left"] {
    top: 50%;
    right: auto;
    left: 16px;
    transform: translateY(-50%);
  }
  .flowr-replay-overlay[data-placement="right"] {
    top: 50%;
    right: 16px;
    left: auto;
    transform: translateY(-50%);
  }
`;

const STYLE = `${WR_HIGHLIGHT_AND_TOOLTIP_CSS}\n${SDK_OVERLAY_CSS}`;

const STYLE_ID = "flowr-anchored-tooltip-style";

const ensureStyle = (root: ShadowRoot): void => {
  if (root.getElementById(STYLE_ID)) return;
  const style = document.createElement("style");
  style.id = STYLE_ID;
  style.textContent = STYLE;
  root.appendChild(style);
};

const getViewportSize = (): { width: number; height: number } => ({
  width: window.innerWidth || document.documentElement.clientWidth,
  height: window.innerHeight || document.documentElement.clientHeight,
});

const clamp = (value: number, min: number, max: number): number => {
  if (max < min) return min;
  return Math.max(Math.min(value, max), min);
};

const getSpotlightRect = (
  targetRect: ReplayTargetRect,
): {
  top: number;
  left: number;
  width: number;
  height: number;
} => {
  const { width: viewportWidth, height: viewportHeight } = getViewportSize();
  const minSize = 4;
  const targetRight = targetRect.left + targetRect.width;
  const targetBottom = targetRect.top + targetRect.height;
  const isHorizontallyVisible = targetRight > 0 && targetRect.left < viewportWidth;
  const isVerticallyVisible = targetBottom > 0 && targetRect.top < viewportHeight;

  const left = isHorizontallyVisible
    ? clamp(targetRect.left, 0, viewportWidth)
    : targetRight <= 0
      ? 0
      : Math.max(viewportWidth - minSize, 0);
  const right = isHorizontallyVisible
    ? clamp(targetRight, 0, viewportWidth)
    : Math.min(left + minSize, viewportWidth);
  const top = isVerticallyVisible
    ? clamp(targetRect.top, 0, viewportHeight)
    : targetBottom <= 0
      ? 0
      : Math.max(viewportHeight - minSize, 0);
  const bottom = isVerticallyVisible
    ? clamp(targetBottom, 0, viewportHeight)
    : Math.min(top + minSize, viewportHeight);

  return {
    top,
    left,
    width: Math.max(right - left, minSize),
    height: Math.max(bottom - top, minSize),
  };
};

type ReplaySpotlightHandle = AnchoredTooltipHandle & {
  host: HTMLElement;
  getTargetRect(): ReplayTargetRect;
};

const mountReplaySpotlight = (
  root: ShadowRoot,
  opts: ReplayHighlightOptions,
): ReplaySpotlightHandle => {
  ensureStyle(root);

  const host = document.createElement("div");
  host.className = "flowr-overlay-host";
  root.appendChild(host);

  const masks = Array.from({ length: 4 }, () => {
    const mask = document.createElement("div");
    mask.className = "flowr-replay-mask";
    host.appendChild(mask);
    return mask;
  });

  const highlight = document.createElement("div");
  highlight.className = "wr-highlight";
  highlight.setAttribute("data-flowr-replay-highlight", "");
  host.appendChild(highlight);

  const getTargetRect = () =>
    opts.targetElement instanceof Element
      ? opts.targetElement.getBoundingClientRect()
      : opts.targetRect;

  const setMaskRect = (
    mask: HTMLElement,
    rect: { top: number; left: number; width: number; height: number },
  ): void => {
    mask.style.top = `${rect.top}px`;
    mask.style.left = `${rect.left}px`;
    mask.style.width = `${Math.max(rect.width, 0)}px`;
    mask.style.height = `${Math.max(rect.height, 0)}px`;
  };

  const applyMasks = (spotlightRect: {
    top: number;
    left: number;
    width: number;
    height: number;
  }): void => {
    const { width: viewportWidth, height: viewportHeight } = getViewportSize();
    const right = Math.min(spotlightRect.left + spotlightRect.width, viewportWidth);
    const bottom = Math.min(spotlightRect.top + spotlightRect.height, viewportHeight);

    setMaskRect(masks[0], { top: 0, left: 0, width: viewportWidth, height: spotlightRect.top });
    setMaskRect(masks[1], {
      top: bottom,
      left: 0,
      width: viewportWidth,
      height: viewportHeight - bottom,
    });
    setMaskRect(masks[2], {
      top: spotlightRect.top,
      left: 0,
      width: spotlightRect.left,
      height: bottom - spotlightRect.top,
    });
    setMaskRect(masks[3], {
      top: spotlightRect.top,
      left: right,
      width: viewportWidth - right,
      height: bottom - spotlightRect.top,
    });
  };

  const applyPosition = () => {
    const targetRect = getTargetRect();
    const spotlightRect = getSpotlightRect(targetRect);
    applyMasks(spotlightRect);
    highlight.style.top = `${spotlightRect.top}px`;
    highlight.style.left = `${spotlightRect.left}px`;
    highlight.style.width = `${spotlightRect.width}px`;
    highlight.style.height = `${spotlightRect.height}px`;
    opts.onPositionUpdate?.(targetRect);
  };

  applyPosition();

  let resizeObserver: ResizeObserver | null = null;
  let mutationObserver: MutationObserver | null = null;
  window.addEventListener("resize", applyPosition, { passive: true });
  if (opts.targetElement) {
    window.addEventListener("scroll", applyPosition, { capture: true, passive: true });
    if (typeof ResizeObserver !== "undefined") {
      resizeObserver = new ResizeObserver(() => applyPosition());
      resizeObserver.observe(opts.targetElement);
    }
    if (typeof MutationObserver !== "undefined") {
      mutationObserver = new MutationObserver(() => applyPosition());
      mutationObserver.observe(document.body ?? document.documentElement, {
        attributes: true,
        childList: true,
        subtree: true,
      });
    }
  }

  return {
    host,
    getTargetRect,
    destroy: () => {
      window.removeEventListener("scroll", applyPosition, { capture: true });
      window.removeEventListener("resize", applyPosition);
      resizeObserver?.disconnect();
      mutationObserver?.disconnect();
      host.remove();
    },
  };
};

export const mountReplayHighlight = (
  root: ShadowRoot,
  opts: ReplayHighlightOptions,
): AnchoredTooltipHandle => {
  return mountReplaySpotlight(root, opts);
};

export const mountAnchoredTooltip = (
  root: ShadowRoot,
  opts: AnchoredTooltipOptions,
): AnchoredTooltipHandle => {
  let tooltip: HTMLDivElement | null = null;

  const applyTooltipPosition = (targetRect: ReplayTargetRect) => {
    if (!tooltip) {
      return;
    }

    const tooltipHeight = tooltip.offsetHeight || 120;
    const tooltipWidth = tooltip.offsetWidth || 320;
    const desiredTop = targetRect.top + targetRect.height + 12;
    const fitsBelow = desiredTop + tooltipHeight + 12 < window.innerHeight;
    tooltip.classList.toggle("is-above", !fitsBelow);
    tooltip.style.top = fitsBelow
      ? `${desiredTop}px`
      : `${Math.max(targetRect.top - tooltipHeight - 12, 12)}px`;
    tooltip.style.left = `${Math.max(
      Math.min(targetRect.left, window.innerWidth - tooltipWidth - 12),
      12,
    )}px`;
  };

  const spotlight = mountReplaySpotlight(root, {
    ...opts,
    onPositionUpdate: applyTooltipPosition,
  });

  tooltip = document.createElement("div");
  tooltip.className = "wr-tooltip";
  tooltip.setAttribute("data-flowr-tooltip", "");

  const title = document.createElement("div");
  title.className = "t-title";
  title.textContent = opts.title;
  tooltip.appendChild(title);

  const body = document.createElement("div");
  body.className = "t-body";
  body.textContent = opts.body;
  tooltip.appendChild(body);

  if (opts.actionLabel) {
    const action = document.createElement("button");
    action.type = "button";
    action.className = "t-action";
    action.textContent = opts.actionLabel;
    action.addEventListener("click", () => opts.onAction?.());
    tooltip.appendChild(action);
  }

  spotlight.host.appendChild(tooltip);
  applyTooltipPosition(spotlight.getTargetRect());

  return {
    destroy: () => {
      spotlight.destroy();
    },
  };
};

export const mountReplayOverlayMessage = (
  root: ShadowRoot,
  message: string,
  placement: ReplayOverlayPlacement = "top",
): ReplayOverlayMessageHandle => {
  ensureStyle(root);

  const host = document.createElement("div");
  host.className = "flowr-overlay-host";
  host.setAttribute("data-flowr-replay-overlay", "");
  root.appendChild(host);

  const card = document.createElement("div");
  card.className = "flowr-replay-overlay";
  card.dataset.placement = placement;
  card.textContent = message;
  host.appendChild(card);

  return {
    destroy: () => {
      host.remove();
    },
    setMessage: (nextMessage: string, nextPlacement: ReplayOverlayPlacement = placement) => {
      card.dataset.placement = nextPlacement;
      card.textContent = nextMessage;
    },
  };
};
