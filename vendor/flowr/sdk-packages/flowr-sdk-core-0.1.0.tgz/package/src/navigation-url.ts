export type NavigationUrlMatchMode = "strict" | "same-path-query-agnostic";

export type NavigationUrlMatchOptions = {
  mode?: NavigationUrlMatchMode;
};

export const navigationUrlMatches = (
  currentHref: string,
  targetHref: string,
  options?: NavigationUrlMatchOptions,
): boolean => {
  const mode = options?.mode ?? "strict";

  try {
    const current = new URL(currentHref);
    const target = new URL(targetHref);

    if (current.origin !== target.origin) return false;

    const normalizedCurrentPath = current.pathname.replace(/\/+$/, "") || "/";
    const normalizedTargetPath = target.pathname.replace(/\/+$/, "") || "/";

    if (normalizedCurrentPath === normalizedTargetPath) {
      if (mode === "same-path-query-agnostic") {
        return true;
      }
      return current.search === target.search && current.hash === target.hash;
    }

    if (
      current.search !== "" ||
      current.hash !== "" ||
      target.search !== "" ||
      target.hash !== ""
    ) {
      return false;
    }

    if (normalizedTargetPath === "/") {
      return true;
    }

    return normalizedCurrentPath.startsWith(`${normalizedTargetPath}/`);
  } catch {
    return currentHref === targetHref;
  }
};
