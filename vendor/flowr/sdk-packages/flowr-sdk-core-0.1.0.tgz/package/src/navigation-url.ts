import {
  DEFAULT_NAVIGATION_STEP_MATCH_MODE,
  NAVIGATION_STEP_MATCH_MODE_FIELD_LABEL,
  NAVIGATION_STEP_MATCH_MODE_OPTIONS,
  NAVIGATION_STEP_MATCH_MODE_SECTION_LABEL,
  getSafeHttpNavigationUrl,
  navigationUrlMatches,
  type NavigationStepMatchMode,
  type NavigationStepMatchModeOption,
  type NavigationUrlMatchMode,
  type NavigationUrlMatchOptions,
} from "@flowr/shared-core";
import type { Recording, Step } from "./types";

export {
  DEFAULT_NAVIGATION_STEP_MATCH_MODE,
  NAVIGATION_STEP_MATCH_MODE_FIELD_LABEL,
  NAVIGATION_STEP_MATCH_MODE_OPTIONS,
  NAVIGATION_STEP_MATCH_MODE_SECTION_LABEL,
  getSafeHttpNavigationUrl,
  navigationUrlMatches,
};
export type {
  NavigationStepMatchMode,
  NavigationStepMatchModeOption,
  NavigationUrlMatchMode,
  NavigationUrlMatchOptions,
};

export type NavigationMatchTarget = {
  targetHref: string;
  sourceHref?: string;
  matchMode?: NavigationStepMatchMode;
};

const resolveNavigationSourceHref = (
  recording: Pick<Recording, "startUrl" | "steps">,
  stepIndex: number,
): string | undefined => {
  for (let currentIndex = stepIndex - 1; currentIndex >= 0; currentIndex -= 1) {
    const previousUrl = recording.steps[currentIndex]?.url?.trim();
    if (previousUrl) {
      return previousUrl;
    }
  }

  const startUrl = recording.startUrl?.trim();
  return startUrl || undefined;
};

export const getNavigationStepMatchMode = (
  step: Pick<Step, "navigationMatchMode">,
): NavigationStepMatchMode => {
  return step.navigationMatchMode ?? DEFAULT_NAVIGATION_STEP_MATCH_MODE;
};

export const getNavigationStepTarget = (
  recording: Pick<Recording, "startUrl" | "steps">,
  stepIndex: number,
): NavigationMatchTarget | null => {
  const step = recording.steps[stepIndex];
  const targetHref = step?.url?.trim();
  if (!step || step.kind !== "navigation" || !targetHref) {
    return null;
  }

  return {
    targetHref,
    sourceHref: resolveNavigationSourceHref(recording, stepIndex),
    matchMode: getNavigationStepMatchMode(step),
  };
};

export const getReplayResumeTarget = (
  recording: Pick<Recording, "startUrl" | "steps">,
  stepIndex: number,
): NavigationMatchTarget | null => {
  const explicitNavigationTarget = getNavigationStepTarget(recording, stepIndex);
  if (explicitNavigationTarget) {
    return explicitNavigationTarget;
  }

  const step = recording.steps[stepIndex];
  const targetHref = step?.url?.trim();
  if (!step || !targetHref) {
    return null;
  }

  return {
    targetHref,
    sourceHref: resolveNavigationSourceHref(recording, stepIndex),
  };
};

export const navigationStepTargetMatches = (
  currentHref: string,
  target: NavigationMatchTarget,
): boolean => {
  const matchMode = target.matchMode ?? DEFAULT_NAVIGATION_STEP_MATCH_MODE;

  if (navigationUrlMatches(currentHref, target.targetHref, { mode: "strict" })) {
    return true;
  }

  try {
    const current = new URL(currentHref);
    const destination = new URL(target.targetHref);
    if (destination.search !== "" && current.search === "") {
      return false;
    }
    if (destination.hash !== "" && current.hash === "") {
      return false;
    }
  } catch {
    return false;
  }

  return navigationUrlMatches(currentHref, target.targetHref, {
    mode: matchMode,
    sourceHref: target.sourceHref,
  });
};

export const navigationTargetReached = (
  currentHref: string,
  targetHref: string,
  options?: Omit<NavigationMatchTarget, "targetHref">,
): boolean => {
  return navigationStepTargetMatches(currentHref, {
    targetHref,
    sourceHref: options?.sourceHref,
    matchMode: options?.matchMode,
  });
};
