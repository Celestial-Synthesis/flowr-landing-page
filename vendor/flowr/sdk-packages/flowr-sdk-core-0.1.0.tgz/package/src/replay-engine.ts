/**
 * SDK replay engine — runs a Recording's steps against the host page.
 *
 * Supported step kinds (MVP):
 *   click | hover | context-click | input | change | submit | navigation | scroll | instruction
 *
 * Renders an anchored highlight + tooltip via `replay-tooltip.ts` inside
 * the bubble's Shadow DOM root so it survives host-page CSS.
 *
 * Keeps the public surface tiny — sdk-replay re-exports `createReplayRunner`
 * and feeds it a `Recording` plus a `ShadowRoot` for tooltip mounting.
 */

import { findElement } from "./selector";
import {
  mountAnchoredTooltip,
  mountReplayHighlight,
  mountReplayOverlayMessage,
  type AnchoredTooltipHandle,
  type ReplayOverlayMessageHandle,
} from "./replay-tooltip";
import { evaluateSkipCondition } from "./skip-condition";
import {
  applyInputAutofill,
  describeStep,
  dispatchKeyboardStep,
  getScrollInstructionDetails,
  isElementInViewport,
  isElementVisible,
  keyboardStepDescriptor,
} from "./replay-helpers";
import { getNavigationStepTarget, navigationStepTargetMatches } from "./navigation-url";
import type { Recording, SdkReplayOverlayCopy, Step } from "./types";

export type ReplayRunnerEvent =
  | { type: "step"; index: number; total: number; step: Step }
  | { type: "step-error"; index: number; step: Step; error: Error }
  | { type: "complete" }
  | { type: "stopped" };

export type ReplayRunnerOptions = {
  recording: Recording;
  /** Shadow root that hosts highlight + tooltip overlays. */
  shadowRoot: ShadowRoot;
  /** Auto-advance through clickable steps. Default: false (user clicks). */
  auto?: boolean;
  /** Optional copy overrides for the off-screen replay overlay. */
  overlayCopy?: SdkReplayOverlayCopy;
  /** Delay between auto-advanced steps (ms). Default: 600. */
  autoDelayMs?: number;
  /** How long to wait for a missing/hidden target before emitting step-error. Default: 10000. */
  targetWaitMs?: number;
  onEvent?(event: ReplayRunnerEvent): void;
};

export type ReplayRunnerHandle = {
  start(startIndex?: number): void;
  stop(): void;
  next(): void;
  current(): number;
};

/**
 * Replay timing constants. Centralized so behavior tuning happens in
 * one place. `autoDelayMs` is the user-tunable default; the others are
 * implementation details for visual smoothness.
 */
export const REPLAY_TIMINGS = {
  /** Wait after `scrollIntoView` so the element settles before measure. */
  scrollSettleMs: 120,
  /** Slightly longer settle for `scroll`-kind steps that animate. */
  scrollKindSettleMs: 150,
  /** Default auto-advance delay between steps. */
  autoDelayMs: 600,
  /** Auto-advance delay after a `skipCondition` jump (faster). */
  skipJumpAutoDelayMs: 200,
  /** Poll interval while waiting for a target to appear or become visible. */
  targetPollMs: 150,
  /** Default timeout while waiting for a target to appear or become visible. */
  targetWaitMs: 10_000,
} as const;

const wait = (ms: number) =>
  new Promise<void>((resolve) => {
    setTimeout(resolve, ms);
  });

export const createReplayRunner = (opts: ReplayRunnerOptions): ReplayRunnerHandle => {
  const { recording, shadowRoot } = opts;
  const total = recording.steps.length;
  let index = 0;
  let stopped = false;
  let tooltip: AnchoredTooltipHandle | null = null;
  let activeReplayHighlight: AnchoredTooltipHandle | null = null;
  let detachCurrentStepListener: (() => void) | null = null;
  let runId = 0;
  // Track step IDs that were skipped via a `skipCondition` so future
  // step-skip references can resolve.
  const skippedStepIds = new Set<string>();

  const emit = (event: ReplayRunnerEvent): void => {
    opts.onEvent?.(event);
  };

  const isRunActive = (activeRunId: number): boolean => {
    return !stopped && activeRunId === runId;
  };

  const assertRunActive = (activeRunId: number): void => {
    if (!isRunActive(activeRunId)) {
      throw new Error("replay stopped");
    }
  };

  const tearDownReplayHighlight = (): void => {
    activeReplayHighlight?.destroy();
    activeReplayHighlight = null;
  };

  const cleanup = () => {
    detachCurrentStepListener?.();
    detachCurrentStepListener = null;
    tearDownReplayHighlight();
    tooltip?.destroy();
    tooltip = null;
  };

  const advance = (activeRunId = runId) => {
    if (!isRunActive(activeRunId)) return;
    if (index >= total) {
      cleanup();
      emit({ type: "complete" });
      return;
    }
    const step = recording.steps[index];
    const navigationTarget =
      step.kind === "navigation" ? getNavigationStepTarget(recording, index) : null;
    if (navigationTarget && navigationStepTargetMatches(window.location.href, navigationTarget)) {
      index += 1;
      advance(activeRunId);
      return;
    }
    emit({ type: "step", index, total, step });

    // Evaluate skip condition before running the step. If it matches we
    // mark this step as skipped and jump to the configured target.
    const skip = evaluateSkipCondition(step, recording, {
      findElement,
      isElementVisible,
      skippedStepIds,
      currentIndex: index,
    });
    if (skip) {
      skippedStepIds.add(step.id);
      cleanup();
      index = skip.jumpToIndex;
      if (opts.auto) {
        void wait(opts.autoDelayMs ?? REPLAY_TIMINGS.skipJumpAutoDelayMs).then(() =>
          advance(activeRunId),
        );
      } else {
        advance(activeRunId);
      }
      return;
    }

    runStep(step, activeRunId)
      .then((handled) => {
        if (!isRunActive(activeRunId)) return;
        if (handled?.advanced) return; // step handler already advanced
        index += 1;
        if (step.kind === "navigation" && !opts.auto) return;
        if (opts.auto) {
          void wait(opts.autoDelayMs ?? REPLAY_TIMINGS.autoDelayMs).then(() =>
            advance(activeRunId),
          );
        } else {
          advance(activeRunId);
        }
      })
      .catch((err: Error) => {
        if (!isRunActive(activeRunId)) return;
        emit({ type: "step-error", index, step, error: err });
      });
  };

  /**
   * Mount the step tooltip anchored to `el`. Handles the boilerplate of
   * measuring the element rect, threading the step title/body, and
   * stashing the handle into the closure-scoped `tooltip` so `cleanup()`
   * can tear it down on stop or step transition.
   */
  const mountStepTooltip = (
    el: Element,
    step: Step,
    actionLabel: string | null,
    onAction: () => void,
  ): void => {
    const rect = el.getBoundingClientRect();
    tooltip = mountAnchoredTooltip(shadowRoot, {
      targetElement: el,
      targetRect: {
        top: rect.top,
        left: rect.left,
        width: rect.width,
        height: rect.height,
      },
      title: `Step ${index + 1} / ${total}`,
      body: step.instruction ?? describeStep(step),
      actionLabel,
      onAction,
    });
  };

  const tearDownTooltip = (): void => {
    tooltip?.destroy();
    tooltip = null;
  };

  const waitForManualTargetInView = async (el: Element): Promise<void> => {
    if (isElementInViewport(el)) {
      return;
    }

    await new Promise<void>((resolve) => {
      let overlay: ReplayOverlayMessageHandle | null = null;
      let checkId: number | null = null;
      let resolved = false;

      const teardown = (): void => {
        if (checkId !== null) {
          window.clearInterval(checkId);
          checkId = null;
        }
        window.removeEventListener("scroll", syncScrollState, true);
        window.removeEventListener("resize", syncScrollState, true);
        overlay?.destroy();
        overlay = null;
      };

      const finish = (): void => {
        if (resolved) {
          return;
        }
        resolved = true;
        teardown();
        detachCurrentStepListener = null;
        resolve();
      };

      const syncScrollState = (): void => {
        if (isElementInViewport(el)) {
          finish();
          return;
        }

        const { message, placement } = getScrollInstructionDetails(el, opts.overlayCopy);
        if (!overlay) {
          overlay = mountReplayOverlayMessage(shadowRoot, message, placement);
          return;
        }
        overlay.setMessage(message, placement);
      };

      detachCurrentStepListener = finish;

      window.addEventListener("scroll", syncScrollState, true);
      window.addEventListener("resize", syncScrollState, true);
      checkId = window.setInterval(syncScrollState, 100);
      syncScrollState();
    });
  };

  const waitForManualTargetInViewWithHighlight = async (el: Element): Promise<void> => {
    if (isElementInViewport(el)) {
      return;
    }

    const rect = el.getBoundingClientRect();
    const highlight = mountReplayHighlight(shadowRoot, {
      targetElement: el,
      targetRect: {
        top: rect.top,
        left: rect.left,
        width: rect.width,
        height: rect.height,
      },
    });
    activeReplayHighlight = highlight;

    try {
      await waitForManualTargetInView(el);
    } finally {
      if (activeReplayHighlight === highlight) {
        activeReplayHighlight = null;
      }
      highlight.destroy();
    }
  };

  const waitForStepTarget = async (step: Step): Promise<Element | null> => {
    const deadline = Date.now() + (opts.targetWaitMs ?? REPLAY_TIMINGS.targetWaitMs);
    do {
      const el = step.selector ? findElement(step.selector) : null;
      if (el && isElementVisible(el)) {
        return el;
      }
      await wait(REPLAY_TIMINGS.targetPollMs);
    } while (!stopped && Date.now() < deadline);

    return stopped ? null : step.selector ? findElement(step.selector) : null;
  };

  const runStep = async (
    step: Step,
    activeRunId: number,
  ): Promise<{ advanced?: boolean } | void> => {
    cleanup();

    if (step.kind === "navigation") {
      // Navigation must be initiated by the host (or `allowNavigation`).
      // Replay halts here; the wrapper SDK decides what to do.
      return;
    }

    if (!step.selector) return;
    const el = await waitForStepTarget(step);
    assertRunActive(activeRunId);
    if (!el) {
      throw new Error(`element not found for step ${index + 1}`);
    }
    if (!isElementVisible(el)) {
      throw new Error(`element not visible for step ${index + 1}`);
    }

    if (step.kind === "scroll") {
      if (opts.auto) {
        el.scrollIntoView({ behavior: "smooth", block: "center" });
        await wait(REPLAY_TIMINGS.scrollKindSettleMs);
        return;
      }

      await waitForManualTargetInViewWithHighlight(el);
      assertRunActive(activeRunId);
      await new Promise<void>((resolve) => {
        let resolved = false;

        const finish = (): void => {
          if (resolved) {
            return;
          }
          resolved = true;
          detachCurrentStepListener = null;
          tearDownTooltip();
          resolve();
        };

        mountStepTooltip(el, step, "Continue", finish);
        detachCurrentStepListener = finish;
      });
      return;
    }

    if (step.kind === "key enter" || step.kind === "key tab" || step.kind === "key shift+tab") {
      if (opts.auto) {
        el.scrollIntoView({ behavior: "smooth", block: "center" });
        await wait(REPLAY_TIMINGS.scrollSettleMs);
        await new Promise<void>((resolve) => {
          mountStepTooltip(el, step, null, () => {
            /* no-op */
          });
          dispatchKeyboardStep(el, step.kind);
          void wait(opts.autoDelayMs ?? REPLAY_TIMINGS.autoDelayMs).then(() => {
            tearDownTooltip();
            resolve();
          });
        });
        return;
      }

      await waitForManualTargetInViewWithHighlight(el);
      assertRunActive(activeRunId);

      // In manual mode, keyboard steps wait for the user to press the
      // matching key on the focused target, matching extension replay.
      await new Promise<void>((resolve) => {
        const { key, shiftKey } = keyboardStepDescriptor(step.kind);
        let resolved = false;
        function finish(): void {
          if (resolved) {
            return;
          }
          resolved = true;
          document.removeEventListener("keydown", onKeyDown, true);
          detachCurrentStepListener = null;
          tearDownTooltip();
          resolve();
        }
        function onKeyDown(event: KeyboardEvent): void {
          if (event.key !== key || event.shiftKey !== shiftKey) {
            return;
          }
          if (!(event.target instanceof Node)) {
            return;
          }
          if (event.target !== el && !el.contains(event.target)) {
            return;
          }
          window.requestAnimationFrame(finish);
        }

        mountStepTooltip(el, step, null, () => {
          /* no-op */
        });
        if (el instanceof HTMLElement) {
          el.focus();
        }
        document.addEventListener("keydown", onKeyDown, true);
        detachCurrentStepListener = finish;
      });
      return;
    }

    if (opts.auto) {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      await wait(REPLAY_TIMINGS.scrollSettleMs);
    } else {
      await waitForManualTargetInViewWithHighlight(el);
      assertRunActive(activeRunId);
    }

    // For click steps: install listener and wait for actual click. The
    // listener resolves the promise; we let the outer .then() advance.
    if (step.kind === "click") {
      await new Promise<void>((resolve) => {
        let resolved = false;
        function handler(): void {
          finish();
        }
        function finish(): void {
          if (resolved) {
            return;
          }
          resolved = true;
          el.removeEventListener("click", handler, true);
          detachCurrentStepListener = null;
          tearDownTooltip();
          resolve();
        }
        mountStepTooltip(el, step, null, () => {
          /* no-op */
        });
        el.addEventListener("click", handler, true);
        detachCurrentStepListener = finish;
      });
      return;
    }

    if (step.kind === "hover") {
      await new Promise<void>((resolve) => {
        let resolved = false;
        function onHover(): void {
          finish();
        }
        function finish(): void {
          if (resolved) {
            return;
          }
          resolved = true;
          el.removeEventListener("mouseenter", onHover, true);
          detachCurrentStepListener = null;
          tearDownTooltip();
          resolve();
        }
        mountStepTooltip(el, step, null, finish);
        el.addEventListener("mouseenter", onHover, true);
        detachCurrentStepListener = finish;
        if (opts.auto) {
          void wait(opts.autoDelayMs ?? REPLAY_TIMINGS.autoDelayMs).then(finish);
        }
      });
      return;
    }

    if (step.kind === "context-click") {
      await new Promise<void>((resolve) => {
        let resolved = false;
        function onContextMenu(event: Event): void {
          event.preventDefault();
          finish();
        }
        function finish(): void {
          if (resolved) {
            return;
          }
          resolved = true;
          el.removeEventListener("contextmenu", onContextMenu, true);
          detachCurrentStepListener = null;
          tearDownTooltip();
          resolve();
        }
        mountStepTooltip(el, step, null, () => {
          /* no-op */
        });
        el.addEventListener("contextmenu", onContextMenu, true);
        detachCurrentStepListener = finish;
        if (opts.auto) {
          void wait(opts.autoDelayMs ?? REPLAY_TIMINGS.autoDelayMs).then(finish);
        }
      });
      return;
    }

    if (step.kind === "input" || step.kind === "input password") {
      await new Promise<void>((resolve) => {
        let resolved = false;
        const finish = (): void => {
          if (resolved) {
            return;
          }
          resolved = true;
          detachCurrentStepListener = null;
          tearDownTooltip();
          resolve();
        };
        mountStepTooltip(el, step, "Continue", finish);
        detachCurrentStepListener = finish;
        const target = el as HTMLInputElement;
        if (typeof step.value === "string" && opts.auto) {
          target.focus();
          applyInputAutofill(target, step.value);
          void wait(opts.autoDelayMs ?? REPLAY_TIMINGS.autoDelayMs).then(finish);
        }
      });
      return;
    }
  };

  const handle: ReplayRunnerHandle = {
    start(startIndex = 0) {
      runId += 1;
      cleanup();
      stopped = false;
      index = Math.min(Math.max(0, Math.floor(startIndex)), total);
      skippedStepIds.clear();
      advance(runId);
    },
    stop() {
      stopped = true;
      runId += 1;
      cleanup();
      emit({ type: "stopped" });
    },
    next() {
      runId += 1;
      cleanup();
      index += 1;
      advance(runId);
    },
    current: () => index,
  };

  return handle;
};
