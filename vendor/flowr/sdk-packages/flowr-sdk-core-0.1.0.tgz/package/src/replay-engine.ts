/**
 * SDK replay engine — runs a Recording's steps against the host page.
 *
 * Supported step kinds (MVP):
 *   click | hover | context-click | input | change | submit | navigation | scroll | instruction
 *
 * Renders an anchored highlight + tooltip via `replay-tooltip.ts` inside
 * the bubble's Shadow DOM root so it survives host-page CSS.
 *
 * Keeps the public surface tiny — sdk-replay re-exports `createReplayRunner`
 * and feeds it a `Recording` plus a `ShadowRoot` for tooltip mounting.
 */

import { findElement } from "./selector";
import {
  mountAnchoredTooltip,
  mountReplayOverlayMessage,
  type AnchoredTooltipHandle,
  type ReplayOverlayMessageHandle,
} from "./replay-tooltip";
import { evaluateSkipCondition } from "./skip-condition";
import {
  applyInputAutofill,
  describeStep,
  dispatchKeyboardStep,
  getScrollInstructionDetails,
  isElementInViewport,
  isElementVisible,
  keyboardStepDescriptor,
} from "./replay-helpers";
import type { Recording, Step } from "./types";

export type ReplayRunnerEvent =
  | { type: "step"; index: number; total: number; step: Step }
  | { type: "step-error"; index: number; step: Step; error: Error }
  | { type: "complete" }
  | { type: "stopped" };

export type ReplayRunnerOptions = {
  recording: Recording;
  /** Shadow root that hosts highlight + tooltip overlays. */
  shadowRoot: ShadowRoot;
  /** Auto-advance through clickable steps. Default: false (user clicks). */
  auto?: boolean;
  /** Delay between auto-advanced steps (ms). Default: 600. */
  autoDelayMs?: number;
  onEvent?(event: ReplayRunnerEvent): void;
};

export type ReplayRunnerHandle = {
  start(): void;
  stop(): void;
  next(): void;
  current(): number;
};

/**
 * Replay timing constants. Centralized so behavior tuning happens in
 * one place. `autoDelayMs` is the user-tunable default; the others are
 * implementation details for visual smoothness.
 */
export const REPLAY_TIMINGS = {
  /** Wait after `scrollIntoView` so the element settles before measure. */
  scrollSettleMs: 120,
  /** Slightly longer settle for `scroll`-kind steps that animate. */
  scrollKindSettleMs: 150,
  /** Default auto-advance delay between steps. */
  autoDelayMs: 600,
  /** Auto-advance delay after a `skipCondition` jump (faster). */
  skipJumpAutoDelayMs: 200,
} as const;

const wait = (ms: number) =>
  new Promise<void>((resolve) => {
    setTimeout(resolve, ms);
  });

export const createReplayRunner = (opts: ReplayRunnerOptions): ReplayRunnerHandle => {
  const { recording, shadowRoot } = opts;
  const total = recording.steps.length;
  let index = 0;
  let stopped = false;
  let tooltip: AnchoredTooltipHandle | null = null;
  let detachCurrentStepListener: (() => void) | null = null;
  // Track step IDs that were skipped via a `skipCondition` so future
  // `step-skipped` references can resolve.
  const skippedStepIds = new Set<string>();

  const emit = (event: ReplayRunnerEvent): void => {
    opts.onEvent?.(event);
  };

  const cleanup = () => {
    detachCurrentStepListener?.();
    detachCurrentStepListener = null;
    tooltip?.destroy();
    tooltip = null;
  };

  const advance = () => {
    if (stopped) return;
    if (index >= total) {
      cleanup();
      emit({ type: "complete" });
      return;
    }
    const step = recording.steps[index];
    emit({ type: "step", index, total, step });

    // Evaluate skip condition before running the step. If it matches we
    // mark this step as skipped and jump to the configured target.
    const skip = evaluateSkipCondition(step, recording, {
      findElement,
      isElementVisible,
      skippedStepIds,
      currentIndex: index,
    });
    if (skip) {
      skippedStepIds.add(step.id);
      cleanup();
      index = skip.jumpToIndex;
      if (opts.auto) {
        void wait(opts.autoDelayMs ?? REPLAY_TIMINGS.skipJumpAutoDelayMs).then(advance);
      } else {
        advance();
      }
      return;
    }

    runStep(step)
      .then((handled) => {
        if (handled?.advanced) return; // step handler already advanced
        index += 1;
        if (step.kind === "navigation" && !opts.auto) return;
        if (opts.auto) {
          void wait(opts.autoDelayMs ?? REPLAY_TIMINGS.autoDelayMs).then(advance);
        } else {
          advance();
        }
      })
      .catch((err: Error) => {
        emit({ type: "step-error", index, step, error: err });
      });
  };

  /**
   * Mount the step tooltip anchored to `el`. Handles the boilerplate of
   * measuring the element rect, threading the step title/body, and
   * stashing the handle into the closure-scoped `tooltip` so `cleanup()`
   * can tear it down on stop or step transition.
   */
  const mountStepTooltip = (
    el: Element,
    step: Step,
    actionLabel: string | null,
    onAction: () => void,
  ): void => {
    const rect = el.getBoundingClientRect();
    tooltip = mountAnchoredTooltip(shadowRoot, {
      targetElement: el,
      targetRect: {
        top: rect.top,
        left: rect.left,
        width: rect.width,
        height: rect.height,
      },
      title: `Step ${index + 1} / ${total}`,
      body: step.instruction ?? describeStep(step),
      actionLabel,
      onAction,
    });
  };

  const tearDownTooltip = (): void => {
    tooltip?.destroy();
    tooltip = null;
  };

  const waitForManualTargetInView = async (el: Element): Promise<void> => {
    if (isElementInViewport(el)) {
      return;
    }

    await new Promise<void>((resolve) => {
      let overlay: ReplayOverlayMessageHandle | null = null;
      let checkId: number | null = null;
      let resolved = false;

      const tearDownOverlay = (): void => {
        overlay?.destroy();
        overlay = null;
      };

      const finish = (): void => {
        if (resolved) {
          return;
        }
        resolved = true;
        detachCurrentStepListener?.();
        detachCurrentStepListener = null;
        resolve();
      };

      const syncScrollState = (): void => {
        if (isElementInViewport(el)) {
          finish();
          return;
        }

        const { message, placement } = getScrollInstructionDetails(el);
        if (!overlay) {
          overlay = mountReplayOverlayMessage(shadowRoot, message, placement);
          return;
        }
        overlay.setMessage(message, placement);
      };

      detachCurrentStepListener = () => {
        if (checkId !== null) {
          window.clearInterval(checkId);
          checkId = null;
        }
        window.removeEventListener("scroll", syncScrollState, true);
        window.removeEventListener("resize", syncScrollState, true);
        tearDownOverlay();
      };

      window.addEventListener("scroll", syncScrollState, true);
      window.addEventListener("resize", syncScrollState, true);
      checkId = window.setInterval(syncScrollState, 100);
      syncScrollState();
    });
  };

  const runStep = async (step: Step): Promise<{ advanced?: boolean } | void> => {
    cleanup();

    if (step.kind === "navigation") {
      // Navigation must be initiated by the host (or `allowNavigation`).
      // Replay halts here; the wrapper SDK decides what to do.
      return;
    }

    if (!step.selector) return;
    const el = findElement(step.selector);
    if (!el) {
      throw new Error(`element not found for step ${index + 1}`);
    }

    if (step.kind === "scroll") {
      if (opts.auto) {
        el.scrollIntoView({ behavior: "smooth", block: "center" });
        await wait(REPLAY_TIMINGS.scrollKindSettleMs);
        return;
      }

      await waitForManualTargetInView(el);
      await new Promise<void>((resolve) => {
        let resolved = false;

        const finish = (): void => {
          if (resolved) {
            return;
          }
          resolved = true;
          detachCurrentStepListener?.();
          detachCurrentStepListener = null;
          resolve();
        };

        mountStepTooltip(el, step, "Continue", finish);
        detachCurrentStepListener = tearDownTooltip;
      });
      return;
    }

    if (step.kind === "key enter" || step.kind === "key tab" || step.kind === "key shift+tab") {
      if (opts.auto) {
        el.scrollIntoView({ behavior: "smooth", block: "center" });
        await wait(REPLAY_TIMINGS.scrollSettleMs);
        await new Promise<void>((resolve) => {
          mountStepTooltip(el, step, null, () => {
            /* no-op */
          });
          dispatchKeyboardStep(el, step.kind);
          void wait(opts.autoDelayMs ?? REPLAY_TIMINGS.autoDelayMs).then(() => {
            tearDownTooltip();
            resolve();
          });
        });
        return;
      }

      await waitForManualTargetInView(el);

      // In manual mode, keyboard steps wait for the user to press the
      // matching key on the focused target, matching extension replay.
      await new Promise<void>((resolve) => {
        const { key, shiftKey } = keyboardStepDescriptor(step.kind);
        const finish = (): void => {
          detachCurrentStepListener?.();
          detachCurrentStepListener = null;
          tearDownTooltip();
          resolve();
        };
        const onKeyDown = (event: KeyboardEvent): void => {
          if (event.key !== key || event.shiftKey !== shiftKey) {
            return;
          }
          if (!(event.target instanceof Node)) {
            return;
          }
          if (event.target !== el && !el.contains(event.target)) {
            return;
          }
          window.requestAnimationFrame(finish);
        };

        mountStepTooltip(el, step, null, () => {
          /* no-op */
        });
        if (el instanceof HTMLElement) {
          el.focus();
        }
        document.addEventListener("keydown", onKeyDown, true);
        detachCurrentStepListener = () => {
          document.removeEventListener("keydown", onKeyDown, true);
        };
      });
      return;
    }

    if (opts.auto) {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      await wait(REPLAY_TIMINGS.scrollSettleMs);
    } else {
      await waitForManualTargetInView(el);
    }

    // For click steps: install listener and wait for actual click. The
    // listener resolves the promise; we let the outer .then() advance.
    if (step.kind === "click") {
      await new Promise<void>((resolve) => {
        mountStepTooltip(el, step, null, () => {
          /* no-op */
        });
        const handler = () => {
          el.removeEventListener("click", handler, true);
          tearDownTooltip();
          resolve();
        };
        el.addEventListener("click", handler, true);
      });
      return;
    }

    if (step.kind === "hover") {
      await new Promise<void>((resolve) => {
        const finish = () => {
          el.removeEventListener("mouseenter", onHover, true);
          tearDownTooltip();
          resolve();
        };
        const onHover = () => {
          finish();
        };
        mountStepTooltip(el, step, null, finish);
        el.addEventListener("mouseenter", onHover, true);
        if (opts.auto) {
          void wait(opts.autoDelayMs ?? REPLAY_TIMINGS.autoDelayMs).then(finish);
        }
      });
      return;
    }

    if (step.kind === "context-click") {
      await new Promise<void>((resolve) => {
        const finish = () => {
          el.removeEventListener("contextmenu", onContextMenu, true);
          tearDownTooltip();
          resolve();
        };
        const onContextMenu = (event: Event) => {
          event.preventDefault();
          finish();
        };
        mountStepTooltip(el, step, null, () => {
          /* no-op */
        });
        el.addEventListener("contextmenu", onContextMenu, true);
        if (opts.auto) {
          void wait(opts.autoDelayMs ?? REPLAY_TIMINGS.autoDelayMs).then(finish);
        }
      });
      return;
    }

    if (step.kind === "input" || step.kind === "input password") {
      await new Promise<void>((resolve) => {
        mountStepTooltip(el, step, "Continue", () => {
          tearDownTooltip();
          resolve();
        });
        const target = el as HTMLInputElement;
        if (typeof step.value === "string" && opts.auto) {
          target.focus();
          applyInputAutofill(target, step.value);
          void wait(opts.autoDelayMs ?? REPLAY_TIMINGS.autoDelayMs).then(resolve);
        }
      });
      return;
    }
  };

  const handle: ReplayRunnerHandle = {
    start() {
      stopped = false;
      index = 0;
      advance();
    },
    stop() {
      stopped = true;
      cleanup();
      emit({ type: "stopped" });
    },
    next() {
      tooltip?.destroy();
      tooltip = null;
      index += 1;
      advance();
    },
    current: () => index,
  };

  return handle;
};
