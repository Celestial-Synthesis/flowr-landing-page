/**
 * Shared skip-condition evaluation used by both the FlowR extension's
 * replay flows (`src/content/replay-flow.ts`, `src/content/replay-runner.ts`)
 * and the SDK replay engine (`src/replay-engine.ts`).
 *
 * Centralizing this logic ensures the extension and the SDK runtimes
 * always agree on when a step is skipped and where execution jumps to.
 */

import type { Recording, SelectorInfo, Step } from "./types";

export type SkipConditionContext = {
  /**
   * Resolve a {@link SelectorInfo} to an `Element` in the current
   * document context. Callers typically pass their own selector engine
   * (`findTargetBySelector` in the extension, `findElement` in the SDK)
   * so deep search/regex behavior is preserved.
   */
  findElement: (selector: SelectorInfo) => Element | null;
  /**
   * Predicate for "the user can see this element right now" — checks
   * bounding rect plus computed style. Both runtimes have their own
   * implementation; pass it through.
   */
  isElementVisible: (el: Element) => boolean;
  /** Set of step ids that have already been skipped this run. */
  skippedStepIds: ReadonlySet<string>;
  /**
   * Index of the step currently being evaluated. The jump target must
   * be strictly after this index (forward-only jumps) to avoid loops.
   */
  currentIndex: number;
};

export type SkipConditionResult = {
  /** Index in `recording.steps` to resume execution at. */
  jumpToIndex: number;
};

/**
 * Evaluate a step's `skipCondition` against the live page.
 *
 * Returns `null` when there is no condition, the condition is not met,
 * or the resolved jump target would not move execution forward.
 */
export const evaluateSkipCondition = (
  step: Step,
  recording: Recording,
  ctx: SkipConditionContext,
): SkipConditionResult | null => {
  const condition = step.skipCondition;
  if (!condition) return null;

  let conditionMet = false;
  if (condition.type === "element-not-visible" && step.selector) {
    const target = ctx.findElement(step.selector);
    conditionMet = !target || !ctx.isElementVisible(target);
  } else if (condition.type === "element-visible" && condition.selector) {
    const target = ctx.findElement(condition.selector);
    conditionMet = !!target && ctx.isElementVisible(target);
  } else if (condition.type === "step-skipped" && condition.referenceStepId) {
    conditionMet = ctx.skippedStepIds.has(condition.referenceStepId);
  }
  if (!conditionMet) return null;

  if (!condition.jumpToStepId) return null;
  const jumpIndex = recording.steps.findIndex((s) => s.id === condition.jumpToStepId);
  if (jumpIndex < 0 || jumpIndex <= ctx.currentIndex) return null;
  return { jumpToIndex: jumpIndex };
};
