/**
 * Shared replay-side DOM helpers used by both `@flowr/sdk-core`'s
 * `createReplayRunner` and the FlowR extension's content-script replay
 * orchestrator. Lives here so the two runtimes can never drift on
 * fundamentals like visibility checks, key dispatch, or autofill semantics.
 *
 * Pure DOM, zero state, zero side effects beyond what each helper documents.
 */

import type { SdkReplayOverlayCopy, Step, StepKind } from "./types";

export type ScrollInstructionPlacement = "top" | "bottom" | "left" | "right";

export type ScrollInstructionDetails = {
  message: string;
  placement: ScrollInstructionPlacement;
};

/**
 * An element is "visible" if it has a non-zero box and is not hidden via
 * `visibility: hidden` or `display: none`. Opacity is intentionally NOT
 * checked — opacity-0 click targets are a common host-page pattern.
 */
export const isElementVisible = (element: Element): boolean => {
  const rect = element.getBoundingClientRect();
  if (rect.width === 0 || rect.height === 0) return false;
  const style = window.getComputedStyle(element);
  return style.visibility !== "hidden" && style.display !== "none";
};

export const isElementInViewport = (element: Element): boolean => {
  const rect = element.getBoundingClientRect();
  const viewHeight = window.innerHeight || document.documentElement.clientHeight;
  const viewWidth = window.innerWidth || document.documentElement.clientWidth;
  return rect.top >= 0 && rect.left >= 0 && rect.bottom <= viewHeight && rect.right <= viewWidth;
};

const resolveScrollInstruction = (fallback: string, overrideValue?: string): string => {
  return typeof overrideValue === "string" && overrideValue.trim()
    ? overrideValue.trim()
    : fallback;
};

export const getScrollInstructionDetails = (
  element: Element,
  overlayCopy?: SdkReplayOverlayCopy,
): ScrollInstructionDetails => {
  const rect = element.getBoundingClientRect();
  const viewHeight = window.innerHeight || document.documentElement.clientHeight;
  const viewWidth = window.innerWidth || document.documentElement.clientWidth;
  if (rect.top < 0) {
    return {
      message: resolveScrollInstruction(
        "Scroll up to the highlighted element",
        overlayCopy?.scrollUp,
      ),
      placement: "top",
    };
  }
  if (rect.bottom > viewHeight) {
    return {
      message: resolveScrollInstruction(
        "Scroll down to the highlighted element",
        overlayCopy?.scrollDown,
      ),
      placement: "bottom",
    };
  }
  if (rect.left < 0) {
    return {
      message: resolveScrollInstruction(
        "Scroll left to the highlighted element",
        overlayCopy?.scrollLeft,
      ),
      placement: "left",
    };
  }
  if (rect.right > viewWidth) {
    return {
      message: resolveScrollInstruction(
        "Scroll right to the highlighted element",
        overlayCopy?.scrollRight,
      ),
      placement: "right",
    };
  }
  return {
    message: resolveScrollInstruction(
      "Scroll to the highlighted element",
      overlayCopy?.scrollGeneric,
    ),
    placement: "top",
  };
};

export const getScrollInstruction = (
  element: Element,
  overlayCopy?: SdkReplayOverlayCopy,
): string => {
  return getScrollInstructionDetails(element, overlayCopy).message;
};

/** Maps a keyboard step kind to the DOM key/code/shift triple to dispatch. */
export const keyboardStepDescriptor = (
  kind: Extract<StepKind, "key enter" | "key tab" | "key shift+tab">,
): { key: string; code: string; shiftKey: boolean } => {
  if (kind === "key enter") return { key: "Enter", code: "Enter", shiftKey: false };
  if (kind === "key tab") return { key: "Tab", code: "Tab", shiftKey: false };
  return { key: "Tab", code: "Tab", shiftKey: true };
};

/**
 * Dispatch a synthetic keydown+keyup pair on `target`. Focuses the target
 * first when it is an HTMLElement so default browser handlers (form
 * submission, focus traversal) can apply.
 */
export const dispatchKeyboardStep = (
  target: Element,
  kind: Extract<StepKind, "key enter" | "key tab" | "key shift+tab">,
): void => {
  const { key, code, shiftKey } = keyboardStepDescriptor(kind);
  if (target instanceof HTMLElement) target.focus();
  target.dispatchEvent(
    new KeyboardEvent("keydown", { key, code, shiftKey, bubbles: true, cancelable: true }),
  );
  target.dispatchEvent(
    new KeyboardEvent("keyup", { key, code, shiftKey, bubbles: true, cancelable: true }),
  );
};

/**
 * Apply a Step's autofill value to an `<input>`, `<textarea>`, `<select>`,
 * or contenteditable target, dispatching the appropriate input/change
 * events. No-op for unsupported elements.
 *
 * Returns true if a value was actually applied so callers can branch on
 * "host page should now reflect this value".
 */
export const applyInputAutofill = (target: Element, value: string): boolean => {
  if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
    target.value = value;
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  if (target instanceof HTMLSelectElement) {
    target.value = value;
    target.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  if (target.getAttribute("contenteditable") === "true") {
    target.textContent = value;
    target.dispatchEvent(new Event("input", { bubbles: true }));
    return true;
  }
  return false;
};

/**
 * Default human-readable instruction text for a step when the recording
 * does not provide one. Shared so the extension and SDK tooltips stay
 * consistent.
 */
export const describeStep = (step: Step): string => {
  switch (step.kind) {
    case "click":
      return "Click this element to continue.";
    case "hover":
      return "Hover this element to continue.";
    case "context-click":
      return "Right-click this element to continue.";
    case "input":
      return step.value ? `Enter: ${step.value}` : "Fill in this field.";
    case "input password":
      return "Enter your password.";
    case "scroll":
      return "Scroll to this section.";
    case "key enter":
      return "Press Enter to continue.";
    case "key tab":
      return "Press Tab to move to the next field.";
    case "key shift+tab":
      return "Press Shift+Tab to move to the previous field.";
    default:
      return "";
  }
};
