/**
 * Shared recorder-side helpers used by both `@flowr/sdk-core`'s
 * `createRecorderEngine` and the FlowR SDK consumer packages
 * (`@celestialsynthesis/flowr-sdk-recorder`, `@flowr/sdk-recorder-local`).
 *
 * Pure DOM, zero state. Lives here so the recording surface stays
 * consistent across embeddable SDKs.
 */

/**
 * True when `event.composedPath()` traverses through `host`, i.e. the
 * event originated inside that host's subtree (including a Shadow DOM).
 * Use this to suppress recording events that came from the recorder UI
 * itself.
 */
export const eventPathIncludes = (event: Event, host: EventTarget): boolean => {
  const path = (event.composedPath?.() ?? []) as EventTarget[];
  return path.some((node) => node === host);
};

type PointerLikeEvent = Pick<MouseEvent, "target" | "composedPath" | "clientX" | "clientY">;

const refineShadowHostTarget = (
  event: Pick<MouseEvent, "clientX" | "clientY">,
  candidate: Element,
): Element => {
  if (!("clientX" in event) || !("clientY" in event)) {
    return candidate;
  }

  const hit = document.elementFromPoint(event.clientX, event.clientY);
  if (!(hit instanceof Element) || hit === candidate) {
    return candidate;
  }

  const candidateRoot = candidate.getRootNode();
  const hitRoot = hit.getRootNode();
  if (candidate.shadowRoot && hitRoot === candidate.shadowRoot) {
    return hit;
  }
  if (candidateRoot instanceof ShadowRoot && candidateRoot.contains(hit)) {
    return hit;
  }
  if (candidate.contains(hit)) {
    return hit;
  }

  return candidate;
};

const firstElementInComposedPath = (path: EventTarget[]): Element | null => {
  for (const node of path) {
    if (node instanceof Element) {
      return node;
    }
    if (node instanceof Text && node.parentElement instanceof Element) {
      return node.parentElement;
    }
  }
  return null;
};

/**
 * Resolve the deepest page element for a pointer/click event. Shadow DOM
 * retargeting can lift `event.target` to a custom-element host even when the
 * user clicked an inner menu item; `composedPath()` and hit-testing recover
 * the real target.
 */
export const resolvePointerEventTarget = (event: PointerLikeEvent): Element | null => {
  const path = (event.composedPath?.() ?? []) as EventTarget[];
  const fromPath = firstElementInComposedPath(path);
  const retargetedTarget = event.target instanceof Element ? event.target : null;

  if (fromPath) {
    const needsShadowRefine =
      (retargetedTarget != null && fromPath !== retargetedTarget) ||
      fromPath.shadowRoot != null ||
      fromPath.getRootNode() instanceof ShadowRoot;
    return needsShadowRefine ? refineShadowHostTarget(event, fromPath) : fromPath;
  }

  if (retargetedTarget) {
    return retargetedTarget;
  }

  return null;
};

export const nodesShareInteractionTarget = (
  baseTarget: Element,
  candidate: Node | null,
): boolean => {
  if (!candidate) return false;
  if (baseTarget === candidate) return true;
  if (baseTarget.contains(candidate)) return true;
  if (candidate instanceof Element && candidate.contains(baseTarget)) return true;

  const baseRoot = baseTarget.getRootNode();
  if (candidate instanceof Element) {
    const candidateRoot = candidate.getRootNode();
    if (baseRoot instanceof ShadowRoot && candidateRoot === baseRoot) {
      return true;
    }
    if (candidateRoot instanceof ShadowRoot && candidateRoot.host === baseTarget) {
      return true;
    }
    if (baseRoot instanceof ShadowRoot && baseRoot.host === candidate) {
      return true;
    }
  }

  return false;
};

export const eventMatchesInteractionTarget = (
  event: PointerLikeEvent,
  baseTarget: Element,
): boolean => {
  const resolved = resolvePointerEventTarget(event);
  if (resolved && nodesShareInteractionTarget(baseTarget, resolved)) {
    return true;
  }

  if (event.target instanceof Node && nodesShareInteractionTarget(baseTarget, event.target)) {
    return true;
  }

  const path = (event.composedPath?.() ?? []) as EventTarget[];
  for (const node of path) {
    if (node instanceof Node && nodesShareInteractionTarget(baseTarget, node)) {
      return true;
    }
  }

  return false;
};

const dispatchPointerPressEvents = (target: HTMLElement): void => {
  const pointerInit: PointerEventInit = {
    bubbles: true,
    cancelable: true,
    composed: true,
    button: 0,
    buttons: 1,
    pointerId: 1,
    pointerType: "mouse",
    isPrimary: true,
  };

  const mouseInit: MouseEventInit = {
    bubbles: true,
    cancelable: true,
    composed: true,
    button: 0,
    buttons: 1,
    detail: 1,
  };

  if (typeof PointerEvent !== "undefined") {
    target.dispatchEvent(new PointerEvent("pointerdown", pointerInit));
  }
  target.dispatchEvent(new MouseEvent("mousedown", mouseInit));
  if (typeof PointerEvent !== "undefined") {
    target.dispatchEvent(
      new PointerEvent("pointerup", {
        ...pointerInit,
        buttons: 0,
      }),
    );
  }
  target.dispatchEvent(
    new MouseEvent("mouseup", {
      ...mouseInit,
      buttons: 0,
    }),
  );
};

const dispatchTouchTapEvents = (target: HTMLElement): void => {
  const touchInit: EventInit = {
    bubbles: true,
    cancelable: true,
    composed: true,
  };

  if (typeof Touch !== "undefined" && typeof TouchEvent !== "undefined") {
    const rect = target.getBoundingClientRect();
    const clientX = rect.left + rect.width / 2;
    const clientY = rect.top + rect.height / 2;
    const touch = new Touch({
      identifier: 0,
      target,
      clientX,
      clientY,
      pageX: clientX + window.scrollX,
      pageY: clientY + window.scrollY,
      screenX: clientX,
      screenY: clientY,
      radiusX: 1,
      radiusY: 1,
      force: 1,
    });
    const touchListInit = {
      touches: [touch],
      targetTouches: [touch],
      changedTouches: [touch],
    };
    target.dispatchEvent(new TouchEvent("touchstart", { ...touchInit, ...touchListInit }));
    target.dispatchEvent(
      new TouchEvent("touchend", {
        ...touchInit,
        touches: [],
        targetTouches: [],
        changedTouches: [touch],
      }),
    );
    return;
  }

  target.dispatchEvent(new Event("touchstart", touchInit));
  target.dispatchEvent(new Event("touchend", touchInit));
};

const shouldUseNativeClickActivation = (target: HTMLElement): boolean => {
  if (target instanceof HTMLAnchorElement || target instanceof HTMLButtonElement) {
    return true;
  }
  if (target instanceof HTMLInputElement) {
    const type = target.type.toLowerCase();
    return type === "button" || type === "submit" || type === "reset";
  }
  const role = target.getAttribute("role");
  return role === "button" || role === "menuitem" || role === "link";
};

const shouldDispatchTouchTap = (target: HTMLElement): boolean => {
  return target.getAttribute("role") === "option";
};

/**
 * Replay a recorded click on a live element, including targets inside Shadow
 * DOM. Uses composed pointer/mouse events and falls back to native `.click()`
 * for elements that rely on default browser activation (anchors, buttons).
 */
export const activateClickTarget = (target: HTMLElement): void => {
  dispatchPointerPressEvents(target);
  if (shouldDispatchTouchTap(target)) {
    dispatchTouchTapEvents(target);
  }
  const inShadowRoot = target.getRootNode() instanceof ShadowRoot;
  if (shouldUseNativeClickActivation(target)) {
    target.click();
    if (!inShadowRoot) {
      return;
    }
  }
  target.dispatchEvent(
    new MouseEvent("click", {
      bubbles: true,
      cancelable: true,
      composed: true,
      button: 0,
      buttons: 0,
      detail: 1,
    }),
  );
};

/**
 * Maps a `KeyboardEvent` to the FlowR step kind it should record, or
 * `null` when the event should not be recorded as a keyboard step.
 *
 * Recognized keys:
 *   - Enter            -> "key enter"
 *   - Tab              -> "key tab"
 *   - Shift+Tab        -> "key shift+tab"
 */
export const keyboardEventToStepKind = (
  event: KeyboardEvent,
): "key enter" | "key tab" | "key shift+tab" | null => {
  if (event.key === "Enter") return "key enter";
  if (event.key === "Tab") return event.shiftKey ? "key shift+tab" : "key tab";
  return null;
};
