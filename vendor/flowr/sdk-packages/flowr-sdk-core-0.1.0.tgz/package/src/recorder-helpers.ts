/**
 * Shared recorder-side helpers used by both `@flowr/sdk-core`'s
 * `createRecorderEngine` and the FlowR SDK consumer packages
 * (`@celestialsynthesis/flowr-sdk-recorder`, `@flowr/sdk-recorder-local`).
 *
 * Pure DOM, zero state. Lives here so the recording surface stays
 * consistent across embeddable SDKs.
 */

/**
 * True when `event.composedPath()` traverses through `host`, i.e. the
 * event originated inside that host's subtree (including a Shadow DOM).
 * Use this to suppress recording events that came from the recorder UI
 * itself.
 */
export const eventPathIncludes = (event: Event, host: EventTarget): boolean => {
  const path = (event.composedPath?.() ?? []) as EventTarget[];
  return path.some((node) => node === host);
};

/**
 * Maps a `KeyboardEvent` to the FlowR step kind it should record, or
 * `null` when the event should not be recorded as a keyboard step.
 *
 * Recognized keys:
 *   - Enter            -> "key enter"
 *   - Tab              -> "key tab"
 *   - Shift+Tab        -> "key shift+tab"
 */
export const keyboardEventToStepKind = (
  event: KeyboardEvent,
): "key enter" | "key tab" | "key shift+tab" | null => {
  if (event.key === "Enter") return "key enter";
  if (event.key === "Tab") return event.shiftKey ? "key shift+tab" : "key tab";
  return null;
};
