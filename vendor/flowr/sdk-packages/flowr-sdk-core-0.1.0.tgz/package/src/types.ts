/**
 * Canonical recording schema used across runtimes. During Phase 1 of the
 * SDK migration this is duplicated with `src/shared/types.ts`; the
 * extension's copy will collapse into a re-export of this file once the
 * kernel migration completes.
 *
 * Keep this file dependency-free — no DOM, no chrome, no third-party
 * imports — so it tree-shakes cleanly into both SDK bundles.
 */

export type SelectorInfo = {
  css: string;
  xpath?: string;
  attributes?: string[];
};

/**
 * Canonical step kinds shared by the FlowR extension and SDK runtimes.
 * The extension re-exports `STEP_KINDS` / `StepKind` from this module
 * so there is exactly one source of truth in the workspace.
 *
 * The Supabase `plan-actions` edge function maintains a parallel copy
 * in `supabase/functions/plan-actions/contracts.ts` because Deno edge
 * functions cannot import workspace packages; keep that list in sync.
 */
export const STEP_KINDS = [
  "click",
  "context-click",
  "navigation",
  "input",
  "input password",
  "hover",
  "scroll",
  "key enter",
  "key tab",
  "key shift+tab",
] as const;

export type StepKind = (typeof STEP_KINDS)[number];

export type SkipConditionType =
  | "element-not-visible"
  | "element-visible"
  | "step-skipped"
  | "step-not-skipped";

export type StepSkipCondition = {
  type: SkipConditionType;
  /** Selector for the element to check visibility of (used by `element-visible`). */
  selector?: SelectorInfo;
  /** Step ID whose skipped status is checked (used by `step-skipped` and `step-not-skipped`). */
  referenceStepId?: string;
  /** Step ID to jump to when condition is met. Empty means end of recording. */
  jumpToStepId: string;
};

export type Step = {
  id: string;
  kind: StepKind;
  url?: string;
  selector?: SelectorInfo;
  value?: string;
  textContent?: string;
  instruction?: string;
  localizedInstructions?: Record<string, string>;
  screenshotDataUrl?: string;
  screenshotUrl?: string;
  timestamp?: number;
  skipCondition?: StepSkipCondition;
  metadata?: Record<string, unknown>;
};

export type RecordingDomainPattern = {
  pattern: string;
  matchSubdomains?: boolean;
};

export type RecordingVisibility = "private" | "public";

export type Recording = {
  id: string;
  title: string;
  startUrl: string;
  steps: Step[];
  createdAt: number;
  updatedAt: number;
  visibility?: RecordingVisibility;
  /** Author / org attribution. */
  ownerId?: string;
  /** Locale codes the recording has localized instructions for. */
  locales?: string[];
  /** Domain patterns the replay engine accepts as matching. */
  domainPatterns?: RecordingDomainPattern[];
  /** Recording schema version — SDK refuses higher than it knows. */
  schemaVersion?: number;
  /** True when the recording exceeds the org's plan storage limit. */
  isOverLimit?: boolean;
};

export type RecorderSettings = {
  captureScreenshots: boolean;
};

export const RECORDING_SCHEMA_VERSION = 1;
