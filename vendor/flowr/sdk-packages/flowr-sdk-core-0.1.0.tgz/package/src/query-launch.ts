import type { SdkQueryLaunch } from "./types";

export const matchesQueryLaunch = (search: string, queryLaunch?: SdkQueryLaunch): boolean => {
  if (!queryLaunch) {
    return false;
  }

  const param = queryLaunch.param.trim();
  if (!param) {
    return false;
  }

  const params = new URLSearchParams(search);
  if (!params.has(param)) {
    return false;
  }

  if (typeof queryLaunch.value !== "string") {
    return true;
  }

  return params.get(param) === queryLaunch.value;
};
