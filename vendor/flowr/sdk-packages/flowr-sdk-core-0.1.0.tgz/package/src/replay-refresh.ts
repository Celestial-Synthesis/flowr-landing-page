import {
  getSafeHttpNavigationUrl,
  navigationTargetReached,
  navigationUrlMatches,
  type NavigationStepMatchMode,
} from "./navigation-url";
import type { Recording } from "./types";

export type ReplayRefreshOptions = {
  enabled?: boolean;
  storageKey?: string;
  ttlMs?: number;
  now?: () => number;
  persistRecording?: boolean;
};

type ScrollRestorationMode = "auto" | "manual";

export type PendingReplayRefresh = {
  version: 1;
  recordingId: string;
  startUrl: string;
  createdAt: number;
  stepIndex?: number;
  sourceUrl?: string;
  matchMode?: NavigationStepMatchMode;
  scrollRestoration?: ScrollRestorationMode;
  recording?: Recording;
};

const DEFAULT_REPLAY_REFRESH_STORAGE_KEY = "flowr:sdk:pending-replay-refresh";
const DEFAULT_REPLAY_REFRESH_TTL_MS = 30_000;

export const SDK_REPLAY_REFRESH_STORAGE_KEY = "flowr:sdk-replay:pending-refresh";
export const SDK_RECORDER_REPLAY_REFRESH_STORAGE_KEY = "flowr:sdk-recorder:pending-refresh";

const isNavigationStepMatchMode = (value: unknown): value is NavigationStepMatchMode => {
  return value === "smart" || value === "loose" || value === "strict";
};

const getSessionStorage = (): Storage | null => {
  try {
    if (typeof sessionStorage === "undefined") {
      return null;
    }
    return sessionStorage;
  } catch {
    return null;
  }
};

const getScrollRestoration = (): ScrollRestorationMode | undefined => {
  try {
    if (typeof window === "undefined" || !("scrollRestoration" in window.history)) {
      return undefined;
    }

    return window.history.scrollRestoration === "manual" ? "manual" : "auto";
  } catch {
    return undefined;
  }
};

const setScrollRestoration = (mode: ScrollRestorationMode): void => {
  try {
    if (typeof window !== "undefined" && "scrollRestoration" in window.history) {
      window.history.scrollRestoration = mode;
    }
  } catch {}
};

const scrollToPageTop = (): void => {
  try {
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
  } catch {
    try {
      window.scrollTo(0, 0);
    } catch {}
  }
};

const prepareReplayRefreshScroll = (): ScrollRestorationMode | undefined => {
  const previousScrollRestoration = getScrollRestoration();
  setScrollRestoration("manual");
  scrollToPageTop();
  return previousScrollRestoration;
};

const restoreReplayRefreshScroll = (previousScrollRestoration?: ScrollRestorationMode): void => {
  if (typeof window === "undefined") {
    return;
  }

  setScrollRestoration("manual");
  scrollToPageTop();

  const finish = (): void => {
    scrollToPageTop();
    if (previousScrollRestoration) {
      setScrollRestoration(previousScrollRestoration);
    }
  };

  try {
    window.requestAnimationFrame(() => {
      scrollToPageTop();
      window.setTimeout(finish, 0);
    });
  } catch {
    window.setTimeout(finish, 0);
  }
};

const readPendingRefresh = (
  storage: Storage,
  key: string,
  now: number,
  ttlMs: number,
): PendingReplayRefresh | null => {
  const raw = storage.getItem(key);
  if (!raw) {
    return null;
  }

  try {
    const parsed = JSON.parse(raw) as Partial<PendingReplayRefresh> | null;
    if (
      !parsed ||
      parsed.version !== 1 ||
      typeof parsed.recordingId !== "string" ||
      typeof parsed.startUrl !== "string" ||
      typeof parsed.createdAt !== "number" ||
      (parsed.sourceUrl !== undefined && typeof parsed.sourceUrl !== "string") ||
      (parsed.matchMode !== undefined && !isNavigationStepMatchMode(parsed.matchMode)) ||
      (parsed.stepIndex !== undefined &&
        (!Number.isInteger(parsed.stepIndex) || parsed.stepIndex < 0)) ||
      (parsed.scrollRestoration !== undefined &&
        parsed.scrollRestoration !== "auto" &&
        parsed.scrollRestoration !== "manual") ||
      now - parsed.createdAt > ttlMs
    ) {
      storage.removeItem(key);
      return null;
    }
    return parsed as PendingReplayRefresh;
  } catch {
    storage.removeItem(key);
    return null;
  }
};

const writePendingRefresh = (
  storage: Storage,
  key: string,
  recording: Recording,
  startUrl: string,
  now: number,
  persistRecording: boolean,
  scrollRestoration?: ScrollRestorationMode,
  stepIndex?: number,
  sourceUrl?: string,
  matchMode?: NavigationStepMatchMode,
): boolean => {
  const normalizedSourceUrl = sourceUrl?.trim();
  const pending: PendingReplayRefresh = {
    version: 1,
    recordingId: recording.id,
    startUrl,
    createdAt: now,
    ...(stepIndex !== undefined ? { stepIndex } : {}),
    ...(normalizedSourceUrl ? { sourceUrl: normalizedSourceUrl } : {}),
    ...(matchMode ? { matchMode } : {}),
    ...(scrollRestoration ? { scrollRestoration } : {}),
    ...(persistRecording ? { recording } : {}),
  };

  try {
    storage.setItem(key, JSON.stringify(pending));
    return true;
  } catch {
    if (!persistRecording) {
      return false;
    }
  }

  try {
    const { recording: _recording, ...fallbackPending } = pending;
    void _recording;
    storage.setItem(key, JSON.stringify(fallbackPending));
    return true;
  } catch {
    return false;
  }
};

export const queuePendingReplayResume = (
  recording: Recording,
  options: ReplayRefreshOptions & {
    targetUrl: string;
    stepIndex?: number;
    prepareScroll?: boolean;
    sourceUrl?: string;
    matchMode?: NavigationStepMatchMode;
  },
): boolean => {
  if (options.enabled === false || typeof window === "undefined") {
    return false;
  }

  const targetUrl = options.targetUrl.trim();
  if (!targetUrl) {
    return false;
  }

  const storage = getSessionStorage();
  if (!storage) {
    return false;
  }

  const key = options.storageKey ?? DEFAULT_REPLAY_REFRESH_STORAGE_KEY;
  const now = options.now?.() ?? Date.now();
  const stepIndex =
    options.stepIndex !== undefined ? Math.max(0, Math.floor(options.stepIndex)) : undefined;
  const scrollRestoration = options.prepareScroll ? prepareReplayRefreshScroll() : undefined;
  const didWrite = writePendingRefresh(
    storage,
    key,
    recording,
    targetUrl,
    now,
    options.persistRecording === true,
    scrollRestoration,
    stepIndex,
    options.sourceUrl,
    options.matchMode,
  );

  if (!didWrite && scrollRestoration) {
    setScrollRestoration(scrollRestoration);
  }

  return didWrite;
};

export const navigateToReplayStartUrlIfNeeded = (
  recording: Recording,
  options: ReplayRefreshOptions & { stepIndex?: number } = {},
): boolean => {
  if (options.enabled === false || typeof window === "undefined") {
    return false;
  }

  const startUrl = getSafeHttpNavigationUrl(recording.startUrl?.trim());
  if (!startUrl || navigationUrlMatches(window.location.href, startUrl, { mode: "strict" })) {
    return false;
  }

  if (
    !queuePendingReplayResume(recording, {
      ...options,
      targetUrl: startUrl,
      stepIndex: options.stepIndex ?? 0,
      prepareScroll: true,
    })
  ) {
    return false;
  }

  window.location.assign(startUrl);
  return true;
};

export const getPendingReplayRefresh = (
  options: ReplayRefreshOptions & { recordingId?: string } = {},
): PendingReplayRefresh | null => {
  if (options.enabled === false || typeof window === "undefined") {
    return null;
  }

  const storage = getSessionStorage();
  if (!storage) {
    return null;
  }

  const key = options.storageKey ?? DEFAULT_REPLAY_REFRESH_STORAGE_KEY;
  const now = options.now?.() ?? Date.now();
  const ttlMs = options.ttlMs ?? DEFAULT_REPLAY_REFRESH_TTL_MS;
  const pending = readPendingRefresh(storage, key, now, ttlMs);
  if (!pending) {
    return null;
  }

  if (options.recordingId && pending.recordingId !== options.recordingId) {
    return null;
  }

  if (
    pending.sourceUrl || pending.matchMode
      ? !navigationTargetReached(window.location.href, pending.startUrl, {
          sourceHref: pending.sourceUrl,
          matchMode: pending.matchMode,
        })
      : !navigationUrlMatches(window.location.href, pending.startUrl, { mode: "strict" })
  ) {
    return null;
  }

  return pending;
};

export const consumePendingReplayRefresh = (
  options: ReplayRefreshOptions & { recordingId?: string } = {},
): PendingReplayRefresh | null => {
  const pending = getPendingReplayRefresh(options);
  if (!pending) {
    return null;
  }

  const storage = getSessionStorage();
  if (!storage) {
    return null;
  }

  storage.removeItem(options.storageKey ?? DEFAULT_REPLAY_REFRESH_STORAGE_KEY);
  restoreReplayRefreshScroll(pending.scrollRestoration);
  return pending;
};

export const refreshPageBeforeReplayIfNeeded = (
  recording: Recording,
  options: ReplayRefreshOptions = {},
): boolean => {
  if (options.enabled === false || typeof window === "undefined") {
    return false;
  }

  const startUrl = recording.startUrl?.trim();
  if (!startUrl || !navigationUrlMatches(window.location.href, startUrl, { mode: "strict" })) {
    return false;
  }

  const storage = getSessionStorage();
  if (!storage) {
    return false;
  }

  const key = options.storageKey ?? DEFAULT_REPLAY_REFRESH_STORAGE_KEY;
  const now = options.now?.() ?? Date.now();
  const ttlMs = options.ttlMs ?? DEFAULT_REPLAY_REFRESH_TTL_MS;
  const pending = consumePendingReplayRefresh({
    enabled: options.enabled,
    storageKey: key,
    ttlMs,
    now: () => now,
    recordingId: recording.id,
  });

  if (pending?.recordingId === recording.id && pending.startUrl === startUrl) {
    return false;
  }

  const scrollRestoration = prepareReplayRefreshScroll();
  if (
    !writePendingRefresh(
      storage,
      key,
      recording,
      startUrl,
      now,
      options.persistRecording === true,
      scrollRestoration,
      undefined,
    )
  ) {
    if (scrollRestoration) {
      setScrollRestoration(scrollRestoration);
    }
    return false;
  }
  window.location.reload();
  return true;
};
