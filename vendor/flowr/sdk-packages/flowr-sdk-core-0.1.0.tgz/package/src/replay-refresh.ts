import { navigationUrlMatches } from "./navigation-url";
import type { Recording } from "./types";

export type ReplayRefreshOptions = {
  enabled?: boolean;
  storageKey?: string;
  ttlMs?: number;
  now?: () => number;
  persistRecording?: boolean;
};

export type PendingReplayRefresh = {
  version: 1;
  recordingId: string;
  startUrl: string;
  createdAt: number;
  recording?: Recording;
};

const DEFAULT_REPLAY_REFRESH_STORAGE_KEY = "flowr:sdk:pending-replay-refresh";
const DEFAULT_REPLAY_REFRESH_TTL_MS = 30_000;

export const SDK_REPLAY_REFRESH_STORAGE_KEY = "flowr:sdk-replay:pending-refresh";
export const SDK_RECORDER_REPLAY_REFRESH_STORAGE_KEY = "flowr:sdk-recorder:pending-refresh";

const getSessionStorage = (): Storage | null => {
  try {
    if (typeof sessionStorage === "undefined") {
      return null;
    }
    return sessionStorage;
  } catch {
    return null;
  }
};

const readPendingRefresh = (
  storage: Storage,
  key: string,
  now: number,
  ttlMs: number,
): PendingReplayRefresh | null => {
  const raw = storage.getItem(key);
  if (!raw) {
    return null;
  }

  try {
    const parsed = JSON.parse(raw) as Partial<PendingReplayRefresh> | null;
    if (
      !parsed ||
      parsed.version !== 1 ||
      typeof parsed.recordingId !== "string" ||
      typeof parsed.startUrl !== "string" ||
      typeof parsed.createdAt !== "number" ||
      now - parsed.createdAt > ttlMs
    ) {
      storage.removeItem(key);
      return null;
    }
    return parsed as PendingReplayRefresh;
  } catch {
    storage.removeItem(key);
    return null;
  }
};

const writePendingRefresh = (
  storage: Storage,
  key: string,
  recording: Recording,
  startUrl: string,
  now: number,
  persistRecording: boolean,
): boolean => {
  const pending: PendingReplayRefresh = {
    version: 1,
    recordingId: recording.id,
    startUrl,
    createdAt: now,
    ...(persistRecording ? { recording } : {}),
  };

  try {
    storage.setItem(key, JSON.stringify(pending));
    return true;
  } catch {
    if (!persistRecording) {
      return false;
    }
  }

  try {
    const { recording: _recording, ...fallbackPending } = pending;
    void _recording;
    storage.setItem(key, JSON.stringify(fallbackPending));
    return true;
  } catch {
    return false;
  }
};

export const getPendingReplayRefresh = (
  options: ReplayRefreshOptions & { recordingId?: string } = {},
): PendingReplayRefresh | null => {
  if (options.enabled === false || typeof window === "undefined") {
    return null;
  }

  const storage = getSessionStorage();
  if (!storage) {
    return null;
  }

  const key = options.storageKey ?? DEFAULT_REPLAY_REFRESH_STORAGE_KEY;
  const now = options.now?.() ?? Date.now();
  const ttlMs = options.ttlMs ?? DEFAULT_REPLAY_REFRESH_TTL_MS;
  const pending = readPendingRefresh(storage, key, now, ttlMs);
  if (!pending) {
    return null;
  }

  if (options.recordingId && pending.recordingId !== options.recordingId) {
    return null;
  }

  if (!navigationUrlMatches(window.location.href, pending.startUrl, { mode: "strict" })) {
    return null;
  }

  return pending;
};

export const consumePendingReplayRefresh = (
  options: ReplayRefreshOptions & { recordingId?: string } = {},
): PendingReplayRefresh | null => {
  const pending = getPendingReplayRefresh(options);
  if (!pending) {
    return null;
  }

  const storage = getSessionStorage();
  if (!storage) {
    return null;
  }

  storage.removeItem(options.storageKey ?? DEFAULT_REPLAY_REFRESH_STORAGE_KEY);
  return pending;
};

export const refreshPageBeforeReplayIfNeeded = (
  recording: Recording,
  options: ReplayRefreshOptions = {},
): boolean => {
  if (options.enabled === false || typeof window === "undefined") {
    return false;
  }

  const startUrl = recording.startUrl?.trim();
  if (!startUrl || !navigationUrlMatches(window.location.href, startUrl, { mode: "strict" })) {
    return false;
  }

  const storage = getSessionStorage();
  if (!storage) {
    return false;
  }

  const key = options.storageKey ?? DEFAULT_REPLAY_REFRESH_STORAGE_KEY;
  const now = options.now?.() ?? Date.now();
  const ttlMs = options.ttlMs ?? DEFAULT_REPLAY_REFRESH_TTL_MS;
  const pending = consumePendingReplayRefresh({
    enabled: options.enabled,
    storageKey: key,
    ttlMs,
    now: () => now,
    recordingId: recording.id,
  });

  if (pending?.recordingId === recording.id && pending.startUrl === startUrl) {
    return false;
  }

  if (
    !writePendingRefresh(storage, key, recording, startUrl, now, options.persistRecording === true)
  ) {
    return false;
  }
  window.location.reload();
  return true;
};
