/**
 * SDK recorder engine — captures basic interactions on the host page.
 *
 * MVP step kinds: click, input, navigation, key enter / key tab /
 * key shift+tab.
 *
 * Ignores events originating inside the SDK shadow root (the recorder UI
 * itself) by checking event.composedPath() for the bubble host.
 *
 * When `promptInstruction` is provided, left-click is intercepted (the
 * page's own click handler is suppressed) and the engine awaits the
 * instruction prompt before recording the step. This matches the FlowR
 * extension's interactive recording flow. When `promptInstruction` is
 * omitted, clicks pass through and are recorded passively.
 */

import { buildSelectorInfo } from "./selector";
import { eventPathIncludes, keyboardEventToStepKind } from "./recorder-helpers";
import type { Step, StepKind } from "./types";

export type RecorderEngineOptions = {
  /** The bubble host element — events whose path includes it are ignored. */
  ignoreHost: HTMLElement;
  randomId(): string;
  now(): number;
  onStep(step: Step): void;
  /**
   * When provided, the engine intercepts left-clicks on non-editable
   * targets and awaits this callback before recording a step. Returning
   * `null` cancels the step entirely. Returning a string records a click
   * step with that string as `step.instruction`.
   *
   * Editable targets (inputs, textareas, contenteditable) are not
   * intercepted — focus/typing flows through normally and the engine
   * captures `input` steps via the `change` event on commit (blur/Enter).
   */
  promptInstruction?: (target: Element) => Promise<string | null>;
};

export type RecorderEngineHandle = {
  start(): void;
  stop(): void;
  /** True when actively recording. */
  isActive(): boolean;
};

const SUPPORTED_KINDS: StepKind[] = [
  "click",
  "input",
  "input password",
  "key enter",
  "key tab",
  "key shift+tab",
];

/**
 * True for elements that accept text input. Selects intentionally
 * return `false` — they're interactive, but they don't take freeform
 * text and we want clicks on them to flow through the prompt path so
 * users can annotate option-picking like any other click.
 */
const isTextInputTarget = (target: Element): boolean => {
  if (target instanceof HTMLInputElement) {
    const type = (target.type || "text").toLowerCase();
    return type !== "button" && type !== "submit" && type !== "reset" && type !== "file";
  }
  if (target instanceof HTMLTextAreaElement) return true;
  if (target instanceof HTMLSelectElement) return false;
  return target instanceof HTMLElement && target.isContentEditable;
};

const readTextInputValue = (target: Element): string | null => {
  if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
    return target.value;
  }
  if (target instanceof HTMLElement && target.isContentEditable) {
    return target.textContent ?? "";
  }
  return null;
};

export const createRecorderEngine = (opts: RecorderEngineOptions): RecorderEngineHandle => {
  let active = false;
  let pendingPrompt = false;
  let deferredClickTarget: Element | null = null;
  const pendingInputValueByTarget = new WeakMap<Element, string>();
  const lastRecordedInputValueByTarget = new WeakMap<Element, string>();

  const dispatchDeferredClickSequence = (target: Element): void => {
    const pointerInit: PointerEventInit = {
      bubbles: true,
      cancelable: true,
      composed: true,
      button: 0,
      buttons: 1,
      pointerId: 1,
      pointerType: "mouse",
      isPrimary: true,
    };

    const mouseInit: MouseEventInit = {
      bubbles: true,
      cancelable: true,
      composed: true,
      button: 0,
      buttons: 1,
      detail: 1,
    };

    if (target instanceof HTMLElement) {
      try {
        target.focus({ preventScroll: true });
      } catch {
        target.focus();
      }
    }

    if (typeof PointerEvent !== "undefined") {
      target.dispatchEvent(new PointerEvent("pointerdown", pointerInit));
    }
    target.dispatchEvent(new MouseEvent("mousedown", mouseInit));
    if (typeof PointerEvent !== "undefined") {
      target.dispatchEvent(
        new PointerEvent("pointerup", {
          ...pointerInit,
          buttons: 0,
        }),
      );
    }
    target.dispatchEvent(
      new MouseEvent("mouseup", {
        ...mouseInit,
        buttons: 0,
      }),
    );
    target.dispatchEvent(new MouseEvent("click", mouseInit));
  };

  const isFromSdk = (e: Event): boolean => eventPathIncludes(e, opts.ignoreHost);

  const appendInputStep = (target: Element, value: string): void => {
    const isPassword =
      target instanceof HTMLInputElement && target.type.toLowerCase() === "password";
    const selector = buildSelectorInfo(target);
    const step: Step = {
      id: opts.randomId(),
      kind: isPassword ? "input password" : "input",
      url: window.location.href,
      selector,
      value: isPassword ? undefined : value,
      timestamp: opts.now(),
    };
    opts.onStep(step);
    pendingInputValueByTarget.delete(target);
    lastRecordedInputValueByTarget.set(target, value);
  };

  const flushPendingTextInputStep = (target: Element): boolean => {
    if (!isTextInputTarget(target)) {
      return false;
    }

    const pendingValue = pendingInputValueByTarget.get(target);
    if (pendingValue === undefined) {
      return false;
    }

    appendInputStep(target, pendingValue);
    return true;
  };

  const captureClick = (e: MouseEvent): void => {
    if (!active || isFromSdk(e)) return;
    if (e.button !== 0) return;
    const target = e.target as Element | null;
    if (!target || !(target instanceof Element)) return;

    if (!e.isTrusted && deferredClickTarget === target) {
      deferredClickTarget = null;
      return;
    }

    // While a prompt is resolving, swallow further clicks so the page's
    // own click handlers can't fire mid-prompt.
    if (pendingPrompt) {
      e.preventDefault();
      if ("stopImmediatePropagation" in e) e.stopImmediatePropagation();
      e.stopPropagation();
      return;
    }

    const buildClickStep = (instruction?: string): Step => ({
      id: opts.randomId(),
      kind: "click",
      url: window.location.href,
      selector: buildSelectorInfo(target),
      textContent: (target.textContent ?? "").trim().slice(0, 120) || undefined,
      instruction,
      timestamp: opts.now(),
    });

    if (!opts.promptInstruction) {
      opts.onStep(buildClickStep());
      return;
    }

    // Block synchronously so the page can't navigate before we record.
    // Editable targets are blocked too — the prompt UI takes priority over
    // typing. Once the prompt resolves we re-focus the target so the user
    // can continue typing into the field, and `input`/`change` events
    // captured below produce their own steps as usual.
    e.preventDefault();
    if ("stopImmediatePropagation" in e) e.stopImmediatePropagation();
    e.stopPropagation();

    const isTextInput = isTextInputTarget(target);
    let shouldReplayDeferredClick = false;

    pendingPrompt = true;
    void opts
      .promptInstruction(target)
      .then((instruction) => {
        if (instruction !== null) {
          opts.onStep(buildClickStep(instruction || undefined));
          shouldReplayDeferredClick = !isTextInput;
        }
        if (isTextInput && target instanceof HTMLElement) {
          // Restore focus the page would have gotten naturally on click.
          try {
            target.focus({ preventScroll: true });
          } catch {
            target.focus();
          }
        }
      })
      .finally(() => {
        pendingPrompt = false;
        if (shouldReplayDeferredClick) {
          deferredClickTarget = target;
          dispatchDeferredClickSequence(target);
          if (deferredClickTarget === target) {
            deferredClickTarget = null;
          }
        }
      });
  };

  const captureChange = (e: Event): void => {
    if (!active || isFromSdk(e)) return;
    if (pendingPrompt) return;
    const target = e.target as Element | null;
    if (!target || !(target instanceof Element) || !isTextInputTarget(target)) return;

    const pendingValue = pendingInputValueByTarget.get(target);
    const currentValue = readTextInputValue(target);
    const valueToRecord = pendingValue ?? currentValue;
    if (valueToRecord === null) return;

    if (
      pendingValue === undefined &&
      lastRecordedInputValueByTarget.get(target) === valueToRecord
    ) {
      return;
    }

    appendInputStep(target, valueToRecord);
  };

  const captureInput = (e: Event): void => {
    if (!active || isFromSdk(e)) return;
    if (pendingPrompt) return;
    const target = e.target as Element | null;
    if (!target || !(target instanceof Element) || !isTextInputTarget(target)) return;
    const currentValue = readTextInputValue(target);
    if (currentValue === null) return;
    pendingInputValueByTarget.set(target, currentValue);
  };

  /**
   * Capture Tab / Shift+Tab / Enter as discrete keyboard steps so
   * replay can re-issue the same focus / submit semantics. Mirrors the
   * extension's `key enter` / `key tab` / `key shift+tab` step kinds.
   */
  const captureKeydown = (e: KeyboardEvent): void => {
    if (!active || isFromSdk(e)) return;
    if (pendingPrompt) return;
    const kind = keyboardEventToStepKind(e);
    if (!kind) return;
    const target = e.target as Element | null;
    if (target instanceof Element && isTextInputTarget(target)) {
      flushPendingTextInputStep(target);
    }
    const selector = target instanceof Element ? buildSelectorInfo(target) : undefined;
    const step: Step = {
      id: opts.randomId(),
      kind,
      url: window.location.href,
      selector,
      timestamp: opts.now(),
    };
    opts.onStep(step);
  };

  return {
    start() {
      if (active) return;
      active = true;
      document.addEventListener("click", captureClick, true);
      document.addEventListener("input", captureInput, true);
      document.addEventListener("change", captureChange, true);
      document.addEventListener("keydown", captureKeydown, true);
    },
    stop() {
      if (!active) return;
      active = false;
      pendingPrompt = false;
      document.removeEventListener("click", captureClick, true);
      document.removeEventListener("input", captureInput, true);
      document.removeEventListener("change", captureChange, true);
      document.removeEventListener("keydown", captureKeydown, true);
    },
    isActive: () => active,
  };
};

export const recorderSupportedKinds = (): StepKind[] => SUPPORTED_KINDS.slice();
