/**
 * Safe browser storage adapter with quota/availability fallback.
 *
 * Returns the host page's `localStorage` when available and writable.
 * Falls back to an in-memory `Map`-backed shim when localStorage is
 * unavailable (Safari private mode, sandboxed iframes, quota exceeded
 * on probe write). The fallback satisfies the same `SafeStorage`
 * surface so callers don't need to branch on availability.
 *
 * Used by SDK consumers that need a tiny key/value store without
 * the full StorageAdapter surface (which the SDK kernel does not need
 * for in-page recording).
 */

export type SafeStorage = Pick<Storage, "getItem" | "setItem" | "removeItem">;

/** In-memory shim used when no real storage backend is available. */
export const createMemoryStorage = (): SafeStorage => {
  const m = new Map<string, string>();
  return {
    getItem: (k) => (m.has(k) ? m.get(k)! : null),
    setItem: (k, v) => {
      m.set(k, v);
    },
    removeItem: (k) => {
      m.delete(k);
    },
  };
};

/**
 * Returns `localStorage` when a probe write succeeds; otherwise an
 * in-memory shim. The probe handles Safari private mode (throws on
 * setItem) and any other case where reading global localStorage is
 * unsafe.
 */
export const createSafeStorage = (): SafeStorage => {
  try {
    if (typeof localStorage !== "undefined") {
      const probe = "__flowr_probe__";
      localStorage.setItem(probe, "1");
      localStorage.removeItem(probe);
      return localStorage;
    }
  } catch {
    /* fall through to memory shim */
  }
  return createMemoryStorage();
};
