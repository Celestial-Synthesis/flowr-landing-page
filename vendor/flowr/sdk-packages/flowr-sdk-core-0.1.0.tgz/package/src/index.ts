import { FLOWR_DEFAULT_ICON_DATA_URL } from "./brand-icon.js";

export { mountBubble } from "./bubble";
export type { BubbleHandle, BubbleOptions } from "./bubble";
export {
  createSdkActivityScope,
  getActiveSdkActivity,
  isSdkActivityBlocked,
} from "./activity-guard";
export type { SdkActivityMode, SdkActivityScope } from "./activity-guard";
export { createMemoryStorage, createSafeStorage, type SafeStorage } from "./safe-storage";
export { createStore } from "./store";
export type { Store, StoreListener } from "./store";
export { createInlineButton } from "./inline-button";
export type { CreateInlineButtonOptions, InlineButtonVariant } from "./inline-button";
export { FLOWR_DEFAULT_ICON_DATA_URL };
export { blobToDataUrl, compressScreenshot, compressScreenshotDataUrl } from "./image-compression";
export type {
  CompressedScreenshot,
  ScreenshotCompressionMode,
  ScreenshotCompressionOptions,
} from "./image-compression";
export type {
  Recording,
  RecordingVisibility,
  SdkReplayOverlayCopy,
  RecorderSettings,
  SdkReplayPickerCopy,
  SdkQueryLaunch,
  SdkTheme,
  SelectorInfo,
  Step,
  StepKind,
  StepSkipCondition,
  SkipConditionType,
  RecordingDomainPattern,
} from "./types";
export { RECORDING_SCHEMA_VERSION, STEP_KINDS } from "./types";
export { matchesQueryLaunch } from "./query-launch";
export { buildSelectorInfo, findElement, getSelectorInfo } from "./selector";
export { createReplayRunner } from "./replay-engine";
export type { ReplayRunnerOptions, ReplayRunnerHandle, ReplayRunnerEvent } from "./replay-engine";
export { evaluateSkipCondition, getStepSkipReferenceCandidates } from "./skip-condition";
export type { SkipConditionContext, SkipConditionResult } from "./skip-condition";
export { mountAnchoredTooltip } from "./replay-tooltip";
export { mountReplayOverlayMessage } from "./replay-tooltip";
export type {
  AnchoredTooltipHandle,
  AnchoredTooltipOptions,
  ReplayOverlayMessageHandle,
} from "./replay-tooltip";
export { createRecorderEngine, recorderSupportedKinds } from "./recorder-engine";
export type { RecorderEngineHandle, RecorderEngineOptions } from "./recorder-engine";
export { WR_HIGHLIGHT_AND_TOOLTIP_CSS } from "./wr-styles";
export {
  getAnchoredTooltipLayout,
  applyAnchoredTooltipLayout,
  trackAnchoredTooltip,
  TOOLTIP_MARGIN_PX,
  TOOLTIP_GAP_PX,
  TOOLTIP_ARROW_MARGIN_PX,
  TOOLTIP_ARROW_HALF_WIDTH_PX,
  TOOLTIP_VIEWPORT_EPSILON_PX,
} from "./anchored-tooltip-layout";
export type {
  AnchoredTooltipLayout,
  AnchoredTooltipLayoutOptions,
  AnchoredTooltipHorizontalAlign,
  AnchoredTooltipTrackerOptions,
} from "./anchored-tooltip-layout";
export {
  DEFAULT_NAVIGATION_STEP_MATCH_MODE,
  NAVIGATION_STEP_MATCH_MODE_FIELD_LABEL,
  NAVIGATION_STEP_MATCH_MODE_OPTIONS,
  NAVIGATION_STEP_MATCH_MODE_SECTION_LABEL,
  getNavigationStepMatchMode,
  getReplayResumeTarget,
  getNavigationStepTarget,
  navigationTargetReached,
  navigationStepTargetMatches,
  navigationUrlMatches,
} from "./navigation-url";
export type {
  NavigationMatchTarget,
  NavigationStepMatchMode,
  NavigationStepMatchModeOption,
  NavigationUrlMatchMode,
  NavigationUrlMatchOptions,
} from "./navigation-url";
export {
  consumePendingReplayRefresh,
  getPendingReplayRefresh,
  navigateToReplayStartUrlIfNeeded,
  queuePendingReplayResume,
  refreshPageBeforeReplayIfNeeded,
  SDK_RECORDER_REPLAY_REFRESH_STORAGE_KEY,
  SDK_REPLAY_REFRESH_STORAGE_KEY,
} from "./replay-refresh";
export type { PendingReplayRefresh, ReplayRefreshOptions } from "./replay-refresh";

export {
  isElementVisible,
  isElementInViewport,
  getScrollInstructionDetails,
  getScrollInstruction,
  keyboardStepDescriptor,
  dispatchKeyboardStep,
  applyInputAutofill,
  describeStep,
} from "./replay-helpers";
export type { ScrollInstructionDetails, ScrollInstructionPlacement } from "./replay-helpers";
export { activateClickTarget, eventMatchesInteractionTarget, eventPathIncludes, keyboardEventToStepKind, nodesShareInteractionTarget, resolvePointerEventTarget } from "./recorder-helpers";
export { isMobileViewport } from "./viewport";
