/**
 * The floating bubble UI shared by the replay and recorder SDKs.
 *
 * Mounts in a Shadow DOM root so host-page CSS can't bleed in. Renders
 * the FlowR icon button; clicking it toggles a panel slot the caller
 * fills with their own content (replay panel or recorder panel).
 *
 * Vanilla DOM only — no Preact in this layer to keep the shell tiny.
 */

import type { AssetsAdapter } from "./platform";
import type { SdkTheme } from "./types";

export type BubbleOptions = {
  assets: AssetsAdapter;
  /** Where the bubble docks. Default: "bottom-right". */
  position?: "bottom-right" | "bottom-left" | "top-right" | "top-left";
  /** Pixel offset from the docked edge. Default: 24. */
  offset?: number;
  /** Initial panel state. Default: false. */
  open?: boolean;
  /** Hover/click tooltip on the bubble. */
  tooltip?: string;
  /** Optional theme tokens for the bubble and panel shell. */
  theme?: SdkTheme;
};

export type BubbleHandle = {
  /** Shadow root that hosts the bubble + panel slot. */
  shadowRoot: ShadowRoot;
  /** Panel content container — inject your UI here. */
  panelEl: HTMLElement;
  open(): void;
  close(): void;
  toggle(): void;
  isOpen(): boolean;
  destroy(): void;
};

const POSITIONS: Record<NonNullable<BubbleOptions["position"]>, string> = {
  "bottom-right": "bottom: var(--off); right: var(--off);",
  "bottom-left": "bottom: var(--off); left: var(--off);",
  "top-right": "top: var(--off); right: var(--off);",
  "top-left": "top: var(--off); left: var(--off);",
};

const PANEL_POSITIONS: Record<NonNullable<BubbleOptions["position"]>, string> = {
  "bottom-right": "bottom: 72px; right: 0;",
  "bottom-left": "bottom: 72px; left: 0;",
  "top-right": "top: 72px; right: 0;",
  "top-left": "top: 72px; left: 0;",
};

const PANEL_MOBILE_POSITIONS: Record<NonNullable<BubbleOptions["position"]>, string> = {
  "bottom-right": "bottom: 68px;",
  "bottom-left": "bottom: 68px;",
  "top-right": "top: 68px;",
  "top-left": "top: 68px;",
};

const BUBBLE_OPEN_EVENT = "flowr-sdk:bubble-open";

const createBubbleInstanceId = (): string => {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return `flowr-bubble-${crypto.randomUUID()}`;
  }
  return `flowr-bubble-${Date.now()}-${Math.random().toString(36).slice(2)}`;
};

const applyThemeVariables = (element: HTMLElement, theme?: SdkTheme): void => {
  if (!theme) {
    return;
  }

  const mappings: Array<[keyof SdkTheme, string]> = [
    ["fontFamily", "--flowr-sdk-font-family"],
    ["accentColor", "--flowr-sdk-accent"],
    ["accentForeground", "--flowr-sdk-accent-foreground"],
    ["panelBackground", "--flowr-sdk-panel-background"],
    ["surfaceBackground", "--flowr-sdk-surface-background"],
    ["surfaceMutedBackground", "--flowr-sdk-surface-muted-background"],
    ["panelForeground", "--flowr-sdk-panel-foreground"],
    ["panelBorderColor", "--flowr-sdk-panel-border"],
    ["mutedForeground", "--flowr-sdk-panel-muted"],
    ["bubbleBackground", "--flowr-sdk-bubble-background"],
    ["bubbleForeground", "--flowr-sdk-bubble-foreground"],
    ["bubbleShadow", "--flowr-sdk-bubble-shadow"],
    ["overlayBackground", "--flowr-sdk-overlay-background"],
    ["overlayForeground", "--flowr-sdk-overlay-foreground"],
  ];

  mappings.forEach(([key, variableName]) => {
    const value = theme[key];
    if (typeof value === "string" && value.trim()) {
      element.style.setProperty(variableName, value.trim());
    }
  });
};

const buildShadowCss = (
  position: NonNullable<BubbleOptions["position"]>,
  offset: number,
): string => `
  :host {
    all: initial;
    --flowr-sdk-font-family: "Avenir Next", "Segoe UI", "Helvetica Neue", sans-serif;
    --flowr-sdk-bubble-background: #ffffff;
    --flowr-sdk-bubble-foreground: #111827;
    --flowr-sdk-bubble-shadow: 0 28px 72px rgba(15,23,42,.20), 0 10px 24px rgba(15,23,42,.10);
    --flowr-sdk-panel-background: #ffffff;
  }
  .root {
    position: fixed;
    ${POSITIONS[position]}
    --off: ${offset}px;
    --panel-viewport-width: calc(100vw - var(--off) - var(--off));
    z-index: 2147483646;
    font: 14px/1.4 var(--flowr-sdk-font-family);
    color: var(--flowr-sdk-bubble-foreground);
  }
  .root[data-open="true"] {
    z-index: 2147483648;
  }
  .bubble {
    width: 60px; height: 60px;
    border-radius: 9999px;
    border: 1px solid color-mix(in srgb, var(--flowr-sdk-accent, #8d2e3a) 12%, rgba(255,255,255,.88));
    background-color: var(--flowr-sdk-bubble-background);
    background-image:
      radial-gradient(circle at 30% 20%, rgba(255,255,255,.72), transparent 46%),
      linear-gradient(180deg, color-mix(in srgb, var(--flowr-sdk-bubble-background) 84%, white 16%) 0%, var(--flowr-sdk-bubble-background) 100%);
    color: var(--flowr-sdk-bubble-foreground);
    box-shadow: var(--flowr-sdk-bubble-shadow);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    transition: transform .16s ease, box-shadow .16s ease, border-color .16s ease;
  }
  .bubble:hover {
    transform: translateY(-1px) scale(1.03);
    box-shadow: 0 34px 84px rgba(15,23,42,.22), 0 14px 28px rgba(15,23,42,.12);
  }
  .bubble:active { transform: translateY(0) scale(0.97); }
  .bubble img {
    width: 30px;
    height: 30px;
    display: block;
    object-fit: contain;
    filter: drop-shadow(0 4px 10px rgba(15,23,42,.10));
  }
  .panel {
    position: absolute;
    ${PANEL_POSITIONS[position]}
    box-sizing: border-box;
    width: min(392px, var(--panel-viewport-width));
    min-width: 0;
    max-width: var(--panel-viewport-width);
    max-height: min(70vh, calc(100vh - 96px));
    overflow: auto;
    background-color: var(--flowr-sdk-panel-border, rgba(17,24,39,.08));
    background-image: linear-gradient(180deg, rgba(255,255,255,.38), rgba(255,255,255,.12));
    border-radius: 24px;
    box-shadow: 0 30px 80px rgba(15,23,42,.22), 0 10px 28px rgba(15,23,42,.12);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    padding: 1px;
    display: none;
  }
  .panel[data-open="true"] { display: block; }
  @media (max-width: 480px) {
    .root {
      --off: min(${offset}px, 12px);
      --panel-viewport-width: calc(100vw - var(--off) - var(--off));
    }
    .panel {
      ${PANEL_MOBILE_POSITIONS[position]}
      width: var(--panel-viewport-width);
      max-width: var(--panel-viewport-width);
      max-height: calc(100vh - 92px);
      border-radius: 20px;
    }
  }
`;

export const mountBubble = (opts: BubbleOptions): BubbleHandle => {
  const instanceId = createBubbleInstanceId();
  const host = document.createElement("div");
  host.setAttribute("data-flowr-sdk", "");
  host.style.all = "initial";
  applyThemeVariables(host, opts.theme);
  document.body.appendChild(host);
  const shadow = host.attachShadow({ mode: "open" });

  const style = document.createElement("style");
  style.textContent = buildShadowCss(opts.position ?? "bottom-right", opts.offset ?? 24);
  shadow.appendChild(style);

  if (opts.assets.contentCssText) {
    const contentStyle = document.createElement("style");
    contentStyle.textContent = opts.assets.contentCssText;
    shadow.appendChild(contentStyle);
  }
  if (opts.assets.panelCssText) {
    const panelStyle = document.createElement("style");
    panelStyle.textContent = opts.assets.panelCssText;
    shadow.appendChild(panelStyle);
  }

  const root = document.createElement("div");
  root.className = "root";
  shadow.appendChild(root);

  const panel = document.createElement("div");
  panel.className = "panel";
  panel.setAttribute("data-flowr-panel", "");
  root.appendChild(panel);

  const bubble = document.createElement("button");
  bubble.className = "bubble";
  bubble.type = "button";
  bubble.title = opts.tooltip ?? "FlowR";
  bubble.setAttribute("aria-label", opts.tooltip ?? "FlowR");
  const iconImg = document.createElement("img");
  iconImg.src = opts.assets.iconUrl;
  iconImg.alt = "";
  bubble.appendChild(iconImg);
  root.appendChild(bubble);

  let open = Boolean(opts.open);
  const apply = () => {
    root.setAttribute("data-open", open ? "true" : "false");
    panel.setAttribute("data-open", open ? "true" : "false");
  };
  const announceOpen = () => {
    window.dispatchEvent(new CustomEvent(BUBBLE_OPEN_EVENT, { detail: { instanceId } }));
  };
  const setOpen = (nextOpen: boolean): void => {
    if (nextOpen) {
      announceOpen();
    }
    open = nextOpen;
    apply();
  };
  const onPeerOpen = (event: Event): void => {
    const detail = event instanceof CustomEvent ? event.detail : null;
    if (!detail || detail.instanceId === instanceId || !open) {
      return;
    }
    open = false;
    apply();
  };
  window.addEventListener(BUBBLE_OPEN_EVENT, onPeerOpen);
  apply();

  bubble.addEventListener("click", () => {
    setOpen(!open);
  });

  return {
    shadowRoot: shadow,
    panelEl: panel,
    open: () => {
      setOpen(true);
    },
    close: () => {
      setOpen(false);
    },
    toggle: () => {
      setOpen(!open);
    },
    isOpen: () => open,
    destroy: () => {
      window.removeEventListener(BUBBLE_OPEN_EVENT, onPeerOpen);
      host.remove();
    },
  };
};
