/**
 * The floating bubble UI shared by the replay and recorder SDKs.
 *
 * Mounts in a Shadow DOM root so host-page CSS can't bleed in. Renders
 * the FlowR icon button; clicking it toggles a panel slot the caller
 * fills with their own content (replay panel or recorder panel).
 *
 * Vanilla DOM only — no Preact in this layer to keep the shell tiny.
 */

import type { AssetsAdapter } from "./platform";

export type BubbleOptions = {
  assets: AssetsAdapter;
  /** Where the bubble docks. Default: "bottom-right". */
  position?: "bottom-right" | "bottom-left" | "top-right" | "top-left";
  /** Pixel offset from the docked edge. Default: 24. */
  offset?: number;
  /** Initial panel state. Default: false. */
  open?: boolean;
  /** Hover/click tooltip on the bubble. */
  tooltip?: string;
};

export type BubbleHandle = {
  /** Shadow root that hosts the bubble + panel slot. */
  shadowRoot: ShadowRoot;
  /** Panel content container — inject your UI here. */
  panelEl: HTMLElement;
  open(): void;
  close(): void;
  toggle(): void;
  isOpen(): boolean;
  destroy(): void;
};

const POSITIONS: Record<NonNullable<BubbleOptions["position"]>, string> = {
  "bottom-right": "bottom: var(--off); right: var(--off);",
  "bottom-left": "bottom: var(--off); left: var(--off);",
  "top-right": "top: var(--off); right: var(--off);",
  "top-left": "top: var(--off); left: var(--off);",
};

const PANEL_POSITIONS: Record<NonNullable<BubbleOptions["position"]>, string> = {
  "bottom-right": "bottom: 72px; right: 0;",
  "bottom-left": "bottom: 72px; left: 0;",
  "top-right": "top: 72px; right: 0;",
  "top-left": "top: 72px; left: 0;",
};

const PANEL_MOBILE_POSITIONS: Record<NonNullable<BubbleOptions["position"]>, string> = {
  "bottom-right": "bottom: 68px;",
  "bottom-left": "bottom: 68px;",
  "top-right": "top: 68px;",
  "top-left": "top: 68px;",
};

const buildShadowCss = (
  position: NonNullable<BubbleOptions["position"]>,
  offset: number,
): string => `
  :host { all: initial; }
  .root {
    position: fixed;
    ${POSITIONS[position]}
    --off: ${offset}px;
    --panel-viewport-width: calc(100vw - var(--off) - var(--off));
    z-index: 2147483646;
    font: 14px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
    color: #111827;
  }
  .bubble {
    width: 56px; height: 56px;
    border-radius: 9999px;
    border: none;
    background: #ffffff;
    box-shadow: 0 10px 30px rgba(0,0,0,.18), 0 2px 6px rgba(0,0,0,.08);
    cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    transition: transform .12s ease;
  }
  .bubble:hover { transform: scale(1.05); }
  .bubble:active { transform: scale(0.96); }
  .bubble img { width: 28px; height: 28px; }
  .panel {
    position: absolute;
    ${PANEL_POSITIONS[position]}
    box-sizing: border-box;
    width: min(360px, var(--panel-viewport-width));
    min-width: 0;
    max-width: var(--panel-viewport-width);
    max-height: min(70vh, calc(100vh - 96px));
    overflow: auto;
    background: #ffffff;
    border-radius: 16px;
    box-shadow: 0 24px 60px rgba(0,0,0,.22), 0 4px 12px rgba(0,0,0,.10);
    padding: 0;
    display: none;
  }
  .panel[data-open="true"] { display: block; }
  @media (max-width: 480px) {
    .root {
      --off: min(${offset}px, 12px);
      --panel-viewport-width: calc(100vw - var(--off) - var(--off));
    }
    .panel {
      ${PANEL_MOBILE_POSITIONS[position]}
      width: var(--panel-viewport-width);
      max-width: var(--panel-viewport-width);
      max-height: calc(100vh - 92px);
      border-radius: 14px;
    }
  }
`;

export const mountBubble = (opts: BubbleOptions): BubbleHandle => {
  const host = document.createElement("div");
  host.setAttribute("data-flowr-sdk", "");
  host.style.all = "initial";
  document.body.appendChild(host);
  const shadow = host.attachShadow({ mode: "open" });

  const style = document.createElement("style");
  style.textContent = buildShadowCss(opts.position ?? "bottom-right", opts.offset ?? 24);
  shadow.appendChild(style);

  if (opts.assets.contentCssText) {
    const contentStyle = document.createElement("style");
    contentStyle.textContent = opts.assets.contentCssText;
    shadow.appendChild(contentStyle);
  }
  if (opts.assets.panelCssText) {
    const panelStyle = document.createElement("style");
    panelStyle.textContent = opts.assets.panelCssText;
    shadow.appendChild(panelStyle);
  }

  const root = document.createElement("div");
  root.className = "root";
  shadow.appendChild(root);

  const panel = document.createElement("div");
  panel.className = "panel";
  panel.setAttribute("data-flowr-panel", "");
  root.appendChild(panel);

  const bubble = document.createElement("button");
  bubble.className = "bubble";
  bubble.type = "button";
  bubble.title = opts.tooltip ?? "FlowR";
  bubble.setAttribute("aria-label", opts.tooltip ?? "FlowR");
  const iconImg = document.createElement("img");
  iconImg.src = opts.assets.iconUrl;
  iconImg.alt = "";
  bubble.appendChild(iconImg);
  root.appendChild(bubble);

  let open = Boolean(opts.open);
  const apply = () => {
    panel.setAttribute("data-open", open ? "true" : "false");
  };
  apply();

  bubble.addEventListener("click", () => {
    open = !open;
    apply();
  });

  return {
    shadowRoot: shadow,
    panelEl: panel,
    open: () => {
      open = true;
      apply();
    },
    close: () => {
      open = false;
      apply();
    },
    toggle: () => {
      open = !open;
      apply();
    },
    isOpen: () => open,
    destroy: () => {
      host.remove();
    },
  };
};
