/**
 * Pure layout math for an anchored tooltip — positions a tooltip element
 * against an anchor element while keeping it within the viewport and
 * computing the arrow offset for the host CSS to paint.
 *
 * Lives in sdk-core so the extension and SDK runtimes can share the
 * positioning algorithm. DOM-side glue (event listeners, ResizeObserver,
 * apply-to-element) is also exported below so consumers do not duplicate
 * scroll/resize tracking logic.
 */

export const TOOLTIP_MARGIN_PX = 8;
export const TOOLTIP_GAP_PX = 8;
export const TOOLTIP_ARROW_MARGIN_PX = 24;
export const TOOLTIP_ARROW_HALF_WIDTH_PX = 8;
export const TOOLTIP_VIEWPORT_EPSILON_PX = 0.5;

export type AnchoredTooltipHorizontalAlign = "center" | "anchor-start";

export type AnchoredTooltipLayout = {
  top: number;
  left: number;
  arrowLeft: number;
  shouldPlaceAbove: boolean;
};

export type AnchoredTooltipLayoutOptions = {
  horizontalAlign?: AnchoredTooltipHorizontalAlign;
};

const clamp = (value: number, min: number, max: number): number => {
  if (max < min) return min;
  return Math.min(Math.max(value, min), max);
};

const measureTooltipDimension = (rectValue: number, offsetValue: number): number => {
  return rectValue > 0 ? rectValue : offsetValue;
};

export const getAnchoredTooltipLayout = (
  tooltipElement: HTMLElement,
  anchor: Element,
  options?: AnchoredTooltipLayoutOptions,
): AnchoredTooltipLayout => {
  const anchorRect = anchor.getBoundingClientRect();
  const tooltipRect = tooltipElement.getBoundingClientRect();
  const tooltipStyles = window.getComputedStyle(tooltipElement);
  const tooltipWidth = measureTooltipDimension(tooltipRect.width, tooltipElement.offsetWidth);
  const tooltipHeight = measureTooltipDimension(tooltipRect.height, tooltipElement.offsetHeight);
  const tooltipBorderLeftWidth = Number.parseFloat(tooltipStyles.borderLeftWidth || "0");
  const tooltipBorderRightWidth = Number.parseFloat(tooltipStyles.borderRightWidth || "0");
  const tooltipArrowTrackWidth = Math.max(
    0,
    tooltipWidth - tooltipBorderLeftWidth - tooltipBorderRightWidth,
  );
  const viewportWidth = window.innerWidth;
  const viewportHeight = window.innerHeight;
  const anchorCenterX = anchorRect.left + anchorRect.width / 2;
  const horizontalAlign = options?.horizontalAlign ?? "center";

  const preferredLeft =
    horizontalAlign === "anchor-start" ? anchorRect.left : anchorCenterX - tooltipWidth / 2;
  const maxLeft = viewportWidth - tooltipWidth - TOOLTIP_MARGIN_PX - TOOLTIP_VIEWPORT_EPSILON_PX;
  const left = clamp(preferredLeft, TOOLTIP_MARGIN_PX, maxLeft);

  const belowTop = anchorRect.bottom + TOOLTIP_GAP_PX;
  const aboveTop = anchorRect.top - tooltipHeight - TOOLTIP_GAP_PX;
  const spaceBelow = viewportHeight - anchorRect.bottom - TOOLTIP_GAP_PX - TOOLTIP_MARGIN_PX;
  const spaceAbove = anchorRect.top - TOOLTIP_GAP_PX - TOOLTIP_MARGIN_PX;
  const shouldPlaceAbove = spaceBelow < tooltipHeight && spaceAbove > spaceBelow;
  const preferredTop = shouldPlaceAbove ? aboveTop : belowTop;
  const maxTop = viewportHeight - tooltipHeight - TOOLTIP_MARGIN_PX - TOOLTIP_VIEWPORT_EPSILON_PX;
  const top = clamp(preferredTop, TOOLTIP_MARGIN_PX, maxTop);

  const arrowLeft = clamp(
    anchorCenterX - left - tooltipBorderLeftWidth - TOOLTIP_ARROW_HALF_WIDTH_PX,
    TOOLTIP_ARROW_MARGIN_PX,
    Math.max(
      TOOLTIP_ARROW_MARGIN_PX,
      tooltipArrowTrackWidth - TOOLTIP_ARROW_MARGIN_PX - TOOLTIP_ARROW_HALF_WIDTH_PX * 2,
    ),
  );

  return {
    top,
    left,
    arrowLeft,
    shouldPlaceAbove,
  };
};

/**
 * Apply layout output from `getAnchoredTooltipLayout` to a tooltip element:
 * toggles the `is-above` class, sets the `--wr-tooltip-arrow-left` CSS var,
 * and writes `top`/`left` styles. Shared with `@flowr/sdk-core`-based
 * runtimes so the extension and SDK render identically.
 */
export const applyAnchoredTooltipLayout = (
  tooltipElement: HTMLElement,
  anchor: Element,
  options?: AnchoredTooltipLayoutOptions,
): AnchoredTooltipLayout => {
  const layout = getAnchoredTooltipLayout(tooltipElement, anchor, options);

  tooltipElement.classList.toggle("is-above", layout.shouldPlaceAbove);
  tooltipElement.style.setProperty("--wr-tooltip-arrow-left", `${layout.arrowLeft}px`);
  tooltipElement.style.top = `${layout.top}px`;
  tooltipElement.style.left = `${layout.left}px`;

  return layout;
};

export type AnchoredTooltipTrackerOptions = AnchoredTooltipLayoutOptions & {
  /** Observe the anchor's own size changes via ResizeObserver. */
  observeAnchorResize?: boolean;
};

/**
 * Position `tooltipElement` against `anchor` and keep it positioned while the
 * page scrolls/resizes. Returns a dispose function that removes all listeners.
 *
 * Scroll listener uses capture-phase so nested scroll containers (whose scroll
 * events do not bubble) are also tracked.
 */
export const trackAnchoredTooltip = (
  tooltipElement: HTMLElement,
  anchor: Element,
  options?: AnchoredTooltipTrackerOptions,
): (() => void) => {
  const reposition = (): void => {
    applyAnchoredTooltipLayout(tooltipElement, anchor, options);
  };

  // Two-pass: first lays out, forced reflow, then re-measures so any
  // wrapping/sizing changes from the first pass are accounted for.
  reposition();
  void tooltipElement.offsetHeight;
  reposition();

  const win = tooltipElement.ownerDocument?.defaultView ?? window;
  win.addEventListener("scroll", reposition, { capture: true, passive: true });
  win.addEventListener("resize", reposition, { passive: true });

  let resizeObserver: ResizeObserver | null = null;
  if (options?.observeAnchorResize && typeof ResizeObserver !== "undefined") {
    resizeObserver = new ResizeObserver(reposition);
    resizeObserver.observe(anchor);
  }

  return (): void => {
    win.removeEventListener("scroll", reposition, { capture: true });
    win.removeEventListener("resize", reposition);
    resizeObserver?.disconnect();
  };
};
