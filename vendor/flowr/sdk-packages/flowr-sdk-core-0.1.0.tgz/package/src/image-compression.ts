const MAX_DIMENSION_SCALE_PASSES = 4;
const SCALE_FACTOR_PER_PASS = 0.82;
const MIN_QUALITY = 0.42;
const MAX_QUALITY = 0.95;
const QUALITY_SEARCH_STEPS = 7;
const FAST_SCALE_PASSES = 2;
const FAST_SCALE_FACTOR = 0.9;
const FAST_QUALITY_STEPS = [0.82, 0.72, 0.62, 0.52] as const;

export type ScreenshotCompressionMode = "quality" | "fast";

export type ScreenshotCompressionOptions = {
  mode?: ScreenshotCompressionMode;
};

const toBlobWithQuality = async (
  canvas: OffscreenCanvas,
  type: "image/webp" | "image/jpeg",
  quality: number,
): Promise<Blob> => {
  return canvas.convertToBlob({ type, quality });
};

const pickBestBlobForType = async (
  canvas: OffscreenCanvas,
  type: "image/webp" | "image/jpeg",
  maxBytes: number,
): Promise<Blob | null> => {
  let low = MIN_QUALITY;
  let high = MAX_QUALITY;
  let best: Blob | null = null;

  for (let step = 0; step < QUALITY_SEARCH_STEPS; step += 1) {
    const quality = (low + high) / 2;
    const blob = await toBlobWithQuality(canvas, type, quality);
    if (blob.size <= maxBytes) {
      best = blob;
      low = quality;
    } else {
      high = quality;
    }
  }

  if (best) {
    return best;
  }

  const floorBlob = await toBlobWithQuality(canvas, type, MIN_QUALITY);
  return floorBlob.size <= maxBytes ? floorBlob : null;
};

const pickBestCompressedBlob = async (
  canvas: OffscreenCanvas,
  maxBytes: number,
): Promise<Blob | null> => {
  const preferredTypes: Array<"image/webp" | "image/jpeg"> = ["image/webp", "image/jpeg"];

  for (const type of preferredTypes) {
    const blob = await pickBestBlobForType(canvas, type, maxBytes);
    if (blob && blob.size <= maxBytes) {
      return blob;
    }
  }

  return null;
};

const pickFastCompressedBlob = async (
  canvas: OffscreenCanvas,
  maxBytes: number,
): Promise<Blob | null> => {
  for (const quality of FAST_QUALITY_STEPS) {
    const webp = await toBlobWithQuality(canvas, "image/webp", quality);
    if (webp.size <= maxBytes) {
      return webp;
    }
    const jpeg = await toBlobWithQuality(canvas, "image/jpeg", quality);
    if (jpeg.size <= maxBytes) {
      return jpeg;
    }
  }

  return null;
};

export type CompressedScreenshot = {
  blob: Blob;
  width: number;
  height: number;
};

export const blobToDataUrl = async (blob: Blob): Promise<string> => {
  const arrayBuffer = await blob.arrayBuffer();
  const bytes = new Uint8Array(arrayBuffer);
  let binary = "";
  const chunkSize = 0x8000;

  for (let offset = 0; offset < bytes.length; offset += chunkSize) {
    const chunk = bytes.subarray(offset, offset + chunkSize);
    binary += String.fromCharCode(...chunk);
  }

  const base64 = btoa(binary);
  return `data:${blob.type};base64,${base64}`;
};

export const compressScreenshot = async (
  dataUrl: string,
  maxBytes: number,
  options?: ScreenshotCompressionOptions,
): Promise<CompressedScreenshot> => {
  const mode = options?.mode ?? "quality";
  const response = await fetch(dataUrl);
  const srcBlob = await response.blob();
  const bitmap = await createImageBitmap(srcBlob);

  if (srcBlob.size <= maxBytes) {
    return { blob: srcBlob, width: bitmap.width, height: bitmap.height };
  }

  if (typeof OffscreenCanvas === "undefined") {
    return { blob: srcBlob, width: bitmap.width, height: bitmap.height };
  }

  let width = bitmap.width;
  let height = bitmap.height;

  const maxScalePasses = mode === "fast" ? FAST_SCALE_PASSES : MAX_DIMENSION_SCALE_PASSES;
  const scaleFactor = mode === "fast" ? FAST_SCALE_FACTOR : SCALE_FACTOR_PER_PASS;

  for (let scalePass = 0; scalePass <= maxScalePasses; scalePass++) {
    if (scalePass > 0) {
      width = Math.max(1, Math.round(width * scaleFactor));
      height = Math.max(1, Math.round(height * scaleFactor));
    }

    const canvas = new OffscreenCanvas(width, height);
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Failed to get OffscreenCanvas 2d context");
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(bitmap, 0, 0, width, height);

    const bestBlob =
      mode === "fast"
        ? await pickFastCompressedBlob(canvas, maxBytes)
        : await pickBestCompressedBlob(canvas, maxBytes);
    if (bestBlob) {
      return { blob: bestBlob, width, height };
    }
  }

  const canvas = new OffscreenCanvas(width, height);
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Failed to get OffscreenCanvas 2d context");
  ctx.drawImage(bitmap, 0, 0, width, height);

  return canvas
    .convertToBlob({ type: "image/jpeg", quality: MIN_QUALITY })
    .then((blob) => ({ blob, width, height }));
};

export const compressScreenshotDataUrl = async (
  dataUrl: string,
  maxBytes: number,
  options?: ScreenshotCompressionOptions,
): Promise<string> => {
  const compressed = await compressScreenshot(dataUrl, maxBytes, options);
  return blobToDataUrl(compressed.blob);
};
