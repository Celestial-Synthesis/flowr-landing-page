/**
 * Stable selector generator + resolver shared between the FlowR extension
 * and SDK runtimes.
 *
 * The extension and the SDK both depend on byte-equivalent selector output
 * for any given element so recordings created in one runtime replay reliably
 * in the other. To preserve that guarantee, this is the single source of
 * truth — the extension imports `getSelectorInfo` directly from
 * `@flowr/sdk-core/selector` and the SDK re-exports `buildSelectorInfo`
 * (alias) from `@flowr/sdk-core`.
 *
 * Strategy (in priority order):
 *   1. Stable test attributes (`data-testid`, `data-test`, `data-qa`,
 *      `data-cy`, `data-automation`).
 *   2. Stable `[id]` (excluding runtime-generated IDs).
 *   3. Semantic attributes (`aria-label` with relaxed-prefix fallbacks,
 *      `name`, `role`, `title`, `alt`, `placeholder`).
 *   4. `<a href>` / `<area href>` (skipping query strings + dynamic path
 *      segments).
 *   5. Class chains (filtering CSS-in-JS / hashed class names).
 *   6. Tag + nth-of-type ancestor chain.
 *   7. nth-child ancestor chain as last resort.
 *
 * Plus an XPath fallback for replay engines.
 */

import type { SelectorInfo } from "./types";

const PRIORITY_ATTRIBUTES = [
  "data-testid",
  "data-test",
  "data-qa",
  "data-cy",
  "data-automation",
  "aria-label",
  "name",
  "role",
  "title",
  "alt",
  "placeholder",
];

const cssEscape = (value: string): string => {
  if (typeof CSS !== "undefined" && typeof CSS.escape === "function") {
    return CSS.escape(value);
  }
  return value.replace(/[^a-zA-Z0-9_-]/g, "\\$&");
};

const uniqueSelectors = (selectors: string[]): string[] => {
  return Array.from(new Set(selectors.filter((selector) => selector.length > 0)));
};

const isLikelyStableId = (id: string): boolean => {
  if (!id) return false;
  if (/^[:0-9]/.test(id)) return false;
  if (/^_[A-Za-z0-9]{12,}(?:_\d+)?$/.test(id)) return false;
  const tokenParts = id.split(/[-_]/).filter((part) => part.length > 0);
  const hasHashLikeToken = tokenParts.some((part) => {
    const alphaCount = (part.match(/[a-z]/gi) ?? []).length;
    const digitCount = (part.match(/[0-9]/g) ?? []).length;
    return part.length >= 10 && alphaCount >= 4 && digitCount >= 2;
  });
  if (hasHashLikeToken) return false;
  const compactId = id.replace(/[-_]/g, "");
  const hasMixedCaseHashPattern =
    compactId.length >= 14 &&
    /[a-z]/.test(compactId) &&
    /[A-Z]/.test(compactId) &&
    (/[0-9]/.test(compactId) || id.includes("_"));
  if (hasMixedCaseHashPattern) return false;
  const punctuationCount = (id.match(/[^a-zA-Z0-9_-]/g) ?? []).length;
  return punctuationCount <= Math.floor(id.length / 3);
};

const isLikelyRandomClassName = (className: string): boolean => {
  if (!className) return true;
  if (className.length <= 2 || className.length >= 40) return true;
  if (/^(css|sc|emotion|styled|_|__)[-_]/.test(className)) return true;
  if (/[a-f0-9]{5,}/i.test(className)) return true;
  const alphaCount = (className.match(/[a-zA-Z]/g) ?? []).length;
  const digitCount = (className.match(/[0-9]/g) ?? []).length;
  if (digitCount >= 3 && alphaCount > 0 && digitCount / (alphaCount + digitCount) > 0.4) {
    return true;
  }
  return false;
};

const isUniqueId = (id: string): boolean => {
  if (!id) return false;
  const matches = document.querySelectorAll(`#${cssEscape(id)}`);
  return matches.length === 1;
};

const isLikelyDynamicPathSegment = (segment: string): boolean => {
  if (!segment) return false;
  if (/^\d{4,}$/.test(segment)) return true;
  if (/^[0-9a-f]{8,}$/i.test(segment)) return true;
  if (/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(segment)) {
    return true;
  }

  const alphaCount = (segment.match(/[a-z]/gi) ?? []).length;
  const digitCount = (segment.match(/[0-9]/g) ?? []).length;
  return segment.length >= 10 && alphaCount > 0 && digitCount >= 3;
};

const hasDynamicPathIdentifier = (pathname: string): boolean => {
  const parts = pathname.split("/").filter((part) => part.length > 0);
  return parts.some((part) => isLikelyDynamicPathSegment(part));
};

const buildHrefSelectors = (element: Element): string[] => {
  const tag = element.tagName.toLowerCase();
  if (tag !== "a" && tag !== "area") return [];
  const href = element.getAttribute("href");
  if (!href || !href.trim() || href === "#") return [];

  try {
    const url = new URL(href, document.baseURI);

    if (url.search.length > 0 || hasDynamicPathIdentifier(url.pathname)) {
      return [];
    }

    const selectors: string[] = [];
    selectors.push(`${tag}[href="${cssEscape(href)}"]`);

    const pathname = url.pathname;
    if (pathname && pathname !== "/" && pathname !== href) {
      selectors.push(`${tag}[href^="${cssEscape(pathname)}"]`);
    }

    return selectors;
  } catch {
    return [`${tag}[href="${cssEscape(href)}"]`];
  }
};

const buildAriaLabelSelectors = (element: Element, tag: string): string[] => {
  const value = element.getAttribute("aria-label");
  if (!value || !value.trim()) return [];

  const selectors: string[] = [];
  const trimmed = value.trim();

  selectors.push(`${tag}[aria-label="${cssEscape(trimmed)}"]`);

  const words = trimmed.split(/\s+/);
  if (words.length >= 3) {
    for (const count of [5, 3, 2]) {
      if (words.length > count) {
        const prefix = words.slice(0, count).join(" ");
        selectors.push(`${tag}[aria-label^="${cssEscape(prefix)}"]`);
      }
    }
  }

  const trivialWords = new Set([
    "a",
    "an",
    "the",
    "to",
    "in",
    "on",
    "at",
    "of",
    "for",
    "and",
    "or",
    "is",
    "click",
    "open",
    "close",
    "view",
    "go",
    "show",
    "hide",
    "navigate",
    "select",
    "submit",
    "cancel",
    "save",
    "edit",
    "delete",
    "add",
    "remove",
    "new",
    "more",
    "back",
    "next",
    "previous",
    "yes",
    "no",
    "ok",
    "done",
  ]);
  const significantWord = words.find((w) => w.length > 2 && !trivialWords.has(w.toLowerCase()));
  if (significantWord && significantWord !== trimmed) {
    selectors.push(`${tag}[aria-label*="${cssEscape(significantWord)}"]`);
  }

  return selectors;
};

const buildAttributeSelectors = (element: Element): string[] => {
  const tag = element.tagName.toLowerCase();
  const selectors: string[] = [];

  for (const hrefSelector of buildHrefSelectors(element)) {
    selectors.push(hrefSelector);
  }

  for (const ariaSelector of buildAriaLabelSelectors(element, tag)) {
    selectors.push(ariaSelector);
  }

  for (const attr of PRIORITY_ATTRIBUTES) {
    if (attr === "aria-label") continue;
    const value = element.getAttribute(attr);
    if (value && value.trim()) {
      selectors.push(`${tag}[${attr}="${cssEscape(value)}"]`);
    }
  }
  return selectors;
};

const buildClassSelectors = (element: Element): string[] => {
  const tag = element.tagName.toLowerCase();
  const classNames = Array.from(element.classList).filter(
    (className) => className.trim().length > 0 && !isLikelyRandomClassName(className),
  );
  if (classNames.length === 0) return [];

  const escapedClasses = classNames.map((className) => cssEscape(className));
  const selectors: string[] = [];

  selectors.push(`${tag}.${escapedClasses[0]}`);
  if (escapedClasses.length >= 2) {
    selectors.push(`${tag}.${escapedClasses.slice(0, 2).join(".")}`);
  }
  if (escapedClasses.length >= 3) {
    selectors.push(`${tag}.${escapedClasses.slice(0, 3).join(".")}`);
  }
  if (escapedClasses.length <= 5) {
    selectors.push(`${tag}.${escapedClasses.join(".")}`);
  }

  return uniqueSelectors(selectors);
};

const getSimpleSelectors = (element: Element): string[] => {
  const tag = element.tagName.toLowerCase();
  const selectors: string[] = [];

  if (element.id && isLikelyStableId(element.id) && isUniqueId(element.id)) {
    selectors.push(`${tag}#${cssEscape(element.id)}`);
  }

  for (const attrSelector of buildAttributeSelectors(element)) {
    selectors.push(attrSelector);
  }

  for (const classSelector of buildClassSelectors(element)) {
    selectors.push(classSelector);
  }

  selectors.push(tag);
  return uniqueSelectors(selectors);
};

const getElementNthOfTypeSelector = (element: Element): string => {
  const tag = element.tagName.toLowerCase();
  const parentElement = element.parentElement;
  if (!parentElement) return tag;
  const siblings = Array.from(parentElement.children) as Element[];
  const sameTagSiblings = siblings.filter((child) => child.tagName === element.tagName);
  if (sameTagSiblings.length <= 1) return tag;
  const index = sameTagSiblings.indexOf(element) + 1;
  return `${tag}:nth-of-type(${index})`;
};

const buildSimplestUniqueSelector = (element: Element): string => {
  const directCandidates = getSimpleSelectors(element);
  for (const candidate of directCandidates) {
    if (isUniqueSelector(candidate)) return candidate;
  }

  let ancestor: Element | null = element.parentElement;
  let depth = 0;
  while (ancestor && ancestor.tagName.toLowerCase() !== "html" && depth < 6) {
    const ancestorCandidates = getSimpleSelectors(ancestor);
    for (const ancestorSelector of ancestorCandidates) {
      if (!isUniqueSelector(ancestorSelector)) continue;

      const childCandidates = [...directCandidates, getElementNthOfTypeSelector(element)];
      for (const childSelector of childCandidates) {
        const combined = `${ancestorSelector} ${childSelector}`;
        if (isUniqueSelector(combined)) return combined;
      }
    }
    ancestor = ancestor.parentElement;
    depth += 1;
  }

  const segments: string[] = [];
  let current: Element | null = element;
  while (current && current.tagName.toLowerCase() !== "html") {
    const tag = current.tagName.toLowerCase();
    if (current.id && isLikelyStableId(current.id) && isUniqueId(current.id)) {
      segments.unshift(`${tag}#${cssEscape(current.id)}`);
      break;
    }
    const parentElement: Element | null = current.parentElement;
    if (!parentElement) break;
    const siblings = Array.from(parentElement.children) as Element[];
    const index = siblings.indexOf(current) + 1;
    segments.unshift(`${tag}:nth-child(${index})`);
    current = parentElement;
  }

  return segments.join(" > ");
};

const buildXPath = (element: Element): string => {
  const segments: string[] = [];
  let current: Element | null = element;
  while (current && current.nodeType === Node.ELEMENT_NODE) {
    const currentElement: Element = current;
    const tag = currentElement.tagName.toLowerCase();
    const parentElement: Element | null = currentElement.parentElement;
    if (!parentElement) {
      if (tag === "html") {
        segments.unshift("html[1]");
      }
      break;
    }

    const siblings = Array.from(parentElement.children) as Element[];
    const sameTagSiblings = siblings.filter((child) => child.tagName === currentElement.tagName);
    const index = sameTagSiblings.indexOf(currentElement) + 1;
    segments.unshift(`${tag}[${index}]`);
    current = parentElement;
  }
  return segments.length > 0 ? `/${segments.join("/")}` : "";
};

const isUniqueSelector = (selector: string): boolean => {
  try {
    return document.querySelectorAll(selector).length === 1;
  } catch {
    return false;
  }
};

export const getSelectorInfo = (element: Element): SelectorInfo => {
  const attributeSelectors = buildAttributeSelectors(element);
  const classSelectors = buildClassSelectors(element);
  const fallbackSelectors = uniqueSelectors([...attributeSelectors, ...classSelectors]);
  const uniqueFallbackSelectors = fallbackSelectors.filter((selector) =>
    isUniqueSelector(selector),
  );
  const css = buildSimplestUniqueSelector(element);
  const xpath = buildXPath(element);
  const replayFallbackSelectors = uniqueFallbackSelectors.filter((selector) => selector !== css);

  return {
    css,
    xpath,
    attributes: replayFallbackSelectors.length ? replayFallbackSelectors : undefined,
  };
};

/**
 * SDK alias for `getSelectorInfo`. Both names point at the same
 * implementation; the duplicate export keeps existing SDK consumers stable
 * while letting extension code use the legacy name.
 */
export const buildSelectorInfo = getSelectorInfo;

const tryQuery = (sel: string): Element | null => {
  try {
    return document.querySelector(sel);
  } catch {
    return null;
  }
};

/**
 * Resolve a `SelectorInfo` to a live DOM element. Tries the primary CSS
 * selector first, then each fallback selector in `attributes`, then the
 * XPath as a last resort.
 */
export const findElement = (info: SelectorInfo): Element | null => {
  const direct = tryQuery(info.css);
  if (direct) return direct;

  if (info.attributes) {
    for (const candidate of info.attributes) {
      const el = tryQuery(candidate);
      if (el) return el;
    }
  }

  if (info.xpath) {
    try {
      const result = document.evaluate(
        info.xpath,
        document,
        null,
        XPathResult.FIRST_ORDERED_NODE_TYPE,
        null,
      );
      const node = result.singleNodeValue;
      if (node && node.nodeType === Node.ELEMENT_NODE) {
        return node as Element;
      }
    } catch {
      // ignore
    }
  }

  return null;
};
