/**
 * @flowr/sdk-core — tiny dependency-free observable store.
 *
 * Replaces ad-hoc `let` + manual rerender patterns in SDK packages
 * (`sdk-recorder`, `sdk-recorder-local`) without pulling in RxJS,
 * which would blow the bundle budgets (30 KB gz replay, 80 KB gz
 * recorder).
 *
 * Surface intentionally small:
 *   - value         — synchronous current snapshot.
 *   - set(next)     — replace state.
 *   - update(part)  — shallow-merge partial.
 *   - subscribe(fn) — fires once with current state, then on every
 *                     subsequent change. Returns an unsubscribe fn.
 *
 * Equality is reference-based; if two `set`/`update` calls produce a
 * snapshot that is `===` to the previous one, listeners are skipped.
 * This matches what every consumer here actually wants — `update({})`
 * is a no-op, `update({ panelView })` re-renders only when the value
 * really changed.
 *
 * Listeners that throw are isolated so one bad subscriber can't kill
 * the others.
 */

export type StoreListener<T> = (state: T) => void;

export type Store<T> = {
  /** Current snapshot (synchronous read). */
  readonly value: T;
  /** Replace the entire state. No-op if `===` to current. */
  set(next: T): void;
  /** Shallow-merge partial. No-op if every key is `===` to current. */
  update(partial: Partial<T>): void;
  /**
   * Force-emit current state to all listeners without changing it.
   * Use when state contains mutable references that were mutated in
   * place — `update()` would short-circuit on reference equality.
   */
  notify(): void;
  /**
   * Subscribe to state changes. Listener fires immediately with the
   * current value, then on every subsequent change.
   * Returns an unsubscribe function.
   */
  subscribe(listener: StoreListener<T>): () => void;
};

export const createStore = <T>(initial: T): Store<T> => {
  let state = initial;
  const listeners = new Set<StoreListener<T>>();

  const emit = (): void => {
    for (const listener of [...listeners]) {
      try {
        listener(state);
      } catch {
        /* isolate listener errors so siblings keep working */
      }
    }
  };

  return {
    get value(): T {
      return state;
    },
    set(next: T): void {
      if (next === state) return;
      state = next;
      emit();
    },
    update(partial: Partial<T>): void {
      let changed = false;
      for (const key of Object.keys(partial) as (keyof T)[]) {
        const value = partial[key];
        if (value !== undefined && state[key] !== value) {
          changed = true;
          break;
        }
      }
      if (!changed) return;
      state = { ...state, ...partial };
      emit();
    },
    notify(): void {
      emit();
    },
    subscribe(listener: StoreListener<T>): () => void {
      listeners.add(listener);
      try {
        listener(state);
      } catch {
        /* swallow */
      }
      return () => {
        listeners.delete(listener);
      };
    },
  };
};
