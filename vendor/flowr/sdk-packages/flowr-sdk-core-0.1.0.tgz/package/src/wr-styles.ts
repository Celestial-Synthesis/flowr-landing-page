/**
 * Shared CSS for FlowR recorder/replay overlay surfaces.
 *
 * Single source of truth for `.wr-highlight`, `.wr-tooltip`, and
 * `.wr-input-focus-tooltip`. Both the extension content script and the
 * `@flowr/sdk-*` packages embed this string verbatim so visual drift between
 * the two cannot happen.
 *
 * If a rule is genuinely extension-only (panel chrome, edit-mode UI, flow
 * view, etc.) keep it in `src/panel.css`. Only put rules here when the SDK
 * also needs them.
 */

export const WR_HIGHLIGHT_AND_TOOLTIP_CSS = `
.wr-highlight:not([data-flowr-replay-highlight]) {
  position: fixed;
  pointer-events: none;
  border-radius: 8px;
  box-shadow: 0 0 0 9999px color-mix(in srgb, var(--flowr-sdk-overlay-background, #5a1c24) 34%, transparent);
  border: 2px solid var(--flowr-sdk-accent, #8d2e3a);
  background: color-mix(in srgb, var(--flowr-sdk-panel-background, #ffffff) 16%, transparent);
  backdrop-filter: brightness(1.05);
  z-index: 2147483646;
  opacity: 0;
  transition: opacity 0.2s ease;
}

.wr-tooltip,
.wr-input-focus-tooltip {
  position: fixed;
  z-index: 2147483647;
  max-width: 300px;
  min-width: 100px;
  background: var(--flowr-sdk-surface-background, var(--flowr-sdk-panel-background, #ffffff));
  color: var(--flowr-sdk-panel-foreground, #5a1c24);
  padding: 12px 14px;
  border-radius: 12px;
  border: 1px solid var(--flowr-sdk-panel-border, #e5d3d6);
  font: 13px var(--flowr-sdk-font-family, "Segoe UI", system-ui, -apple-system, Roboto, sans-serif);
  box-shadow: 0 18px 44px color-mix(in srgb, var(--flowr-sdk-accent, #8d2e3a) 18%, transparent), 0 4px 14px rgba(15, 23, 42, 0.10);
  pointer-events: none;
}

.wr-tooltip::before,
.wr-input-focus-tooltip::before {
  content: "";
  position: absolute;
  top: -7px;
  left: var(--wr-tooltip-arrow-left, 20px);
  border-width: 0 8px 8px 8px;
  border-style: solid;
  border-color: transparent transparent var(--flowr-sdk-surface-background, var(--flowr-sdk-panel-background, #ffffff)) transparent;
  filter: drop-shadow(0 -1px 0 var(--flowr-sdk-panel-border, #e5d3d6));
}

.wr-tooltip.is-above::before,
.wr-input-focus-tooltip.is-above::before {
  top: auto;
  bottom: -8px;
  border-width: 8px 8px 0 8px;
  border-color: var(--flowr-sdk-surface-background, var(--flowr-sdk-panel-background, #ffffff)) transparent transparent transparent;
  filter: drop-shadow(0 1px 0 var(--flowr-sdk-panel-border, #e5d3d6));
}

.wr-tooltip textarea {
  width: 100%;
  box-sizing: border-box;
  min-height: 72px;
  border-radius: 10px;
  border: 1px solid var(--flowr-sdk-panel-border, #e5d3d6);
  background: var(--flowr-sdk-surface-muted-background, color-mix(in srgb, var(--flowr-sdk-panel-background, #ffffff) 80%, white 20%));
  color: var(--flowr-sdk-panel-foreground, #5a1c24);
  padding: 8px;
  resize: vertical;
  pointer-events: auto;
}
`;
