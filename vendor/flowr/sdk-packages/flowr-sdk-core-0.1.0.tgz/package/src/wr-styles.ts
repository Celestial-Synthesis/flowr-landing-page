/**
 * Shared CSS for FlowR recorder/replay overlay surfaces.
 *
 * Single source of truth for `.wr-highlight`, `.wr-tooltip`, and
 * `.wr-input-focus-tooltip`. Both the extension content script and the
 * `@flowr/sdk-*` packages embed this string verbatim so visual drift between
 * the two cannot happen.
 *
 * If a rule is genuinely extension-only (panel chrome, edit-mode UI, flow
 * view, etc.) keep it in `src/panel.css`. Only put rules here when the SDK
 * also needs them.
 */

export const WR_HIGHLIGHT_AND_TOOLTIP_CSS = `
.wr-highlight {
  position: fixed;
  pointer-events: none;
  border-radius: 6px;
  box-shadow: 0 0 0 9999px rgba(10, 10, 10, 0.45);
  border: 2px solid #ffffff;
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: brightness(1.05);
  z-index: 2147483646;
  opacity: 0;
  transition: opacity 0.2s ease;
}

.wr-tooltip,
.wr-input-focus-tooltip {
  position: fixed;
  z-index: 2147483647;
  max-width: 280px;
  min-width: 100px;
  background: #ffffff;
  color: #5a1c24;
  padding: 10px 12px;
  border-radius: 10px;
  border: 1px solid #e5d3d6;
  font: 13px "Segoe UI", system-ui, -apple-system, Roboto, sans-serif;
  box-shadow: 0 8px 24px rgba(141, 46, 58, 0.2);
  pointer-events: none;
}

.wr-tooltip::before,
.wr-input-focus-tooltip::before {
  content: "";
  position: absolute;
  top: -7px;
  left: var(--wr-tooltip-arrow-left, 20px);
  border-width: 0 8px 8px 8px;
  border-style: solid;
  border-color: transparent transparent #ffffff transparent;
  filter: drop-shadow(0 -1px 0 #e5d3d6);
}

.wr-tooltip.is-above::before,
.wr-input-focus-tooltip.is-above::before {
  top: auto;
  bottom: -8px;
  border-width: 8px 8px 0 8px;
  border-color: #ffffff transparent transparent transparent;
  filter: drop-shadow(0 1px 0 #e5d3d6);
}

.wr-tooltip textarea {
  width: 100%;
  box-sizing: border-box;
  min-height: 72px;
  border-radius: 8px;
  border: 1px solid #e5d3d6;
  background: #fffdfd;
  color: #5a1c24;
  padding: 8px;
  resize: vertical;
  pointer-events: auto;
}
`;
