/**
 * Shared inline-styled button helper used by both `@celestialsynthesis/flowr-sdk-recorder`
 * and `@celestialsynthesis/flowr-sdk-replay`. Both packages render small DOM panels via
 * `cssText` (rather than CSS classes) to keep the consumer from having
 * to inject a stylesheet for the bubble panel. This helper centralizes
 * the styling so both packages stay visually consistent and the dedupe
 * tracked in #6 of the SDK refactor review is closed.
 *
 * Note: `@flowr/sdk-ui` uses CSS classes (see
 * `recorder-panel-button.ts`) and intentionally does NOT use this
 * helper — that path is the long-term replacement.
 */

export type InlineButtonVariant = "primary" | "secondary";

const VARIANT_CSS: Record<InlineButtonVariant, string> = {
  primary: "background:#4f46e5;color:#fff;",
  secondary: "background:#e5e7eb;color:#111827;",
};

const BASE_CSS = "padding:8px 12px;border-radius:8px;border:none;cursor:pointer;font-weight:600;";

export type CreateInlineButtonOptions = {
  label: string;
  onClick: () => void;
  variant?: InlineButtonVariant;
  /** Override `data-flowr-action` (defaults to a slug of `label`). */
  action?: string;
  /** Additional cssText appended after the base + variant styles. */
  extraCss?: string;
};

export const createInlineButton = (opts: CreateInlineButtonOptions): HTMLButtonElement => {
  const button = document.createElement("button");
  button.type = "button";
  button.textContent = opts.label;
  button.dataset.flowrAction = opts.action ?? opts.label.toLowerCase().replace(/\s+/g, "-");
  button.style.cssText = BASE_CSS + VARIANT_CSS[opts.variant ?? "primary"] + (opts.extraCss ?? "");
  button.addEventListener("click", opts.onClick);
  return button;
};
