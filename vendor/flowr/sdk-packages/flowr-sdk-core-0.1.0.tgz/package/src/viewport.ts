const MOBILE_VIEWPORT_QUERY = "(max-width: 767px)";

export const isMobileViewport = (targetWindow?: Window): boolean => {
  const currentWindow = targetWindow ?? (typeof window !== "undefined" ? window : undefined);
  if (!currentWindow) {
    return false;
  }

  try {
    if (typeof currentWindow.matchMedia === "function") {
      return currentWindow.matchMedia(MOBILE_VIEWPORT_QUERY).matches;
    }
  } catch {
    return currentWindow.innerWidth <= 767;
  }

  return currentWindow.innerWidth <= 767;
};
