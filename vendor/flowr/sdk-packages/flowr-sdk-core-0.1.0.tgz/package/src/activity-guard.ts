export type SdkActivityMode = "recorder" | "replay";

type SdkActivityState = {
  mode: SdkActivityMode;
  ownerId: string;
  startedAt: number;
};

type FlowrActivityWindow = Window &
  typeof globalThis & {
    __flowrSdkActivityState?: SdkActivityState;
  };

const ACTIVITY_CHANGE_EVENT = "flowr-sdk:activity-change";

const getActivityWindow = (): FlowrActivityWindow | null => {
  if (typeof window === "undefined") {
    return null;
  }
  return window as FlowrActivityWindow;
};

const createActivityOwnerId = (mode: SdkActivityMode): string => {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return `flowr-${mode}-${crypto.randomUUID()}`;
  }
  return `flowr-${mode}-${Date.now()}-${Math.random().toString(36).slice(2)}`;
};

const dispatchActivityChange = (state: SdkActivityState | null): void => {
  const activityWindow = getActivityWindow();
  activityWindow?.dispatchEvent(new CustomEvent(ACTIVITY_CHANGE_EVENT, { detail: state }));
};

export const getActiveSdkActivity = (): SdkActivityState | null => {
  return getActivityWindow()?.__flowrSdkActivityState ?? null;
};

export const isSdkActivityBlocked = (mode: SdkActivityMode, ownerId?: string): boolean => {
  const active = getActiveSdkActivity();
  return Boolean(active && active.ownerId !== ownerId && active.mode !== mode);
};

export type SdkActivityScope = {
  readonly mode: SdkActivityMode;
  readonly ownerId: string;
  acquire: () => boolean;
  release: () => void;
  isBlocked: () => boolean;
  onBlocked: (callback: () => void) => () => void;
};

export type SdkActivityScopeOptions = {
  ownerId?: string;
};

export const createSdkActivityScope = (
  mode: SdkActivityMode,
  options: SdkActivityScopeOptions = {},
): SdkActivityScope => {
  const ownerId = options.ownerId ?? createActivityOwnerId(mode);

  const acquire = (): boolean => {
    const activityWindow = getActivityWindow();
    if (!activityWindow) {
      return true;
    }
    const active = activityWindow.__flowrSdkActivityState;
    if (active && active.ownerId !== ownerId && active.mode !== mode) {
      return false;
    }
    activityWindow.__flowrSdkActivityState = { mode, ownerId, startedAt: Date.now() };
    dispatchActivityChange(activityWindow.__flowrSdkActivityState);
    return true;
  };

  const release = (): void => {
    const activityWindow = getActivityWindow();
    if (!activityWindow) {
      return;
    }
    const active = activityWindow.__flowrSdkActivityState;
    if (!active || active.ownerId !== ownerId || active.mode !== mode) {
      return;
    }
    delete activityWindow.__flowrSdkActivityState;
    dispatchActivityChange(null);
  };

  const isBlocked = (): boolean => isSdkActivityBlocked(mode, ownerId);

  const onBlocked = (callback: () => void): (() => void) => {
    const activityWindow = getActivityWindow();
    if (!activityWindow) {
      return () => {};
    }
    const listener = (): void => {
      if (isBlocked()) {
        callback();
      }
    };
    activityWindow.addEventListener(ACTIVITY_CHANGE_EVENT, listener);
    listener();
    return () => activityWindow.removeEventListener(ACTIVITY_CHANGE_EVENT, listener);
  };

  return { mode, ownerId, acquire, release, isBlocked, onBlocked };
};
