import type { Recording } from "@flowr/sdk-core";
import { sortRecordingsByUpdatedAt, type RecorderKernelStore } from "./recording-store";

export type RecordingLibraryController = {
  setState: (recordings: Recording[]) => Recording[];
  upsert: (recording: Recording) => void;
  remove: (id: string) => void;
  find: (id: string) => Recording | null;
  resolve: (id: string) => Promise<Recording>;
};

export type RecordingLibraryControllerOptions = {
  store: RecorderKernelStore;
  getLibraryRecordings: () => Recording[];
  setLibraryRecordings: (recordings: Recording[]) => void;
};

export const createRecordingLibraryController = ({
  store,
  getLibraryRecordings,
  setLibraryRecordings,
}: RecordingLibraryControllerOptions): RecordingLibraryController => {
  const setState = (recordings: Recording[]): Recording[] => {
    const sorted = sortRecordingsByUpdatedAt(recordings);
    setLibraryRecordings(sorted);
    return sorted;
  };

  const upsert = (recording: Recording): void => {
    setState([
      recording,
      ...getLibraryRecordings().filter((candidate) => candidate.id !== recording.id),
    ]);
  };

  const remove = (id: string): void => {
    setLibraryRecordings(getLibraryRecordings().filter((candidate) => candidate.id !== id));
  };

  const find = (id: string): Recording | null => {
    return getLibraryRecordings().find((candidate) => candidate.id === id) ?? null;
  };

  const resolve = async (id: string): Promise<Recording> => {
    const cached = find(id);
    if (cached) {
      return cached;
    }

    const direct = await store.get(id);
    if (direct) {
      return direct;
    }

    const next = setState(await store.list()).find((candidate) => candidate.id === id);
    if (next) {
      return next;
    }

    throw new Error(`recording not found: ${id}`);
  };

  return {
    setState,
    upsert,
    remove,
    find,
    resolve,
  };
};
