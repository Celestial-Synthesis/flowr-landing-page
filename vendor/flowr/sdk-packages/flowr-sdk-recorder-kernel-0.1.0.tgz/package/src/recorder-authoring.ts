import { buildSelectorInfo, type SelectorInfo, type Step } from "@flowr/sdk-core";
import { createRecorderOverlay, type RecorderOverlayHandle } from "@flowr/sdk-ui";

export type RecorderAuthoringController = {
  overlay: RecorderOverlayHandle;
  pickElement: (onPicked: (selector: SelectorInfo | null) => void) => void;
  isPickingElement: () => boolean;
  destroy: () => void;
};

export type RecorderAuthoringControllerOptions = {
  shadowRoot: ShadowRoot;
  isRecording: () => boolean;
  isFromSdkEvent: (event: Event) => boolean;
  enableContextMenuAuthoring?: boolean;
  enableInputFocusHints?: boolean;
  openBubble: () => void;
  onRecordHover: (target: Element) => void;
  onRecordContextClick: (target: Element) => void;
  onSaveInstruction: (target: Element, instruction: string) => void;
};

export const buildSectionInstructionStep = (target: Element, instruction: string): Step => ({
  id: crypto.randomUUID(),
  kind: "scroll",
  url: window.location.href,
  selector: buildSelectorInfo(target),
  textContent: (target.textContent ?? "").trim().slice(0, 120) || undefined,
  instruction,
  timestamp: Date.now(),
});

export const buildElementStep = (
  kind: Extract<Step["kind"], "hover" | "context-click">,
  target: Element,
): Step => ({
  id: crypto.randomUUID(),
  kind,
  url: window.location.href,
  selector: buildSelectorInfo(target),
  textContent: (target.textContent ?? "").trim().slice(0, 120) || undefined,
  timestamp: Date.now(),
});

const isHintableInput = (target: EventTarget | null): target is HTMLElement => {
  if (!(target instanceof HTMLElement)) return false;
  if (target instanceof HTMLInputElement) {
    const type = (target.type || "text").toLowerCase();
    return (
      type !== "checkbox" &&
      type !== "radio" &&
      type !== "button" &&
      type !== "submit" &&
      type !== "file"
    );
  }
  if (target instanceof HTMLTextAreaElement) return true;
  if (target.isContentEditable) return true;
  return false;
};

export const createRecorderAuthoringController = ({
  shadowRoot,
  isRecording,
  isFromSdkEvent,
  enableContextMenuAuthoring = false,
  enableInputFocusHints = false,
  openBubble,
  onRecordHover,
  onRecordContextClick,
  onSaveInstruction,
}: RecorderAuthoringControllerOptions): RecorderAuthoringController => {
  let isPickingElement = false;

  const overlay = createRecorderOverlay({
    shadowRoot,
    onRecordHover: (target) => {
      if (!enableContextMenuAuthoring) return;
      onRecordHover(target);
    },
    onRecordContextClick: (target) => {
      if (!enableContextMenuAuthoring) return;
      onRecordContextClick(target);
    },
    onSaveInstruction: (target, instruction) => {
      if (!enableContextMenuAuthoring) return;
      onSaveInstruction(target, instruction);
    },
  });

  const pickElement = (onPicked: (selector: SelectorInfo | null) => void): void => {
    if (!enableContextMenuAuthoring) {
      onPicked(null);
      return;
    }

    let resolved = false;

    const finish = (selector: SelectorInfo | null): void => {
      if (resolved) return;
      resolved = true;
      isPickingElement = false;
      window.removeEventListener("click", onClick, true);
      window.removeEventListener("keydown", onKey, true);
      onPicked(selector);
    };

    const onClick = (event: MouseEvent): void => {
      if (isFromSdkEvent(event)) return;
      const target = event.target;
      if (!(target instanceof Element)) return;
      event.preventDefault();
      if ("stopImmediatePropagation" in event) {
        event.stopImmediatePropagation();
      }
      event.stopPropagation();
      finish(buildSelectorInfo(target));
    };

    const onKey = (event: KeyboardEvent): void => {
      if (event.key !== "Escape") return;
      event.preventDefault();
      finish(null);
    };

    isPickingElement = true;
    window.addEventListener("click", onClick, true);
    window.addEventListener("keydown", onKey, true);
  };

  const onDocumentContextMenuCapture = (event: MouseEvent): void => {
    if (!enableContextMenuAuthoring || !isRecording() || isFromSdkEvent(event)) {
      return;
    }

    const target = event.target as Element | null;
    if (!(target instanceof Element)) {
      return;
    }

    event.preventDefault();
    if ("stopImmediatePropagation" in event) {
      event.stopImmediatePropagation();
    }
    event.stopPropagation();
    openBubble();
    overlay.showContextMenu({
      target,
      x: event.clientX,
      y: event.clientY,
    });
  };

  const onDocumentClickCapture = (event: MouseEvent): void => {
    if (isFromSdkEvent(event) || overlay.isPromptingInstruction() || !overlay.isActive()) {
      return;
    }

    event.preventDefault();
    if ("stopImmediatePropagation" in event) {
      event.stopImmediatePropagation();
    }
    event.stopPropagation();
    overlay.hideAll();
  };

  const onDocumentKeydownCapture = (event: KeyboardEvent): void => {
    if (!overlay.isActive() || event.key !== "Escape") {
      return;
    }

    event.preventDefault();
    if ("stopImmediatePropagation" in event) {
      event.stopImmediatePropagation();
    }
    event.stopPropagation();
    overlay.hideAll();
  };

  const onDocumentFocusInCapture = (event: FocusEvent): void => {
    if (!enableInputFocusHints || isFromSdkEvent(event) || !isRecording() || overlay.isActive()) {
      return;
    }

    const target = event.target;
    if (!isHintableInput(target)) {
      overlay.hideInputFocusHint();
      return;
    }

    const isPassword = target instanceof HTMLInputElement && target.type === "password";
    overlay.showInputFocusHint({
      target,
      text: isPassword ? "Type password here" : "Type text here",
    });
  };

  const onDocumentFocusOutCapture = (event: FocusEvent): void => {
    if (!enableInputFocusHints || isFromSdkEvent(event)) return;
    overlay.hideInputFocusHint();
  };

  document.addEventListener("click", onDocumentClickCapture, true);
  document.addEventListener("keydown", onDocumentKeydownCapture, true);
  if (enableContextMenuAuthoring) {
    document.addEventListener("contextmenu", onDocumentContextMenuCapture, true);
  }
  if (enableInputFocusHints) {
    document.addEventListener("focusin", onDocumentFocusInCapture, true);
    document.addEventListener("focusout", onDocumentFocusOutCapture, true);
  }

  return {
    overlay,
    pickElement,
    isPickingElement: () => isPickingElement,
    destroy: () => {
      document.removeEventListener("click", onDocumentClickCapture, true);
      document.removeEventListener("keydown", onDocumentKeydownCapture, true);
      if (enableContextMenuAuthoring) {
        document.removeEventListener("contextmenu", onDocumentContextMenuCapture, true);
      }
      if (enableInputFocusHints) {
        document.removeEventListener("focusin", onDocumentFocusInCapture, true);
        document.removeEventListener("focusout", onDocumentFocusOutCapture, true);
      }
      overlay.destroy();
    },
  };
};
