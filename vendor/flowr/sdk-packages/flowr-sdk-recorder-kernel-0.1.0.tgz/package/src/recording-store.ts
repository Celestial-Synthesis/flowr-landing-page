import type { Recording, RecordingVisibility } from "@flowr/sdk-core";

export type RecorderKernelStore = {
  list: () => Promise<Recording[]>;
  get: (id: string) => Promise<Recording | null>;
  save: (recording: Recording) => Promise<Recording>;
  delete: (id: string) => Promise<void>;
  clear?: () => Promise<void>;
};

export const DEFAULT_RECORDING_TITLE = "Untitled walkthrough";

export const DEFAULT_RECORDING_VISIBILITY: RecordingVisibility = "private";

export const cloneRecording = (recording: Recording | null): Recording | null => {
  if (!recording) return null;
  if (typeof globalThis.structuredClone === "function") {
    return globalThis.structuredClone(recording) as Recording;
  }
  return JSON.parse(JSON.stringify(recording)) as Recording;
};

export const sortRecordingsByUpdatedAt = (recordings: Recording[]): Recording[] => {
  return [...recordings].sort((left, right) => (right.updatedAt ?? 0) - (left.updatedAt ?? 0));
};
