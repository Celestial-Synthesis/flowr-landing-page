import {
  createReplayRunner,
  getReplayResumeTarget,
  isMobileViewport,
  navigateToReplayStartUrlIfNeeded,
  navigationUrlMatches,
  queuePendingReplayResume,
  refreshPageBeforeReplayIfNeeded,
  SDK_RECORDER_REPLAY_REFRESH_STORAGE_KEY,
  type Recording,
  type ReplayRunnerEvent,
  type ReplayRunnerHandle,
  type Step,
} from "@flowr/sdk-core";

export type RecorderReplayController = {
  stop: () => void;
  replay: (
    idOrRecording: string | Recording,
    options?: {
      skipRefreshBeforeReplay?: boolean;
      skipStartUrlNavigation?: boolean;
      startIndex?: number;
    },
  ) => Promise<void>;
};

export type RecorderReplayControllerOptions = {
  shadowRoot: ShadowRoot;
  setBubbleVisible: (visible: boolean) => void;
  resolveRecording: (id: string) => Promise<Recording>;
  applyCurrentRecording: (recording: Recording) => Recording;
  updateReplayState: (patch: {
    replayIndex?: number | null;
    isReplaying?: boolean;
    panelView?: "recorder";
  }) => void;
  notify: () => void;
  onReplayStart?: (recording: Recording) => void;
  onReplayStep?: (index: number, step: Step) => void;
  onReplayComplete?: () => void;
  onReplayError?: (error: unknown) => void;
  refreshBeforeReplay?: boolean;
};

export const createRecorderReplayController = ({
  shadowRoot,
  setBubbleVisible,
  resolveRecording,
  applyCurrentRecording,
  updateReplayState,
  notify,
  onReplayStart,
  onReplayStep,
  onReplayComplete,
  onReplayError,
  refreshBeforeReplay = true,
}: RecorderReplayControllerOptions): RecorderReplayController => {
  let replayer: ReplayRunnerHandle | null = null;
  let activeReplayRecording: Recording | null = null;
  let shouldPersistActiveReplayRecording = false;

  const stop = (): void => {
    replayer?.stop();
    replayer = null;
    activeReplayRecording = null;
    shouldPersistActiveReplayRecording = false;
    updateReplayState({ replayIndex: null, isReplaying: false });
    setBubbleVisible(true);
    notify();
  };

  const onReplayEvent = (event: ReplayRunnerEvent): void => {
    if (event.type === "step") {
      queueResumeForNextPageStep(event.index);
      updateReplayState({ replayIndex: event.index });
      onReplayStep?.(event.index, event.step);
      return;
    }

    if (event.type === "step-error") {
      updateReplayState({ replayIndex: event.index });
      onReplayError?.(event.error);
      return;
    }

    if (event.type === "stopped") {
      replayer = null;
      activeReplayRecording = null;
      shouldPersistActiveReplayRecording = false;
      updateReplayState({ replayIndex: null, isReplaying: false });
      setBubbleVisible(true);
      return;
    }

    replayer = null;
    activeReplayRecording = null;
    shouldPersistActiveReplayRecording = false;
    updateReplayState({ replayIndex: null, isReplaying: false });
    setBubbleVisible(true);
    onReplayComplete?.();
  };

  const queueResumeForNextPageStep = (index: number): void => {
    const recording = activeReplayRecording;
    if (!recording || typeof window === "undefined") {
      return;
    }

    const nextTarget = getReplayResumeTarget(recording, index + 1);
    if (!nextTarget) {
      return;
    }
    if (
      navigationUrlMatches(window.location.href, nextTarget.targetHref, {
        mode: "same-path-query-agnostic",
      })
    ) {
      return;
    }

    queuePendingReplayResume(recording, {
      storageKey: SDK_RECORDER_REPLAY_REFRESH_STORAGE_KEY,
      targetUrl: nextTarget.targetHref,
      stepIndex: index + 1,
      sourceUrl: nextTarget.sourceHref,
      matchMode: nextTarget.matchMode,
      persistRecording: shouldPersistActiveReplayRecording,
    });
  };

  const replay = async (
    idOrRecording: string | Recording,
    options: {
      skipRefreshBeforeReplay?: boolean;
      skipStartUrlNavigation?: boolean;
      startIndex?: number;
    } = {},
  ): Promise<void> => {
    const recording =
      typeof idOrRecording === "string" ? await resolveRecording(idOrRecording) : idOrRecording;

    if (
      !options.skipStartUrlNavigation &&
      navigateToReplayStartUrlIfNeeded(recording, {
        storageKey: SDK_RECORDER_REPLAY_REFRESH_STORAGE_KEY,
        persistRecording: typeof idOrRecording !== "string",
      })
    ) {
      return;
    }

    if (
      !options.skipRefreshBeforeReplay &&
      refreshPageBeforeReplayIfNeeded(recording, {
        enabled: refreshBeforeReplay,
        storageKey: SDK_RECORDER_REPLAY_REFRESH_STORAGE_KEY,
        persistRecording: typeof idOrRecording !== "string",
      })
    ) {
      return;
    }

    stop();
    const next = applyCurrentRecording(recording);
    activeReplayRecording = next;
    shouldPersistActiveReplayRecording = typeof idOrRecording !== "string";
    updateReplayState({ panelView: "recorder", isReplaying: true, replayIndex: null });
    setBubbleVisible(false);
    onReplayStart?.(next);
    const nextReplayer = createReplayRunner({
      recording: next,
      shadowRoot,
      onEvent: onReplayEvent,
    });
    replayer = nextReplayer;
    nextReplayer.start(options.startIndex);
  };

  return {
    stop,
    replay,
  };
};
