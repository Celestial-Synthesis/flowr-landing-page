import {
  createReplayRunner,
  refreshPageBeforeReplayIfNeeded,
  SDK_RECORDER_REPLAY_REFRESH_STORAGE_KEY,
  type Recording,
  type ReplayRunnerEvent,
  type ReplayRunnerHandle,
  type Step,
} from "@flowr/sdk-core";

export type RecorderReplayController = {
  stop: () => void;
  replay: (
    idOrRecording: string | Recording,
    options?: { skipRefreshBeforeReplay?: boolean },
  ) => Promise<void>;
};

export type RecorderReplayControllerOptions = {
  shadowRoot: ShadowRoot;
  openBubble: () => void;
  resolveRecording: (id: string) => Promise<Recording>;
  applyCurrentRecording: (recording: Recording) => Recording;
  updateReplayState: (patch: {
    replayIndex?: number | null;
    isReplaying?: boolean;
    panelView?: "recorder";
  }) => void;
  notify: () => void;
  onReplayStart?: (recording: Recording) => void;
  onReplayStep?: (index: number, step: Step) => void;
  onReplayComplete?: () => void;
  onReplayError?: (error: unknown) => void;
  refreshBeforeReplay?: boolean;
};

export const createRecorderReplayController = ({
  shadowRoot,
  openBubble,
  resolveRecording,
  applyCurrentRecording,
  updateReplayState,
  notify,
  onReplayStart,
  onReplayStep,
  onReplayComplete,
  onReplayError,
  refreshBeforeReplay = true,
}: RecorderReplayControllerOptions): RecorderReplayController => {
  let replayer: ReplayRunnerHandle | null = null;

  const stop = (): void => {
    replayer?.stop();
    replayer = null;
    updateReplayState({ replayIndex: null, isReplaying: false });
    notify();
  };

  const onReplayEvent = (event: ReplayRunnerEvent): void => {
    if (event.type === "step") {
      updateReplayState({ replayIndex: event.index });
      onReplayStep?.(event.index, event.step);
      return;
    }

    if (event.type === "step-error") {
      updateReplayState({ replayIndex: event.index });
      onReplayError?.(event.error);
      return;
    }

    if (event.type === "stopped") {
      replayer = null;
      updateReplayState({ replayIndex: null, isReplaying: false });
      return;
    }

    replayer = null;
    updateReplayState({ replayIndex: null, isReplaying: false });
    onReplayComplete?.();
  };

  const replay = async (
    idOrRecording: string | Recording,
    options: { skipRefreshBeforeReplay?: boolean } = {},
  ): Promise<void> => {
    const recording =
      typeof idOrRecording === "string" ? await resolveRecording(idOrRecording) : idOrRecording;

    if (
      !options.skipRefreshBeforeReplay &&
      refreshPageBeforeReplayIfNeeded(recording, {
        enabled: refreshBeforeReplay,
        storageKey: SDK_RECORDER_REPLAY_REFRESH_STORAGE_KEY,
        persistRecording: typeof idOrRecording !== "string",
      })
    ) {
      return;
    }

    stop();
    const next = applyCurrentRecording(recording);
    updateReplayState({ panelView: "recorder", isReplaying: true, replayIndex: null });
    openBubble();
    onReplayStart?.(next);
    const nextReplayer = createReplayRunner({
      recording: next,
      shadowRoot,
      onEvent: onReplayEvent,
    });
    replayer = nextReplayer;
    nextReplayer.start();
  };

  return {
    stop,
    replay,
  };
};
