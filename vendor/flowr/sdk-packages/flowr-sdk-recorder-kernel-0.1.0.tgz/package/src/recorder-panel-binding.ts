import type {
  Recording,
  RecordingVisibility,
  SelectorInfo,
  StepSkipCondition,
} from "@flowr/sdk-core";
import {
  createRecorderPanel,
  type RecorderPanelAuthState,
  type RecorderPanelState,
} from "@flowr/sdk-ui";
import type { RecorderKernelSnapshot } from "./recorder-kernel";

export type RecorderKernelPanelAuthAdapter = {
  getState: () => RecorderPanelAuthState | undefined;
  onSendCode?: (email: string) => void | Promise<unknown>;
  onVerifyCode?: (code: string) => void | Promise<unknown>;
  onUseDifferentEmail?: () => void | Promise<unknown>;
  onSignOut?: () => void | Promise<unknown>;
};

export type RecorderKernelPanelBinding = {
  render: () => void;
  destroy: () => void;
};

type RecorderKernelPanelApi = {
  panelRoot: HTMLElement;
  subscribe: (listener: (snapshot: RecorderKernelSnapshot) => void) => () => void;
  getSnapshot: () => RecorderKernelSnapshot;
  startRecording: (opts?: {
    title?: string;
    visibility?: RecordingVisibility;
  }) => Promise<Recording>;
  stopRecording: () => Promise<Recording | null>;
  saveCurrentRecording: () => Promise<Recording | null>;
  discardCurrentRecording: () => void;
  getCurrentRecording: () => Recording | null;
  replay: (idOrRecording: string | Recording) => Promise<void>;
  stopReplay: () => void;
  setCaptureScreenshots: (value: boolean) => void;
  bindDraftTitle: (value: string) => void;
  commitTitle: () => void;
  setVisibility: (visibility: RecordingVisibility) => Recording | null;
  updateStepInstruction: (stepId: string, value: string) => void;
  commitStepInstruction: () => void;
  deleteStep: (stepId: string) => void;
  updateStepSkipCondition: (stepId: string, condition: StepSkipCondition | null) => void;
  pickElement: (onPicked: (selector: SelectorInfo | null) => void) => void;
  openLibraryView: () => Promise<void>;
  closeLibraryView: () => void;
  loadRecording: (id: string) => Promise<Recording>;
  deleteRecording: (id: string) => Promise<void>;
};

export type AttachRecorderPanelBindingOptions = {
  kernel: RecorderKernelPanelApi;
  root?: HTMLElement;
  enableElementPicker?: boolean;
  auth?: RecorderKernelPanelAuthAdapter;
};

const buildRecorderPanelState = (
  snapshot: RecorderKernelSnapshot,
  authState?: RecorderPanelAuthState,
): RecorderPanelState => ({
  recording: snapshot.current,
  status: snapshot.status,
  draftTitle: snapshot.draftTitle,
  draftVisibility: snapshot.draftVisibility,
  captureScreenshots: snapshot.captureScreenshots,
  replayIndex: snapshot.replayIndex,
  defaultTitle: snapshot.defaultTitle,
  hasUnsavedChanges: snapshot.hasUnsavedChanges,
  canSave: snapshot.canSave,
  view: snapshot.panelView,
  recordings: snapshot.panelView === "library" ? snapshot.libraryRecordings : undefined,
  ...(authState ? { auth: authState } : {}),
});

const buildRenderSignature = (
  snapshot: RecorderKernelSnapshot,
  authState?: RecorderPanelAuthState,
): string => {
  const current = snapshot.current;
  const currentStepsKey =
    current?.steps
      .map((step) => {
        const screenshotKey = step.screenshotDataUrl
          ? `data:${step.screenshotDataUrl.length}`
          : (step.screenshotUrl ?? "none");
        return `${step.id}:${step.kind}:${screenshotKey}`;
      })
      .join(",") ?? "none";
  const currentKey = current
    ? [
        current.id,
        current.title,
        current.updatedAt,
        current.visibility,
        current.steps.length,
        currentStepsKey,
      ].join("|")
    : "none";
  const recordingsKey = snapshot.libraryRecordings
    .map((recording) => `${recording.id}:${recording.updatedAt}:${recording.steps.length}`)
    .join(",");
  const authKey = authState
    ? [
        authState.isAuthenticated,
        authState.pendingEmail ?? "",
        authState.signInError ?? "",
        authState.sessionEmail ?? "",
        authState.canSignOut ?? false,
      ].join("|")
    : "no-auth";

  return [
    currentKey,
    snapshot.status,
    snapshot.draftTitle,
    snapshot.draftVisibility,
    snapshot.captureScreenshots,
    snapshot.replayIndex,
    snapshot.defaultTitle,
    snapshot.hasUnsavedChanges,
    snapshot.canSave,
    snapshot.panelView,
    recordingsKey,
    authKey,
  ].join("::");
};

export const attachRecorderPanelBinding = ({
  kernel,
  root,
  enableElementPicker = false,
  auth,
}: AttachRecorderPanelBindingOptions): RecorderKernelPanelBinding => {
  const panel = createRecorderPanel({
    root: root ?? kernel.panelRoot,
    handlers: {
      onSendCode: auth?.onSendCode,
      onVerifyCode: auth?.onVerifyCode,
      onUseDifferentEmail: auth?.onUseDifferentEmail,
      onSignOut: auth?.onSignOut,
      onStart: () =>
        kernel.startRecording({
          title: kernel.getSnapshot().draftTitle,
          visibility: kernel.getSnapshot().draftVisibility,
        }),
      onStop: () => kernel.stopRecording(),
      onReplay: () => {
        const current = kernel.getCurrentRecording();
        if (current) {
          return kernel.replay(current);
        }
      },
      onStopReplay: () => {
        kernel.stopReplay();
      },
      onCaptureScreenshotsChange: (value) => {
        kernel.setCaptureScreenshots(value);
      },
      onSave: () => kernel.saveCurrentRecording(),
      onDiscard: () => {
        kernel.discardCurrentRecording();
      },
      onTitleInput: (value) => {
        kernel.bindDraftTitle(value);
      },
      onTitleCommit: () => {
        kernel.commitTitle();
      },
      onVisibilityChange: (value) => {
        kernel.setVisibility(value);
      },
      onStepInstructionInput: (stepId, value) => {
        kernel.updateStepInstruction(stepId, value);
      },
      onStepInstructionCommit: () => {
        kernel.commitStepInstruction();
      },
      onStepDelete: (stepId) => {
        kernel.deleteStep(stepId);
      },
      onStepSkipConditionChange: (stepId, condition) => {
        kernel.updateStepSkipCondition(stepId, condition);
      },
      onPickElement: enableElementPicker
        ? (onPicked) => {
            kernel.pickElement(onPicked);
          }
        : undefined,
      onOpenLibrary: () => kernel.openLibraryView(),
      onCloseLibrary: () => {
        kernel.closeLibraryView();
      },
      onLoadRecording: (id) => kernel.loadRecording(id).then(() => undefined),
      onDeleteRecording: (id) => kernel.deleteRecording(id),
      onReplayRecording: (id) => kernel.replay(id),
    },
  });

  let lastRenderSignature: string | null = null;

  const render = (): void => {
    const snapshot = kernel.getSnapshot();
    if (snapshot.pendingOperation !== null) {
      return;
    }
    const authState = auth?.getState();
    const nextSignature = buildRenderSignature(snapshot, authState);
    if (nextSignature === lastRenderSignature) {
      return;
    }
    lastRenderSignature = nextSignature;
    panel.render(buildRecorderPanelState(snapshot, authState));
  };

  const detach = kernel.subscribe(() => {
    render();
  });

  render();

  return {
    render,
    destroy: () => {
      detach();
      panel.destroy();
    },
  };
};
