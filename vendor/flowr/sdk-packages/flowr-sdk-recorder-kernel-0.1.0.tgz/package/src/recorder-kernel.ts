import {
  createRecorderEngine,
  createStore,
  eventPathIncludes,
  consumePendingReplayRefresh,
  mountBubble,
  RECORDING_SCHEMA_VERSION,
  SDK_RECORDER_REPLAY_REFRESH_STORAGE_KEY,
  type BubbleHandle,
  type Recording,
  type RecordingVisibility,
  type SelectorInfo,
  type Step,
  type StepSkipCondition,
} from "@flowr/sdk-core";
import { type RecorderOverlayHandle, type RecorderPanelStatus } from "@flowr/sdk-ui";
import {
  cloneRecording,
  DEFAULT_RECORDING_TITLE,
  DEFAULT_RECORDING_VISIBILITY,
  type RecorderKernelStore,
} from "./recording-store";
import {
  buildSectionInstructionStep,
  buildElementStep,
  createRecorderAuthoringController,
} from "./recorder-authoring";
import {
  attachRecorderPanelBinding,
  type RecorderKernelPanelAuthAdapter,
  type RecorderKernelPanelBinding,
} from "./recorder-panel-binding";
import {
  deleteRecordingStep,
  formatRecordingMeta as formatRecordingMetaLabel,
  resolveDraftTitle,
  updateRecordingStepInstruction,
  updateRecordingStepSkipCondition,
} from "./recording-step-edits";
import { createRecordingLibraryController } from "./recording-library-controller";
import { createRecorderReplayController } from "./replay-controller";
import { createStepCaptureController } from "./step-capture-controller";

type PendingOperation = "starting" | "saving" | "replaying" | null;

type PanelView = "recorder" | "library";

type KernelStoreState = {
  current: Recording | null;
  hasUnsavedChanges: boolean;
  replayIndex: number | null;
  panelView: PanelView;
  libraryRecordings: Recording[];
  isRecording: boolean;
  isReplaying: boolean;
  pendingOperation: PendingOperation;
};

export type RecorderKernelSnapshot = KernelStoreState & {
  draftTitle: string;
  draftVisibility: RecordingVisibility;
  captureScreenshots: boolean;
  defaultTitle: string;
  defaultVisibility: RecordingVisibility;
  canSave: boolean;
  status: RecorderPanelStatus;
};

export type RecorderKernelHooks = {
  onReady?: () => void;
  onRecordingStarted?: (recording: Recording) => void;
  onStepCaptured?: (recording: Recording, step: Step) => void;
  onStepUpdated?: (recording: Recording, step: Step) => void;
  onCaptureScreenshotsChanged?: (captureScreenshots: boolean) => void;
  onRecordingSaved?: (recording: Recording) => void;
  onRecordingLoaded?: (recording: Recording) => void;
  onReplayStart?: (recording: Recording) => void;
  onReplayStep?: (index: number, step: Step) => void;
  onReplayComplete?: () => void;
  onError?: (error: Error) => void;
};

export type RecorderKernelOptions = {
  store: RecorderKernelStore;
  bubble: {
    defaultIconDataUrl: string;
    iconUrl?: string;
    panelCssText?: string;
    position?: "bottom-right" | "bottom-left" | "top-right" | "top-left";
    tooltip: string;
  };
  captureScreenshots?: boolean;
  interceptClicks?: boolean;
  userId?: string;
  resolveOwnerId?: () => string | undefined;
  authoring?: {
    enableContextMenuAuthoring?: boolean;
    enableInputFocusHints?: boolean;
  };
  onBeforeStartRecording?: () => Promise<void> | void;
  refreshBeforeReplay?: boolean;
  hooks?: RecorderKernelHooks;
};

export type RecorderKernelHandle = {
  readonly bubble: BubbleHandle;
  readonly overlay: RecorderOverlayHandle;
  readonly panelRoot: HTMLElement;
  readonly shadowRoot: ShadowRoot;
  subscribe: (listener: (snapshot: RecorderKernelSnapshot) => void) => () => void;
  getSnapshot: () => RecorderKernelSnapshot;
  open: () => void;
  close: () => void;
  startRecording: (opts?: {
    title?: string;
    visibility?: RecordingVisibility;
  }) => Promise<Recording>;
  stopRecording: () => Promise<Recording | null>;
  saveCurrentRecording: () => Promise<Recording | null>;
  discardCurrentRecording: () => void;
  setVisibility: (visibility: RecordingVisibility) => Recording | null;
  getCurrentRecording: () => Recording | null;
  loadRecording: (id: string) => Promise<Recording>;
  listRecordings: () => Promise<Recording[]>;
  deleteRecording: (id: string) => Promise<void>;
  clearAll: () => Promise<void>;
  replay: (idOrRecording: string | Recording) => Promise<void>;
  stopReplay: () => void;
  setCaptureScreenshots: (value: boolean) => void;
  openLibraryView: () => Promise<void>;
  closeLibraryView: () => void;
  bindDraftTitle: (value: string) => void;
  commitTitle: () => void;
  updateStepInstruction: (stepId: string, value: string) => void;
  commitStepInstruction: () => void;
  deleteStep: (stepId: string) => void;
  updateStepSkipCondition: (stepId: string, condition: StepSkipCondition | null) => void;
  pickElement: (onPicked: (selector: SelectorInfo | null) => void) => void;
  attachSdkUiPanel: (options?: {
    auth?: RecorderKernelPanelAuthAdapter;
  }) => RecorderKernelPanelBinding;
  formatRecordingMeta: (recording: Recording) => string;
  destroy: () => void;
};

export const createRecorderKernel = ({
  store,
  bubble: bubbleOptions,
  captureScreenshots = false,
  interceptClicks = true,
  userId,
  resolveOwnerId,
  authoring,
  onBeforeStartRecording,
  refreshBeforeReplay = true,
  hooks,
}: RecorderKernelOptions): RecorderKernelHandle => {
  const bubble = mountBubble({
    assets: {
      iconUrl: bubbleOptions.iconUrl ?? bubbleOptions.defaultIconDataUrl,
      brandIconUrl: bubbleOptions.iconUrl ?? bubbleOptions.defaultIconDataUrl,
      panelCssText: bubbleOptions.panelCssText ?? "",
      contentCssText: "",
    },
    position: bubbleOptions.position,
    tooltip: bubbleOptions.tooltip,
  });

  const ignoreHost = bubble.shadowRoot.host as HTMLElement;
  const isFromSdkEvent = (event: Event): boolean => eventPathIncludes(event, ignoreHost);

  const panelStore = createStore<KernelStoreState>({
    current: null,
    hasUnsavedChanges: false,
    replayIndex: null,
    panelView: "recorder",
    libraryRecordings: [],
    isRecording: false,
    isReplaying: false,
    pendingOperation: null,
  });

  let draftTitle = DEFAULT_RECORDING_TITLE;
  let draftVisibility = DEFAULT_RECORDING_VISIBILITY;
  let isCaptureScreenshotsEnabled = captureScreenshots;
  let persistedSnapshot: Recording | null = null;
  let attachedPanelBinding: RecorderKernelPanelBinding | null = null;

  const computeStatus = (): RecorderPanelStatus => {
    if (panelStore.value.isRecording) return "recording";
    if (panelStore.value.isReplaying) return "replaying";
    return "idle";
  };
  const getSnapshot = (): RecorderKernelSnapshot => ({
    ...panelStore.value,
    draftTitle,
    draftVisibility,
    captureScreenshots: isCaptureScreenshotsEnabled,
    defaultTitle: DEFAULT_RECORDING_TITLE,
    defaultVisibility: DEFAULT_RECORDING_VISIBILITY,
    canSave: Boolean(panelStore.value.current && panelStore.value.current.steps.length > 0),
    status: computeStatus(),
  });

  const subscribe = (listener: (snapshot: RecorderKernelSnapshot) => void): (() => void) => {
    return panelStore.subscribe(() => {
      listener(getSnapshot());
    });
  };
  const libraryController = createRecordingLibraryController({
    store,
    getLibraryRecordings: () => panelStore.value.libraryRecordings,
    setLibraryRecordings: (recordings) => {
      panelStore.update({ libraryRecordings: recordings });
    },
  });

  const resetCurrentRecording = (): void => {
    persistedSnapshot = null;
    draftTitle = DEFAULT_RECORDING_TITLE;
    draftVisibility = DEFAULT_RECORDING_VISIBILITY;
    panelStore.update({
      current: null,
      hasUnsavedChanges: false,
      replayIndex: null,
      isRecording: false,
      isReplaying: false,
      pendingOperation: null,
    });
  };
  const applyCurrentRecording = (recording: Recording): Recording => {
    const next = cloneRecording(recording) ?? recording;
    persistedSnapshot = cloneRecording(next);
    draftTitle = next.title;
    draftVisibility = next.visibility ?? DEFAULT_RECORDING_VISIBILITY;
    panelStore.update({
      current: next,
      hasUnsavedChanges: false,
      replayIndex: null,
      isRecording: false,
      isReplaying: false,
    });
    return next;
  };
  const emitError = (error: unknown): void => {
    hooks?.onError?.(error as Error);
  };
  let isStepCaptureBlocked = (): boolean => false;
  const stepCaptureController = createStepCaptureController({
    getCaptureScreenshots: () => isCaptureScreenshotsEnabled,
    getCurrentRecording: () => panelStore.value.current,
    isBlocked: () => isStepCaptureBlocked(),
    markUnsavedChanges: () => {
      panelStore.update({ hasUnsavedChanges: true });
    },
    notify: () => {
      panelStore.notify();
    },
    onStepCaptured: hooks?.onStepCaptured,
    onStepUpdated: hooks?.onStepUpdated,
  });
  const authoringController = createRecorderAuthoringController({
    shadowRoot: bubble.shadowRoot,
    isRecording: () => panelStore.value.isRecording,
    isFromSdkEvent,
    enableContextMenuAuthoring: authoring?.enableContextMenuAuthoring === true,
    enableInputFocusHints: authoring?.enableInputFocusHints === true,
    openBubble: () => bubble.open(),
    onRecordHover: (target) => {
      stepCaptureController.appendStep(buildElementStep("hover", target), target);
    },
    onRecordContextClick: (target) => {
      stepCaptureController.appendStep(buildElementStep("context-click", target), target);
    },
    onSaveInstruction: (target, instruction) => {
      stepCaptureController.appendStep(buildSectionInstructionStep(target, instruction), target);
    },
  });
  isStepCaptureBlocked = () => authoringController.isPickingElement();
  const overlay = authoringController.overlay;
  const pickElement = authoringController.pickElement;
  const engine = createRecorderEngine({
    ignoreHost,
    randomId: () => crypto.randomUUID(),
    now: () => Date.now(),
    onStep(step) {
      stepCaptureController.appendStep(step);
    },
    promptInstruction: interceptClicks
      ? (target) =>
          overlay.showInstructionPrompt({
            target,
            title: "Add instruction",
            copy: "Tell viewers what to do at this step.",
            placeholder: "Click the highlighted element",
            defaultInstruction: "Click the highlighted element",
          })
      : undefined,
  });
  const stopEngine = (): void => {
    if (!panelStore.value.isRecording) {
      return;
    }

    engine.stop();
    panelStore.update({ isRecording: false });
  };
  const resolveRecording = async (id: string): Promise<Recording> => {
    return libraryController.resolve(id);
  };
  const replayController = createRecorderReplayController({
    shadowRoot: bubble.shadowRoot,
    openBubble: () => bubble.open(),
    resolveRecording,
    applyCurrentRecording,
    updateReplayState: (patch) => {
      panelStore.update(patch);
    },
    notify: () => {
      panelStore.notify();
    },
    onReplayStart: hooks?.onReplayStart,
    onReplayStep: hooks?.onReplayStep,
    onReplayComplete: hooks?.onReplayComplete,
    onReplayError: emitError,
    refreshBeforeReplay,
  });
  const stopReplay = (): void => replayController.stop();
  const saveCurrentRecording = async (): Promise<Recording | null> => {
    const current = panelStore.value.current;
    if (!current) return null;

    panelStore.update({ pendingOperation: "saving" });
    overlay.hideAll();
    overlay.hideInputFocusHint();
    stopEngine();
    await stepCaptureController.waitForPendingScreenshotCaptures();

    if (current.steps.length === 0) {
      if (persistedSnapshot) {
        const restored = cloneRecording(persistedSnapshot);
        draftTitle = restored?.title ?? DEFAULT_RECORDING_TITLE;
        draftVisibility = restored?.visibility ?? DEFAULT_RECORDING_VISIBILITY;
        panelStore.update({
          current: restored,
          hasUnsavedChanges: false,
          replayIndex: null,
        });
      } else {
        draftTitle = DEFAULT_RECORDING_TITLE;
        draftVisibility = DEFAULT_RECORDING_VISIBILITY;
        panelStore.update({
          current: null,
          hasUnsavedChanges: false,
          replayIndex: null,
        });
      }
      panelStore.update({ pendingOperation: null });
      return null;
    }

    try {
      current.updatedAt = Date.now();
      const currentAtSaveStart = current;
      const snapshotToSave = cloneRecording(currentAtSaveStart)!;
      const saved = await store.save(snapshotToSave);
      const activeCurrent = panelStore.value.current;
      const didSwitchDraft = activeCurrent !== currentAtSaveStart;
      const didEditDuringSave =
        !didSwitchDraft && currentAtSaveStart.updatedAt !== snapshotToSave.updatedAt;

      persistedSnapshot = cloneRecording(saved);
      libraryController.upsert(saved);
      hooks?.onRecordingSaved?.(saved);

      if (didSwitchDraft) {
        return activeCurrent;
      }

      if (didEditDuringSave) {
        currentAtSaveStart.createdAt = saved.createdAt;
        currentAtSaveStart.ownerId = saved.ownerId ?? currentAtSaveStart.ownerId;
        currentAtSaveStart.schemaVersion = saved.schemaVersion ?? currentAtSaveStart.schemaVersion;
        draftTitle = currentAtSaveStart.title;
        draftVisibility = currentAtSaveStart.visibility ?? DEFAULT_RECORDING_VISIBILITY;
        panelStore.update({ hasUnsavedChanges: true, replayIndex: null });
        return currentAtSaveStart;
      }

      draftTitle = saved.title;
      draftVisibility = saved.visibility ?? DEFAULT_RECORDING_VISIBILITY;
      panelStore.update({
        current: saved,
        hasUnsavedChanges: false,
        replayIndex: null,
      });
      return saved;
    } catch (error) {
      emitError(error);
      return panelStore.value.current;
    } finally {
      panelStore.update({ pendingOperation: null });
      panelStore.notify();
    }
  };
  const discardCurrentRecording = (): void => {
    overlay.hideAll();
    overlay.hideInputFocusHint();
    stopEngine();

    if (persistedSnapshot) {
      const restored = cloneRecording(persistedSnapshot);
      draftTitle = restored?.title ?? DEFAULT_RECORDING_TITLE;
      draftVisibility = restored?.visibility ?? DEFAULT_RECORDING_VISIBILITY;
      panelStore.update({
        current: restored,
        hasUnsavedChanges: false,
        replayIndex: null,
      });
      return;
    }

    draftTitle = DEFAULT_RECORDING_TITLE;
    draftVisibility = DEFAULT_RECORDING_VISIBILITY;
    panelStore.update({
      current: null,
      hasUnsavedChanges: false,
      replayIndex: null,
      pendingOperation: null,
    });
  };
  const startRecording = async (opts?: {
    title?: string;
    visibility?: RecordingVisibility;
  }): Promise<Recording> => {
    const current = panelStore.value.current;
    if (panelStore.value.isRecording && current) {
      bubble.open();
      panelStore.notify();
      return current;
    }

    panelStore.update({ pendingOperation: "starting" });
    bubble.open();

    try {
      await onBeforeStartRecording?.();
      stopReplay();
      overlay.hideAll();
      overlay.hideInputFocusHint();

      persistedSnapshot = cloneRecording(panelStore.value.current);
      draftTitle = opts?.title?.trim() || draftTitle || DEFAULT_RECORDING_TITLE;
      draftVisibility = opts?.visibility ?? draftVisibility ?? DEFAULT_RECORDING_VISIBILITY;

      const next: Recording = {
        id: crypto.randomUUID(),
        title: draftTitle,
        startUrl: window.location.href,
        steps: [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
        visibility: draftVisibility,
        ownerId: resolveOwnerId?.() ?? userId,
        schemaVersion: RECORDING_SCHEMA_VERSION,
      };

      engine.start();
      panelStore.update({
        current: next,
        hasUnsavedChanges: false,
        replayIndex: null,
        panelView: "recorder",
        isRecording: true,
        isReplaying: false,
      });
      hooks?.onRecordingStarted?.(next);
      return next;
    } catch (error) {
      emitError(error);
      throw error;
    } finally {
      panelStore.update({ pendingOperation: null });
      panelStore.notify();
    }
  };
  const setVisibility = (visibility: RecordingVisibility): Recording | null => {
    draftVisibility = visibility;
    const current = panelStore.value.current;
    if (!current) {
      panelStore.notify();
      return null;
    }

    current.visibility = visibility;
    current.updatedAt = Date.now();
    panelStore.update({ hasUnsavedChanges: true });
    panelStore.notify();
    return current;
  };
  const setCaptureScreenshots = (value: boolean): void => {
    if (isCaptureScreenshotsEnabled === value) {
      return;
    }

    isCaptureScreenshotsEnabled = value;
    panelStore.notify();
    hooks?.onCaptureScreenshotsChanged?.(value);
  };
  const openLibraryView = async (): Promise<void> => {
    try {
      libraryController.setState(await store.list());
      panelStore.update({ panelView: "library" });
    } catch (error) {
      emitError(error);
      throw error;
    }
  };
  const closeLibraryView = (): void => {
    panelStore.update({ panelView: "recorder" });
  };
  const listRecordings = async (): Promise<Recording[]> => {
    try {
      const recordings = await store.list();
      libraryController.setState(recordings);
      if (panelStore.value.panelView === "library") {
        panelStore.notify();
      }
      return recordings;
    } catch (error) {
      emitError(error);
      throw error;
    }
  };
  const loadRecording = async (id: string): Promise<Recording> => {
    try {
      stopReplay();
      overlay.hideAll();
      overlay.hideInputFocusHint();
      const recording = await resolveRecording(id);
      const next = applyCurrentRecording(recording);
      panelStore.update({ panelView: "recorder" });
      hooks?.onRecordingLoaded?.(next);
      return next;
    } catch (error) {
      emitError(error);
      throw error;
    }
  };
  const deleteRecording = async (id: string): Promise<void> => {
    try {
      await store.delete(id);
      libraryController.remove(id);
      if (panelStore.value.current?.id === id) {
        stopReplay();
        resetCurrentRecording();
      } else {
        panelStore.update({ replayIndex: null });
        panelStore.notify();
      }
    } catch (error) {
      emitError(error);
      throw error;
    }
  };
  const clearAll = async (): Promise<void> => {
    if (!store.clear) {
      return;
    }

    try {
      await store.clear();
      stopReplay();
      resetCurrentRecording();
      panelStore.update({ libraryRecordings: [] });
    } catch (error) {
      emitError(error);
      throw error;
    }
  };
  const replayInternal = async (
    idOrRecording: string | Recording,
    options: { skipRefreshBeforeReplay?: boolean } = {},
  ): Promise<void> => {
    panelStore.update({ pendingOperation: "replaying" });
    try {
      await replayController.replay(idOrRecording, options);
    } catch (error) {
      emitError(error);
      throw error;
    } finally {
      panelStore.update({ pendingOperation: null });
      panelStore.notify();
    }
  };
  const replay = (idOrRecording: string | Recording): Promise<void> =>
    replayInternal(idOrRecording);
  const bindDraftTitle = (value: string): void => {
    const nextTitle = resolveDraftTitle(value, DEFAULT_RECORDING_TITLE);
    draftTitle = nextTitle;
    const current = panelStore.value.current;
    if (!current) return;
    current.title = nextTitle;
    current.updatedAt = Date.now();
  };
  const commitTitle = (): void => {
    if (!panelStore.value.current) return;
    panelStore.update({ hasUnsavedChanges: true });
    panelStore.notify();
  };
  const updateStepInstruction = (stepId: string, value: string): void => {
    const current = panelStore.value.current;
    if (!current) return;
    updateRecordingStepInstruction(current, stepId, value);
  };
  const commitStepInstruction = (): void => {
    if (!panelStore.value.current) return;
    panelStore.update({ hasUnsavedChanges: true });
    panelStore.notify();
  };
  const deleteStep = (stepId: string): void => {
    const current = panelStore.value.current;
    if (!current) return;
    if (!deleteRecordingStep(current, stepId)) return;
    panelStore.update({ hasUnsavedChanges: true });
    panelStore.notify();
  };
  const updateStepSkipCondition = (stepId: string, condition: StepSkipCondition | null): void => {
    const current = panelStore.value.current;
    if (!current) return;
    if (!updateRecordingStepSkipCondition(current, stepId, condition)) return;
    panelStore.update({ hasUnsavedChanges: true });
    panelStore.notify();
  };
  const attachSdkUiPanel = (options?: {
    auth?: RecorderKernelPanelAuthAdapter;
  }): RecorderKernelPanelBinding => {
    attachedPanelBinding?.destroy();
    attachedPanelBinding = attachRecorderPanelBinding({
      kernel: {
        panelRoot: bubble.panelEl,
        subscribe,
        getSnapshot,
        startRecording,
        stopRecording: saveCurrentRecording,
        saveCurrentRecording,
        discardCurrentRecording,
        getCurrentRecording: () => panelStore.value.current,
        replay,
        stopReplay,
        setCaptureScreenshots,
        bindDraftTitle,
        commitTitle,
        setVisibility,
        updateStepInstruction,
        commitStepInstruction,
        deleteStep,
        updateStepSkipCondition,
        pickElement,
        openLibraryView,
        closeLibraryView,
        loadRecording,
        deleteRecording,
      },
      enableElementPicker: authoring?.enableContextMenuAuthoring === true,
      auth: options?.auth,
    });
    return attachedPanelBinding;
  };

  queueMicrotask(() => {
    hooks?.onReady?.();
    const pending = consumePendingReplayRefresh({
      enabled: refreshBeforeReplay,
      storageKey: SDK_RECORDER_REPLAY_REFRESH_STORAGE_KEY,
    });
    if (!pending) {
      return;
    }

    void replayInternal(pending.recording ?? pending.recordingId, {
      skipRefreshBeforeReplay: true,
    }).catch(() => {
      /* replay() emits the error */
    });
  });

  return {
    bubble,
    overlay,
    panelRoot: bubble.panelEl,
    shadowRoot: bubble.shadowRoot,
    subscribe,
    getSnapshot,
    open: () => bubble.open(),
    close: () => bubble.close(),
    startRecording,
    stopRecording: saveCurrentRecording,
    saveCurrentRecording,
    discardCurrentRecording,
    setVisibility,
    getCurrentRecording: () => panelStore.value.current,
    loadRecording,
    listRecordings,
    deleteRecording,
    clearAll,
    replay,
    stopReplay,
    setCaptureScreenshots,
    openLibraryView,
    closeLibraryView,
    bindDraftTitle,
    commitTitle,
    updateStepInstruction,
    commitStepInstruction,
    deleteStep,
    updateStepSkipCondition,
    pickElement,
    attachSdkUiPanel,
    formatRecordingMeta: formatRecordingMetaLabel,
    destroy: () => {
      attachedPanelBinding?.destroy();
      stopReplay();
      engine.stop();
      authoringController.destroy();
      bubble.destroy();
    },
  };
};
