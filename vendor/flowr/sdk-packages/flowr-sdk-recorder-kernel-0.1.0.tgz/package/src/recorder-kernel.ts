import {
  createRecorderEngine,
  createSdkActivityScope,
  createStore,
  eventPathIncludes,
  consumePendingReplayRefresh,
  mountBubble,
  RECORDING_SCHEMA_VERSION,
  SDK_RECORDER_REPLAY_REFRESH_STORAGE_KEY,
  type BubbleHandle,
  type NavigationStepMatchMode,
  type Recording,
  type RecordingVisibility,
  type SdkTheme,
  type SelectorInfo,
  type Step,
  type StepSkipCondition,
} from "@flowr/sdk-core";
import type { RecorderOverlayHandle } from "@flowr/sdk-ui/recorder-overlay";
import type { RecorderPanelStatus } from "@flowr/sdk-ui/recorder-panel";
import {
  cloneRecording,
  DEFAULT_RECORDING_TITLE,
  DEFAULT_RECORDING_VISIBILITY,
  sortRecordingsByUpdatedAt,
  type RecorderKernelStore,
} from "./recording-store";
import {
  buildSectionInstructionStep,
  buildElementStep,
  createRecorderAuthoringController,
} from "./recorder-authoring";
import {
  attachRecorderPanelBinding,
  type RecorderKernelPanelAuthAdapter,
  type RecorderKernelPanelBinding,
} from "./recorder-panel-binding";
import {
  deleteRecordingStep,
  formatRecordingMeta as formatRecordingMetaLabel,
  resolveDraftTitle,
  updateRecordingStepInstruction,
  updateRecordingStepNavigationMatchMode,
  updateRecordingStepSkipCondition,
} from "./recording-step-edits";
import { createRecordingLibraryController } from "./recording-library-controller";
import { createRecorderReplayController } from "./replay-controller";
import { createStepCaptureController } from "./step-capture-controller";

type PendingOperation = "starting" | "saving" | "replaying" | null;

type PanelView = "recorder" | "library";

type LibraryStatus = "idle" | "loading" | "ready";

const LIBRARY_CACHE_TTL_MS = 10 * 60 * 1000;
const ACTIVE_RECORDING_STORAGE_KEY = "flowr:sdk-recorder:active-recording";
const ACTIVE_RECORDING_STORAGE_VERSION = 1;

type ActiveRecordingDraft = {
  version: typeof ACTIVE_RECORDING_STORAGE_VERSION;
  origin: string;
  recording: Recording;
  draftTitle: string;
  draftVisibility: RecordingVisibility;
  captureScreenshots: boolean;
  updatedAt: number;
};

const isPlainObject = (value: unknown): value is Record<string, unknown> =>
  value !== null && typeof value === "object" && !Array.isArray(value);

const isRecordingVisibility = (value: unknown): value is RecordingVisibility =>
  value === "private" || value === "public" || value === "internal";

const isRecordingDraftPayload = (value: unknown): value is ActiveRecordingDraft => {
  if (!isPlainObject(value)) {
    return false;
  }
  const recording = value.recording;
  return (
    value.version === ACTIVE_RECORDING_STORAGE_VERSION &&
    typeof value.origin === "string" &&
    isPlainObject(recording) &&
    typeof recording.id === "string" &&
    typeof recording.title === "string" &&
    typeof recording.startUrl === "string" &&
    Array.isArray(recording.steps) &&
    typeof value.draftTitle === "string" &&
    isRecordingVisibility(value.draftVisibility) &&
    typeof value.captureScreenshots === "boolean"
  );
};

const readActiveRecordingDraft = (): ActiveRecordingDraft | null => {
  try {
    const raw = window.sessionStorage.getItem(ACTIVE_RECORDING_STORAGE_KEY);
    if (!raw) {
      return null;
    }
    const parsed = JSON.parse(raw) as unknown;
    return isRecordingDraftPayload(parsed) ? parsed : null;
  } catch {
    return null;
  }
};

type KernelStoreState = {
  current: Recording | null;
  hasUnsavedChanges: boolean;
  replayIndex: number | null;
  panelView: PanelView;
  libraryRecordings: Recording[];
  libraryStatus: LibraryStatus;
  libraryLastLoadedAt: number | null;
  isRecording: boolean;
  isReplaying: boolean;
  pendingOperation: PendingOperation;
};

export type RecorderKernelSnapshot = KernelStoreState & {
  draftTitle: string;
  draftVisibility: RecordingVisibility;
  captureScreenshots: boolean;
  defaultTitle: string;
  defaultVisibility: RecordingVisibility;
  canSave: boolean;
  status: RecorderPanelStatus;
};

export type RecorderKernelHooks = {
  onReady?: () => void;
  onRecordingStarted?: (recording: Recording) => void;
  onStepCaptured?: (recording: Recording, step: Step) => void;
  onStepUpdated?: (recording: Recording, step: Step) => void;
  onCaptureScreenshotsChanged?: (captureScreenshots: boolean) => void;
  onRecordingSaved?: (recording: Recording) => void;
  onRecordingLoaded?: (recording: Recording) => void;
  onReplayStart?: (recording: Recording) => void;
  onReplayStep?: (index: number, step: Step) => void;
  onReplayComplete?: () => void;
  onError?: (error: Error) => void;
};

export type RecorderKernelOptions = {
  store: RecorderKernelStore;
  bubble: {
    defaultIconDataUrl: string;
    iconUrl?: string;
    panelCssText?: string;
    theme?: SdkTheme;
    position?: "bottom-right" | "bottom-left" | "top-right" | "top-left";
    tooltip: string;
  };
  captureScreenshots?: boolean;
  interceptClicks?: boolean;
  activityOwnerId?: string;
  userId?: string;
  resolveOwnerId?: () => string | undefined;
  authoring?: {
    enableContextMenuAuthoring?: boolean;
    enableInputFocusHints?: boolean;
  };
  onBeforeStartRecording?: () => Promise<void> | void;
  refreshBeforeReplay?: boolean;
  hooks?: RecorderKernelHooks;
};

export type RecorderKernelHandle = {
  readonly bubble: BubbleHandle;
  readonly overlay: RecorderOverlayHandle;
  readonly panelRoot: HTMLElement;
  readonly shadowRoot: ShadowRoot;
  subscribe: (listener: (snapshot: RecorderKernelSnapshot) => void) => () => void;
  getSnapshot: () => RecorderKernelSnapshot;
  open: () => void;
  close: () => void;
  startRecording: (opts?: {
    title?: string;
    visibility?: RecordingVisibility;
  }) => Promise<Recording>;
  stopRecording: () => Promise<Recording | null>;
  saveCurrentRecording: () => Promise<Recording | null>;
  discardCurrentRecording: () => void;
  clearCurrentRecording: () => void;
  setVisibility: (visibility: RecordingVisibility) => Recording | null;
  getCurrentRecording: () => Recording | null;
  loadRecording: (id: string) => Promise<Recording>;
  listRecordings: () => Promise<Recording[]>;
  deleteRecording: (id: string) => Promise<void>;
  clearAll: () => Promise<void>;
  replay: (idOrRecording: string | Recording) => Promise<void>;
  stopReplay: () => void;
  setCaptureScreenshots: (value: boolean) => void;
  openLibraryView: () => void;
  reloadLibrary: () => Promise<void>;
  closeLibraryView: () => void;
  bindDraftTitle: (value: string) => void;
  commitTitle: () => void;
  updateStepInstruction: (stepId: string, value: string) => void;
  commitStepInstruction: () => void;
  deleteStep: (stepId: string) => void;
  updateStepNavigationMatchMode: (stepId: string, mode: NavigationStepMatchMode) => void;
  updateStepSkipCondition: (stepId: string, condition: StepSkipCondition | null) => void;
  pickElement: (onPicked: (selector: SelectorInfo | null) => void) => void;
  attachSdkUiPanel: (options?: {
    auth?: RecorderKernelPanelAuthAdapter;
    theme?: SdkTheme;
  }) => RecorderKernelPanelBinding;
  formatRecordingMeta: (recording: Recording) => string;
  destroy: () => void;
};

export const createRecorderKernel = ({
  store,
  bubble: bubbleOptions,
  captureScreenshots = false,
  interceptClicks = true,
  activityOwnerId,
  userId,
  resolveOwnerId,
  authoring,
  onBeforeStartRecording,
  refreshBeforeReplay = true,
  hooks,
}: RecorderKernelOptions): RecorderKernelHandle => {
  const bubble = mountBubble({
    assets: {
      iconUrl: bubbleOptions.iconUrl ?? bubbleOptions.defaultIconDataUrl,
      brandIconUrl: bubbleOptions.iconUrl ?? bubbleOptions.defaultIconDataUrl,
      panelCssText: bubbleOptions.panelCssText ?? "",
      contentCssText: "",
    },
    theme: bubbleOptions.theme,
    position: bubbleOptions.position,
    tooltip: bubbleOptions.tooltip,
  });

  const ignoreHost = bubble.shadowRoot.host as HTMLElement;
  const isFromSdkEvent = (event: Event): boolean => eventPathIncludes(event, ignoreHost);

  const panelStore = createStore<KernelStoreState>({
    current: null,
    hasUnsavedChanges: false,
    replayIndex: null,
    panelView: "recorder",
    libraryRecordings: [],
    libraryStatus: "idle",
    libraryLastLoadedAt: null,
    isRecording: false,
    isReplaying: false,
    pendingOperation: null,
  });

  let draftTitle = DEFAULT_RECORDING_TITLE;
  let draftVisibility = DEFAULT_RECORDING_VISIBILITY;
  let isCaptureScreenshotsEnabled = captureScreenshots;
  let persistedSnapshot: Recording | null = null;
  let attachedPanelBinding: RecorderKernelPanelBinding | null = null;
  let libraryLoadPromise: Promise<Recording[]> | null = null;
  const recordingActivity = createSdkActivityScope("recorder", {
    ...(activityOwnerId ? { ownerId: activityOwnerId } : {}),
  });
  const replayActivity = createSdkActivityScope("replay", {
    ownerId: recordingActivity.ownerId,
  });

  const clearActiveRecordingDraft = (): void => {
    try {
      window.sessionStorage.removeItem(ACTIVE_RECORDING_STORAGE_KEY);
    } catch {
      /* ignore private/sandboxed storage failures */
    }
  };

  const persistActiveRecordingDraft = (): void => {
    const current = panelStore.value.current;
    if (!panelStore.value.isRecording || !current) {
      return;
    }

    const recording = cloneRecording(current);
    if (!recording) {
      return;
    }

    const payload: ActiveRecordingDraft = {
      version: ACTIVE_RECORDING_STORAGE_VERSION,
      origin: window.location.origin,
      recording,
      draftTitle,
      draftVisibility,
      captureScreenshots: isCaptureScreenshotsEnabled,
      updatedAt: Date.now(),
    };

    try {
      window.sessionStorage.setItem(ACTIVE_RECORDING_STORAGE_KEY, JSON.stringify(payload));
    } catch {
      /* ignore private/sandboxed storage failures */
    }
  };

  const computeStatus = (): RecorderPanelStatus => {
    if (panelStore.value.isRecording) return "recording";
    if (panelStore.value.isReplaying) return "replaying";
    return "idle";
  };
  const getSnapshot = (): RecorderKernelSnapshot => ({
    ...panelStore.value,
    draftTitle,
    draftVisibility,
    captureScreenshots: isCaptureScreenshotsEnabled,
    defaultTitle: DEFAULT_RECORDING_TITLE,
    defaultVisibility: DEFAULT_RECORDING_VISIBILITY,
    canSave: Boolean(panelStore.value.current && panelStore.value.current.steps.length > 0),
    status: computeStatus(),
  });

  const subscribe = (listener: (snapshot: RecorderKernelSnapshot) => void): (() => void) => {
    return panelStore.subscribe(() => {
      listener(getSnapshot());
    });
  };
  const libraryController = createRecordingLibraryController({
    store,
    getLibraryRecordings: () => panelStore.value.libraryRecordings,
    setLibraryRecordings: (recordings) => {
      panelStore.update({ libraryRecordings: recordings });
    },
  });

  const markLibraryCacheFresh = (): void => {
    panelStore.update({
      libraryStatus: "ready",
      libraryLastLoadedAt: Date.now(),
    });
  };

  const applyLoadedLibraryRecordings = (recordings: Recording[]): Recording[] => {
    const sorted = sortRecordingsByUpdatedAt(recordings);
    panelStore.update({
      libraryRecordings: sorted,
      libraryStatus: "ready",
      libraryLastLoadedAt: Date.now(),
    });
    return sorted;
  };

  const hasFreshLibraryCache = (): boolean => {
    const lastLoadedAt = panelStore.value.libraryLastLoadedAt;
    return lastLoadedAt !== null && Date.now() - lastLoadedAt < LIBRARY_CACHE_TTL_MS;
  };

  const loadLibraryRecordings = async (options: { force?: boolean } = {}): Promise<Recording[]> => {
    if (libraryLoadPromise) {
      if (options.force) {
        const inFlightRequest = libraryLoadPromise;
        await inFlightRequest.catch(() => undefined);
        if (libraryLoadPromise === inFlightRequest) {
          libraryLoadPromise = null;
        }
      } else {
        return libraryLoadPromise;
      }
    }

    if (libraryLoadPromise) {
      return libraryLoadPromise;
    }

    panelStore.update({ libraryStatus: "loading" });

    const request = store
      .list()
      .then((recordings) => {
        const sorted = applyLoadedLibraryRecordings(recordings);
        return sorted;
      })
      .catch((error) => {
        panelStore.update({
          libraryStatus: panelStore.value.libraryRecordings.length > 0 ? "ready" : "idle",
        });
        emitError(error);
        throw error;
      })
      .finally(() => {
        if (libraryLoadPromise === request) {
          libraryLoadPromise = null;
        }
      });

    libraryLoadPromise = request;
    return request;
  };

  const resetCurrentRecording = (): void => {
    clearActiveRecordingDraft();
    recordingActivity.release();
    persistedSnapshot = null;
    draftTitle = DEFAULT_RECORDING_TITLE;
    draftVisibility = DEFAULT_RECORDING_VISIBILITY;
    panelStore.update({
      current: null,
      hasUnsavedChanges: false,
      replayIndex: null,
      isRecording: false,
      isReplaying: false,
      pendingOperation: null,
    });
  };
  const applyCurrentRecording = (recording: Recording): Recording => {
    clearActiveRecordingDraft();
    const next = cloneRecording(recording) ?? recording;
    persistedSnapshot = cloneRecording(next);
    draftTitle = next.title;
    draftVisibility = next.visibility ?? DEFAULT_RECORDING_VISIBILITY;
    panelStore.update({
      current: next,
      hasUnsavedChanges: false,
      replayIndex: null,
      isRecording: false,
      isReplaying: false,
    });
    return next;
  };
  const emitError = (error: unknown): void => {
    hooks?.onError?.(error as Error);
  };
  let isStepCaptureBlocked = (): boolean => false;
  const stepCaptureController = createStepCaptureController({
    getCaptureScreenshots: () => isCaptureScreenshotsEnabled,
    getCurrentRecording: () => panelStore.value.current,
    isBlocked: () => isStepCaptureBlocked(),
    markUnsavedChanges: () => {
      panelStore.update({ hasUnsavedChanges: true });
      persistActiveRecordingDraft();
    },
    notify: () => {
      persistActiveRecordingDraft();
      panelStore.notify();
    },
    onStepCaptured: hooks?.onStepCaptured,
    onStepUpdated: hooks?.onStepUpdated,
  });
  const authoringController = createRecorderAuthoringController({
    shadowRoot: bubble.shadowRoot,
    isRecording: () => panelStore.value.isRecording,
    isFromSdkEvent,
    isCaptureScreenshotsEnabled: () => isCaptureScreenshotsEnabled,
    enableContextMenuAuthoring: authoring?.enableContextMenuAuthoring === true,
    enableInputFocusHints: authoring?.enableInputFocusHints === true,
    openBubble: () => bubble.open(),
    onRecordHover: (target) => {
      stepCaptureController.appendStep(buildElementStep("hover", target), target);
    },
    onRecordContextClick: (target) => {
      stepCaptureController.appendStep(buildElementStep("context-click", target), target);
    },
    onSaveInstruction: (target, instruction) => {
      stepCaptureController.appendStep(buildSectionInstructionStep(target, instruction), target);
    },
  });
  isStepCaptureBlocked = () => authoringController.isPickingElement();
  const overlay = authoringController.overlay;
  const pickElement = authoringController.pickElement;
  const engine = createRecorderEngine({
    ignoreHost,
    randomId: () => crypto.randomUUID(),
    now: () => Date.now(),
    onStep(step) {
      stepCaptureController.appendStep(step);
    },
    promptInstruction: interceptClicks
      ? (target) =>
          overlay.showInstructionPrompt({
            target,
            title: "Add instruction",
            copy: "Tell viewers what to do at this step.",
            placeholder: "Click the highlighted element",
            defaultInstruction: "Click the highlighted element",
          })
      : undefined,
  });
  const restoreActiveRecordingDraft = (): boolean => {
    const draft = readActiveRecordingDraft();
    if (!draft) {
      return false;
    }
    if (draft.origin !== window.location.origin) {
      clearActiveRecordingDraft();
      return false;
    }

    const recording = cloneRecording(draft.recording);
    if (!recording) {
      clearActiveRecordingDraft();
      return false;
    }
    if (!recordingActivity.acquire()) {
      return false;
    }

    persistedSnapshot = null;
    draftTitle = draft.draftTitle || recording.title || DEFAULT_RECORDING_TITLE;
    draftVisibility = draft.draftVisibility;
    isCaptureScreenshotsEnabled = draft.captureScreenshots;
    engine.start();
    panelStore.update({
      current: recording,
      hasUnsavedChanges: recording.steps.length > 0,
      replayIndex: null,
      panelView: "recorder",
      isRecording: true,
      isReplaying: false,
      pendingOperation: null,
    });
    persistActiveRecordingDraft();
    panelStore.notify();
    return true;
  };
  const stopEngine = (): void => {
    if (!panelStore.value.isRecording) {
      return;
    }

    engine.stop();
    recordingActivity.release();
    panelStore.update({ isRecording: false });
  };
  const resolveRecording = async (id: string): Promise<Recording> => {
    return libraryController.resolve(id);
  };
  const replayController = createRecorderReplayController({
    shadowRoot: bubble.shadowRoot,
    setBubbleVisible: (visible) => bubble.setBubbleVisible(visible),
    openBubble: () => bubble.open(),
    resolveRecording,
    applyCurrentRecording,
    updateReplayState: (patch) => {
      panelStore.update(patch);
    },
    notify: () => {
      panelStore.notify();
    },
    onReplayStart: hooks?.onReplayStart,
    onReplayStep: hooks?.onReplayStep,
    onReplayComplete: () => {
      replayActivity.release();
      hooks?.onReplayComplete?.();
    },
    onReplayError: (error) => {
      replayActivity.release();
      emitError(error);
    },
    refreshBeforeReplay,
  });
  const stopReplay = (): void => {
    replayController.stop();
    replayActivity.release();
  };
  const saveCurrentRecording = async (): Promise<Recording | null> => {
    const current = panelStore.value.current;
    if (!current) return null;

    panelStore.update({ pendingOperation: "saving" });
    overlay.hideAll();
    overlay.hideInputFocusHint();
    stopEngine();
    clearActiveRecordingDraft();
    await stepCaptureController.waitForPendingScreenshotCaptures();

    if (current.steps.length === 0) {
      if (persistedSnapshot) {
        const restored = cloneRecording(persistedSnapshot);
        draftTitle = restored?.title ?? DEFAULT_RECORDING_TITLE;
        draftVisibility = restored?.visibility ?? DEFAULT_RECORDING_VISIBILITY;
        panelStore.update({
          current: restored,
          hasUnsavedChanges: false,
          replayIndex: null,
        });
      } else {
        draftTitle = DEFAULT_RECORDING_TITLE;
        draftVisibility = DEFAULT_RECORDING_VISIBILITY;
        panelStore.update({
          current: null,
          hasUnsavedChanges: false,
          replayIndex: null,
        });
      }
      panelStore.update({ pendingOperation: null });
      return null;
    }

    try {
      current.updatedAt = Date.now();
      const currentAtSaveStart = current;
      const snapshotToSave = cloneRecording(currentAtSaveStart)!;
      const saved = await store.save(snapshotToSave);
      const activeCurrent = panelStore.value.current;
      const didSwitchDraft = activeCurrent !== currentAtSaveStart;
      const didEditDuringSave =
        !didSwitchDraft && currentAtSaveStart.updatedAt !== snapshotToSave.updatedAt;

      const savedSnapshot = cloneRecording(saved) ?? saved;
      persistedSnapshot = cloneRecording(savedSnapshot);
      libraryController.upsert(cloneRecording(savedSnapshot) ?? savedSnapshot);
      markLibraryCacheFresh();
      hooks?.onRecordingSaved?.(cloneRecording(savedSnapshot) ?? savedSnapshot);

      if (didSwitchDraft) {
        return activeCurrent;
      }

      if (didEditDuringSave) {
        currentAtSaveStart.createdAt = saved.createdAt;
        currentAtSaveStart.ownerId = saved.ownerId ?? currentAtSaveStart.ownerId;
        currentAtSaveStart.schemaVersion = saved.schemaVersion ?? currentAtSaveStart.schemaVersion;
        draftTitle = currentAtSaveStart.title;
        draftVisibility = currentAtSaveStart.visibility ?? DEFAULT_RECORDING_VISIBILITY;
        panelStore.update({ hasUnsavedChanges: true, replayIndex: null });
        return currentAtSaveStart;
      }

      const nextCurrent = cloneRecording(savedSnapshot) ?? savedSnapshot;
      draftTitle = nextCurrent.title;
      draftVisibility = nextCurrent.visibility ?? DEFAULT_RECORDING_VISIBILITY;
      panelStore.update({
        current: nextCurrent,
        hasUnsavedChanges: false,
        replayIndex: null,
      });
      return nextCurrent;
    } catch (error) {
      emitError(error);
      return panelStore.value.current;
    } finally {
      panelStore.update({ pendingOperation: null });
      panelStore.notify();
    }
  };
  const discardCurrentRecording = (): void => {
    overlay.hideAll();
    overlay.hideInputFocusHint();
    stopEngine();
    clearActiveRecordingDraft();

    if (persistedSnapshot) {
      const restored = cloneRecording(persistedSnapshot);
      draftTitle = restored?.title ?? DEFAULT_RECORDING_TITLE;
      draftVisibility = restored?.visibility ?? DEFAULT_RECORDING_VISIBILITY;
      panelStore.update({
        current: restored,
        hasUnsavedChanges: false,
        replayIndex: null,
      });
      return;
    }

    draftTitle = DEFAULT_RECORDING_TITLE;
    draftVisibility = DEFAULT_RECORDING_VISIBILITY;
    panelStore.update({
      current: null,
      hasUnsavedChanges: false,
      replayIndex: null,
      pendingOperation: null,
    });
  };
  const clearCurrentRecording = (): void => {
    overlay.hideAll();
    overlay.hideInputFocusHint();
    stopReplay();
    stopEngine();
    resetCurrentRecording();
    panelStore.update({ panelView: "recorder" });
    panelStore.notify();
  };
  const startRecording = async (opts?: {
    title?: string;
    visibility?: RecordingVisibility;
  }): Promise<Recording> => {
    const current = panelStore.value.current;
    if (panelStore.value.isRecording && current) {
      bubble.open();
      panelStore.notify();
      return current;
    }

    panelStore.update({ pendingOperation: "starting" });
    bubble.open();
    if (!recordingActivity.acquire()) {
      const error = new Error("FlowR replay is active.");
      panelStore.update({ pendingOperation: null });
      emitError(error);
      throw error;
    }

    try {
      await onBeforeStartRecording?.();
      stopReplay();
      overlay.hideAll();
      overlay.hideInputFocusHint();

      persistedSnapshot = cloneRecording(panelStore.value.current);
      draftTitle = opts?.title?.trim() || draftTitle || DEFAULT_RECORDING_TITLE;
      draftVisibility = opts?.visibility ?? draftVisibility ?? DEFAULT_RECORDING_VISIBILITY;

      const next: Recording = {
        id: crypto.randomUUID(),
        title: draftTitle,
        startUrl: window.location.href,
        steps: [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
        visibility: draftVisibility,
        ownerId: resolveOwnerId?.() ?? userId,
        schemaVersion: RECORDING_SCHEMA_VERSION,
      };

      engine.start();
      panelStore.update({
        current: next,
        hasUnsavedChanges: false,
        replayIndex: null,
        panelView: "recorder",
        isRecording: true,
        isReplaying: false,
      });
      persistActiveRecordingDraft();
      hooks?.onRecordingStarted?.(next);
      return next;
    } catch (error) {
      recordingActivity.release();
      emitError(error);
      throw error;
    } finally {
      panelStore.update({ pendingOperation: null });
      panelStore.notify();
    }
  };
  const setVisibility = (visibility: RecordingVisibility): Recording | null => {
    draftVisibility = visibility;
    const current = panelStore.value.current;
    if (!current) {
      panelStore.notify();
      return null;
    }

    current.visibility = visibility;
    current.updatedAt = Date.now();
    panelStore.update({ hasUnsavedChanges: true });
    persistActiveRecordingDraft();
    panelStore.notify();
    return current;
  };
  const setCaptureScreenshots = (value: boolean): void => {
    if (isCaptureScreenshotsEnabled === value) {
      return;
    }

    isCaptureScreenshotsEnabled = value;
    persistActiveRecordingDraft();
    panelStore.notify();
    hooks?.onCaptureScreenshotsChanged?.(value);
  };
  const openLibraryView = (): void => {
    panelStore.update({ panelView: "library" });
    if (hasFreshLibraryCache()) {
      panelStore.update({ libraryStatus: "ready" });
      return;
    }

    void loadLibraryRecordings();
  };

  const reloadLibrary = async (): Promise<void> => {
    await loadLibraryRecordings({ force: true });
  };

  const closeLibraryView = (): void => {
    panelStore.update({ panelView: "recorder" });
  };
  const listRecordings = async (): Promise<Recording[]> => {
    if (hasFreshLibraryCache()) {
      return panelStore.value.libraryRecordings;
    }

    return loadLibraryRecordings();
  };
  const loadRecording = async (id: string): Promise<Recording> => {
    try {
      stopReplay();
      overlay.hideAll();
      overlay.hideInputFocusHint();
      const recording = await resolveRecording(id);
      const next = applyCurrentRecording(recording);
      panelStore.update({ panelView: "recorder" });
      hooks?.onRecordingLoaded?.(next);
      return next;
    } catch (error) {
      emitError(error);
      throw error;
    }
  };
  const deleteRecording = async (id: string): Promise<void> => {
    try {
      await store.delete(id);
      libraryController.remove(id);
      markLibraryCacheFresh();
      if (panelStore.value.current?.id === id) {
        stopReplay();
        resetCurrentRecording();
      } else {
        panelStore.update({ replayIndex: null });
        panelStore.notify();
      }
    } catch (error) {
      emitError(error);
      throw error;
    }
  };
  const clearAll = async (): Promise<void> => {
    if (!store.clear) {
      return;
    }

    try {
      await store.clear();
      stopReplay();
      resetCurrentRecording();
      panelStore.update({
        libraryRecordings: [],
        libraryStatus: "ready",
        libraryLastLoadedAt: Date.now(),
      });
    } catch (error) {
      emitError(error);
      throw error;
    }
  };
  const replayInternal = async (
    idOrRecording: string | Recording,
    options: {
      skipRefreshBeforeReplay?: boolean;
      skipStartUrlNavigation?: boolean;
      startIndex?: number;
    } = {},
  ): Promise<void> => {
    panelStore.update({ pendingOperation: "replaying" });
    if (!replayActivity.acquire()) {
      const error = new Error("FlowR recorder is active.");
      panelStore.update({ pendingOperation: null });
      emitError(error);
      throw error;
    }
    try {
      await replayController.replay(idOrRecording, options);
    } catch (error) {
      replayActivity.release();
      emitError(error);
      throw error;
    } finally {
      panelStore.update({ pendingOperation: null });
      panelStore.notify();
    }
  };
  const replay = (idOrRecording: string | Recording): Promise<void> =>
    replayInternal(idOrRecording);
  const bindDraftTitle = (value: string): void => {
    const nextTitle = resolveDraftTitle(value, DEFAULT_RECORDING_TITLE);
    draftTitle = nextTitle;
    const current = panelStore.value.current;
    if (!current) return;
    current.title = nextTitle;
    current.updatedAt = Date.now();
    persistActiveRecordingDraft();
  };
  const commitTitle = (): void => {
    if (!panelStore.value.current) return;
    panelStore.update({ hasUnsavedChanges: true });
    persistActiveRecordingDraft();
    panelStore.notify();
  };
  const updateStepInstruction = (stepId: string, value: string): void => {
    const current = panelStore.value.current;
    if (!current) return;
    updateRecordingStepInstruction(current, stepId, value);
    persistActiveRecordingDraft();
  };
  const commitStepInstruction = (): void => {
    if (!panelStore.value.current) return;
    panelStore.update({ hasUnsavedChanges: true });
    persistActiveRecordingDraft();
    panelStore.notify();
  };
  const deleteStep = (stepId: string): void => {
    const current = panelStore.value.current;
    if (!current) return;
    if (!deleteRecordingStep(current, stepId)) return;
    panelStore.update({ hasUnsavedChanges: true });
    persistActiveRecordingDraft();
    panelStore.notify();
  };
  const updateStepNavigationMatchMode = (
    stepId: string,
    mode: NavigationStepMatchMode,
  ): void => {
    const current = panelStore.value.current;
    if (!current) return;
    if (!updateRecordingStepNavigationMatchMode(current, stepId, mode)) return;
    panelStore.update({ hasUnsavedChanges: true });
    persistActiveRecordingDraft();
    panelStore.notify();
  };
  const updateStepSkipCondition = (stepId: string, condition: StepSkipCondition | null): void => {
    const current = panelStore.value.current;
    if (!current) return;
    if (!updateRecordingStepSkipCondition(current, stepId, condition)) return;
    panelStore.update({ hasUnsavedChanges: true });
    persistActiveRecordingDraft();
    panelStore.notify();
  };
  const attachSdkUiPanel = (options?: {
    auth?: RecorderKernelPanelAuthAdapter;
    theme?: SdkTheme;
  }): RecorderKernelPanelBinding => {
    attachedPanelBinding?.destroy();
    attachedPanelBinding = attachRecorderPanelBinding({
      kernel: {
        panelRoot: bubble.panelEl,
        subscribe,
        getSnapshot,
        startRecording,
        stopRecording: saveCurrentRecording,
        saveCurrentRecording,
        discardCurrentRecording,
        getCurrentRecording: () => panelStore.value.current,
        replay,
        stopReplay,
        setCaptureScreenshots,
        bindDraftTitle,
        commitTitle,
        setVisibility,
        updateStepInstruction,
        commitStepInstruction,
        deleteStep,
        updateStepNavigationMatchMode,
        updateStepSkipCondition,
        pickElement,
        openLibraryView,
        reloadLibrary,
        closeLibraryView,
        loadRecording,
        deleteRecording,
      },
      enableElementPicker: authoring?.enableContextMenuAuthoring === true,
      auth: options?.auth,
      theme: options?.theme ?? bubbleOptions.theme,
    });
    return attachedPanelBinding;
  };

  queueMicrotask(() => {
    restoreActiveRecordingDraft();
    hooks?.onReady?.();
    const pending = consumePendingReplayRefresh({
      storageKey: SDK_RECORDER_REPLAY_REFRESH_STORAGE_KEY,
    });
    if (!pending) {
      return;
    }

    void replayInternal(pending.recording ?? pending.recordingId, {
      skipRefreshBeforeReplay: true,
      skipStartUrlNavigation: true,
      startIndex: pending.stepIndex ?? 0,
    }).catch(() => {
      /* replay() emits the error */
    });
  });

  return {
    bubble,
    overlay,
    panelRoot: bubble.panelEl,
    shadowRoot: bubble.shadowRoot,
    subscribe,
    getSnapshot,
    open: () => bubble.open(),
    close: () => bubble.close(),
    startRecording,
    stopRecording: saveCurrentRecording,
    saveCurrentRecording,
    discardCurrentRecording,
    clearCurrentRecording,
    setVisibility,
    getCurrentRecording: () => panelStore.value.current,
    loadRecording,
    listRecordings,
    deleteRecording,
    clearAll,
    replay,
    stopReplay,
    setCaptureScreenshots,
    openLibraryView,
    reloadLibrary,
    closeLibraryView,
    bindDraftTitle,
    commitTitle,
    updateStepInstruction,
    commitStepInstruction,
    deleteStep,
    updateStepNavigationMatchMode,
    updateStepSkipCondition,
    pickElement,
    attachSdkUiPanel,
    formatRecordingMeta: formatRecordingMetaLabel,
    destroy: () => {
      attachedPanelBinding?.destroy();
      stopReplay();
      engine.stop();
      authoringController.destroy();
      bubble.destroy();
    },
  };
};
