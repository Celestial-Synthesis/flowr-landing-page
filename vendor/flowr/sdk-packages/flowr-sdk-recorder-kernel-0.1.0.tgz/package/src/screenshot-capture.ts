import { compressScreenshotDataUrl } from "@flowr/sdk-core";

type HtmlToImageModule = {
  toCanvas: (target: HTMLElement, options?: Record<string, unknown>) => Promise<HTMLCanvasElement>;
};

const SDK_HOST_SELECTOR = "[data-flowr-sdk]";
const MIN_CAPTURE_SCALE = 2;
const MAX_CAPTURE_SCALE = 3;
const MIN_SCROLLED_CAPTURE_SCALE = 0.5;
const MAX_SCROLLED_SOURCE_PIXELS = 12_000_000;
const LOCAL_SCREENSHOT_MAX_BYTES = 100 * 1024;
const TRANSPARENT_PIXEL_DATA_URL =
  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";

let htmlToImageModuleTask: Promise<Pick<HtmlToImageModule, "toCanvas"> | null> | null = null;

const loadHtmlToImage = async (): Promise<Pick<HtmlToImageModule, "toCanvas"> | null> => {
  if (!htmlToImageModuleTask) {
    htmlToImageModuleTask = import("html-to-image")
      .then((module) => ({ toCanvas: module.toCanvas }))
      .catch(() => null);
  }

  return htmlToImageModuleTask;
};

const drawRoundedRect = (
  context: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number,
): void => {
  const safeRadius = Math.max(0, Math.min(radius, width / 2, height / 2));
  context.beginPath();
  context.moveTo(x + safeRadius, y);
  context.lineTo(x + width - safeRadius, y);
  context.quadraticCurveTo(x + width, y, x + width, y + safeRadius);
  context.lineTo(x + width, y + height - safeRadius);
  context.quadraticCurveTo(x + width, y + height, x + width - safeRadius, y + height);
  context.lineTo(x + safeRadius, y + height);
  context.quadraticCurveTo(x, y + height, x, y + height - safeRadius);
  context.lineTo(x, y + safeRadius);
  context.quadraticCurveTo(x, y, x + safeRadius, y);
  context.closePath();
};

const applyScreenshotHighlight = (
  canvas: HTMLCanvasElement,
  targetRect: DOMRect,
  viewportWidth: number,
  viewportHeight: number,
): void => {
  const context = canvas.getContext("2d");
  if (!context) {
    return;
  }

  const scaleX = canvas.width / Math.max(viewportWidth, 1);
  const scaleY = canvas.height / Math.max(viewportHeight, 1);
  const left = Math.max(0, targetRect.left * scaleX);
  const top = Math.max(0, targetRect.top * scaleY);
  const width = Math.max(4, targetRect.width * scaleX);
  const height = Math.max(4, targetRect.height * scaleY);
  const right = Math.min(canvas.width, left + width);
  const bottom = Math.min(canvas.height, top + height);
  const radius = Math.max(6 * ((scaleX + scaleY) / 2), 6);
  const borderWidth = Math.max(2 * ((scaleX + scaleY) / 2), 2);

  context.save();
  context.fillStyle = "rgba(10, 10, 10, 0.45)";
  if (top > 0) {
    context.fillRect(0, 0, canvas.width, top);
  }
  if (bottom < canvas.height) {
    context.fillRect(0, bottom, canvas.width, canvas.height - bottom);
  }
  if (left > 0) {
    context.fillRect(0, top, left, Math.max(bottom - top, 0));
  }
  if (right < canvas.width) {
    context.fillRect(right, top, canvas.width - right, Math.max(bottom - top, 0));
  }
  context.restore();

  context.save();
  drawRoundedRect(context, left, top, width, height, radius);
  context.fillStyle = "rgba(255, 255, 255, 0.08)";
  context.fill();
  context.lineWidth = borderWidth;
  context.strokeStyle = "#ffffff";
  context.stroke();
  context.restore();
};

const shouldIncludeNode = (node: HTMLElement): boolean => {
  if (node.matches?.(SDK_HOST_SELECTOR) || node.closest?.(SDK_HOST_SELECTOR)) {
    return false;
  }

  return true;
};

const createViewportCanvas = (
  width: number,
  height: number,
): { canvas: HTMLCanvasElement; context: CanvasRenderingContext2D } | null => {
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(width));
  canvas.height = Math.max(1, Math.round(height));
  const context = canvas.getContext("2d");
  if (!context) {
    return null;
  }

  context.fillStyle = "#ffffff";
  context.fillRect(0, 0, canvas.width, canvas.height);
  return { canvas, context };
};

const captureViewportAtOrigin = async (
  htmlToImage: Pick<HtmlToImageModule, "toCanvas">,
  viewportWidth: number,
  viewportHeight: number,
  captureScale: number,
): Promise<HTMLCanvasElement> => {
  const captureTarget = document.body ?? document.documentElement;
  return htmlToImage.toCanvas(captureTarget, {
    backgroundColor: "#ffffff",
    cacheBust: true,
    imagePlaceholder: TRANSPARENT_PIXEL_DATA_URL,
    pixelRatio: captureScale,
    filter: (node: HTMLElement) => shouldIncludeNode(node),
    width: viewportWidth,
    height: viewportHeight,
    style: {
      width: `${viewportWidth}px`,
      height: `${viewportHeight}px`,
      overflow: "hidden",
      backgroundColor: "#ffffff",
    },
  });
};

const getDocumentCaptureSize = (
  captureTarget: HTMLElement,
  viewportWidth: number,
  viewportHeight: number,
): { width: number; height: number } => {
  const documentElement = document.documentElement;
  return {
    width: Math.max(
      captureTarget.scrollWidth,
      captureTarget.offsetWidth,
      captureTarget.clientWidth,
      documentElement?.scrollWidth ?? 0,
      documentElement?.offsetWidth ?? 0,
      documentElement?.clientWidth ?? 0,
      viewportWidth,
      1,
    ),
    height: Math.max(
      captureTarget.scrollHeight,
      captureTarget.offsetHeight,
      captureTarget.clientHeight,
      documentElement?.scrollHeight ?? 0,
      documentElement?.offsetHeight ?? 0,
      documentElement?.clientHeight ?? 0,
      viewportHeight,
      1,
    ),
  };
};

const resolveScrolledCaptureScale = (
  captureTarget: HTMLElement,
  viewportWidth: number,
  viewportHeight: number,
  desiredScale: number,
): { width: number; height: number; scale: number } => {
  const { width, height } = getDocumentCaptureSize(captureTarget, viewportWidth, viewportHeight);
  const sourceCssPixels = width * height;
  const desiredPixelCount = sourceCssPixels * desiredScale * desiredScale;
  if (desiredPixelCount <= MAX_SCROLLED_SOURCE_PIXELS) {
    return { width, height, scale: desiredScale };
  }

  const scale = Math.sqrt(MAX_SCROLLED_SOURCE_PIXELS / sourceCssPixels);
  if (scale < MIN_SCROLLED_CAPTURE_SCALE) {
    throw new Error("Scrolled screenshot capture is too large");
  }

  return { width, height, scale };
};

const captureScrolledViewport = async (
  htmlToImage: Pick<HtmlToImageModule, "toCanvas">,
  viewportWidth: number,
  viewportHeight: number,
  captureScale: number,
): Promise<HTMLCanvasElement> => {
  const captureTarget = document.body ?? document.documentElement;
  const sourceMetrics = resolveScrolledCaptureScale(
    captureTarget,
    viewportWidth,
    viewportHeight,
    captureScale,
  );
  const sourceCanvas = await htmlToImage.toCanvas(captureTarget, {
    backgroundColor: "#ffffff",
    cacheBust: true,
    imagePlaceholder: TRANSPARENT_PIXEL_DATA_URL,
    pixelRatio: sourceMetrics.scale,
    filter: (node: HTMLElement) => shouldIncludeNode(node),
  });

  const scaleX = sourceCanvas.width / sourceMetrics.width;
  const scaleY = sourceCanvas.height / sourceMetrics.height;
  const viewportCanvas = createViewportCanvas(viewportWidth * scaleX, viewportHeight * scaleY);
  if (!viewportCanvas) {
    return sourceCanvas;
  }

  const sourceLeft = Math.max(0, Math.round(window.scrollX * scaleX));
  const sourceTop = Math.max(0, Math.round(window.scrollY * scaleY));
  const sourceWidth = Math.max(
    1,
    Math.min(viewportCanvas.canvas.width, sourceCanvas.width - sourceLeft),
  );
  const sourceHeight = Math.max(
    1,
    Math.min(viewportCanvas.canvas.height, sourceCanvas.height - sourceTop),
  );

  viewportCanvas.context.drawImage(
    sourceCanvas,
    sourceLeft,
    sourceTop,
    sourceWidth,
    sourceHeight,
    0,
    0,
    sourceWidth,
    sourceHeight,
  );

  return viewportCanvas.canvas;
};

const captureVisibleViewport = async (
  htmlToImage: Pick<HtmlToImageModule, "toCanvas">,
  viewportWidth: number,
  viewportHeight: number,
  captureScale: number,
): Promise<HTMLCanvasElement> => {
  const isAtDocumentOrigin = Math.abs(window.scrollX) < 1 && Math.abs(window.scrollY) < 1;
  if (isAtDocumentOrigin) {
    return captureViewportAtOrigin(htmlToImage, viewportWidth, viewportHeight, captureScale);
  }

  return captureScrolledViewport(htmlToImage, viewportWidth, viewportHeight, captureScale);
};

export const captureStepScreenshot = async (target: Element): Promise<string | undefined> => {
  if (!(target instanceof HTMLElement) || !target.isConnected) {
    return undefined;
  }

  const rect = target.getBoundingClientRect();
  if (rect.width < 1 || rect.height < 1) {
    return undefined;
  }

  const htmlToImage = await loadHtmlToImage();
  if (!htmlToImage) {
    return undefined;
  }

  try {
    const viewportWidth = Math.max(window.innerWidth, 1);
    const viewportHeight = Math.max(window.innerHeight, 1);
    const deviceScale = typeof window.devicePixelRatio === "number" ? window.devicePixelRatio : 1;
    const captureScale = Math.min(Math.max(deviceScale, MIN_CAPTURE_SCALE), MAX_CAPTURE_SCALE);
    const canvas = await captureVisibleViewport(
      htmlToImage,
      viewportWidth,
      viewportHeight,
      captureScale,
    );

    applyScreenshotHighlight(canvas, rect, viewportWidth, viewportHeight);

    const screenshotDataUrl = canvas.toDataURL("image/png");
    return await compressScreenshotDataUrl(screenshotDataUrl, LOCAL_SCREENSHOT_MAX_BYTES, {
      mode: "fast",
    });
  } catch {
    return undefined;
  }
};
