import type { Recording, StepSkipCondition } from "@flowr/sdk-core";

export const resolveDraftTitle = (value: string, defaultTitle: string): string => {
  return value.trim() || defaultTitle;
};

export const updateRecordingStepInstruction = (
  recording: Recording,
  stepId: string,
  value: string,
): boolean => {
  const step = recording.steps.find((candidate) => candidate.id === stepId);
  if (!step) return false;
  step.instruction = value.trim() || undefined;
  recording.updatedAt = Date.now();
  return true;
};

export const deleteRecordingStep = (recording: Recording, stepId: string): boolean => {
  const before = recording.steps.length;
  recording.steps = recording.steps.filter((candidate) => candidate.id !== stepId);
  for (const step of recording.steps) {
    if (!step.skipCondition) continue;
    if (
      step.skipCondition.jumpToStepId === stepId ||
      step.skipCondition.referenceStepId === stepId
    ) {
      step.skipCondition = undefined;
    }
  }
  if (recording.steps.length === before) return false;
  recording.updatedAt = Date.now();
  return true;
};

export const updateRecordingStepSkipCondition = (
  recording: Recording,
  stepId: string,
  condition: StepSkipCondition | null,
): boolean => {
  const step = recording.steps.find((candidate) => candidate.id === stepId);
  if (!step) return false;
  step.skipCondition = condition ?? undefined;
  recording.updatedAt = Date.now();
  return true;
};

export const formatRecordingMeta = (recording: Recording): string => {
  const stepCount = recording.steps.length;
  const stepLabel = `${stepCount} step${stepCount === 1 ? "" : "s"}`;
  const updatedAt = recording.updatedAt ? new Date(recording.updatedAt).toLocaleString() : null;
  return updatedAt ? `${stepLabel} · ${updatedAt}` : stepLabel;
};
