import { findElement, type Recording, type Step } from "@flowr/sdk-core";
import { captureStepScreenshot } from "./screenshot-capture";

export type StepCaptureController = {
  appendStep: (step: Step, sourceTarget?: Element) => void;
  waitForPendingScreenshotCaptures: () => Promise<void>;
};

export type StepCaptureControllerOptions = {
  getCaptureScreenshots: () => boolean;
  getCurrentRecording: () => Recording | null;
  isBlocked: () => boolean;
  markUnsavedChanges: () => void;
  notify: () => void;
  onStepCaptured?: (recording: Recording, step: Step) => void;
  onStepUpdated?: (recording: Recording, step: Step) => void;
};

export const createStepCaptureController = ({
  getCaptureScreenshots,
  getCurrentRecording,
  isBlocked,
  markUnsavedChanges,
  notify,
  onStepCaptured,
  onStepUpdated,
}: StepCaptureControllerOptions): StepCaptureController => {
  const pendingScreenshotCaptures = new Set<Promise<void>>();

  const waitForPendingScreenshotCaptures = async (): Promise<void> => {
    if (pendingScreenshotCaptures.size === 0) {
      return;
    }

    await Promise.allSettled(Array.from(pendingScreenshotCaptures));
  };

  const maybeCaptureStepScreenshot = (
    recording: Recording,
    step: Step,
    sourceTarget?: Element,
  ): void => {
    if (!getCaptureScreenshots()) {
      return;
    }

    const target = sourceTarget ?? (step.selector ? findElement(step.selector) : null);
    if (!(target instanceof Element)) {
      return;
    }

    let task: Promise<void>;
    task = captureStepScreenshot(target)
      .then((screenshotDataUrl) => {
        if (!screenshotDataUrl) {
          return;
        }

        const activeRecording = getCurrentRecording();
        if (activeRecording !== recording) {
          return;
        }

        const activeStep = recording.steps.find((candidate) => candidate.id === step.id);
        if (!activeStep) {
          return;
        }

        activeStep.screenshotDataUrl = screenshotDataUrl;
        activeStep.screenshotUrl = undefined;
        recording.updatedAt = Date.now();
        notify();
        onStepUpdated?.(recording, activeStep);
      })
      .finally(() => {
        pendingScreenshotCaptures.delete(task);
      });

    pendingScreenshotCaptures.add(task);
  };

  const appendStep = (step: Step, sourceTarget?: Element): void => {
    const current = getCurrentRecording();
    if (!current || isBlocked()) return;
    current.steps.push(step);
    current.updatedAt = Date.now();
    markUnsavedChanges();
    notify();
    maybeCaptureStepScreenshot(current, step, sourceTarget);
    onStepCaptured?.(current, step);
  };

  return {
    appendStep,
    waitForPendingScreenshotCaptures,
  };
};
