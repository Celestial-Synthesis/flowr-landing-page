/**
 * @flowr/sdk-ui — recorder-panel
 * --------------------------------------------------------------------------
 * Shared, state-driven recorder panel rendered inside a Shadow DOM root
 * (typically the bubble panel created by `@flowr/sdk-core#mountBubble`).
 *
 * The panel is intentionally headless: callers pass a `RecorderPanelState`
 * snapshot plus action handlers, and `render(state)` rebuilds the DOM.
 *
 * Stable test contract (assert in Playwright):
 *   - [data-flowr-view="sign-in"]
 *   - [data-flowr-input="email"]
 *   - [data-flowr-input="code"]
 *   - [data-flowr-action="send-code"]
 *   - [data-flowr-action="verify"]
 *   - [data-flowr-view="recorder"]
 *   - [data-flowr-input="recording-title"]
 *   - [data-flowr-input="recording-visibility"]
 *   - [data-flowr-input="capture-screenshots"]
 *   - [data-flowr-step-list]
 *   - [data-flowr-step-row]
 *   - [data-flowr-input="step-instruction"]
 *   - [data-flowr-action="save"]
 *   - [data-flowr-action="discard"]
 *   - [data-flowr-action="step-delete"]
 *   - [data-flowr-action="step-toggle-advanced"]
 *   - [data-flowr-step-advanced]
 *   - [data-flowr-input="step-navigation-match-mode"]
 *   - [data-flowr-input="skip-condition-type"]
 *   - [data-flowr-input="skip-condition-jump-to"]
 *   - [data-flowr-input="skip-condition-reference"]
 *   - [data-flowr-input="skip-condition-selector-css"]
 *   - [data-flowr-action="skip-condition-pick"]
 *   - [data-flowr-action="tab-recorder"]
 *   - [data-flowr-action="tab-library"]
 *   - [data-flowr-action="library-reload"]
 *   - [data-flowr-input="library-search"]
 *   - [data-flowr-library-loading]
 *   - [data-flowr-library-empty]
 *   - [data-flowr-action="step-screenshot-preview"]
 *   - [data-flowr-screenshot-modal]
 */

import type {
  NavigationStepMatchMode,
  Recording,
  RecordingVisibility,
  SdkTheme,
  SelectorInfo,
  Step,
  StepSkipCondition,
} from "@flowr/sdk-core";
import {
  FLOWR_DEFAULT_ICON_DATA_URL,
  NAVIGATION_STEP_MATCH_MODE_OPTIONS,
  NAVIGATION_STEP_MATCH_MODE_SECTION_LABEL,
  getNavigationStepMatchMode,
  getStepSkipReferenceCandidates,
} from "@flowr/sdk-core";
import { createAutoScrollTracker } from "./recorder-panel-auto-scroll";
import { createRecorderPanelButton } from "./recorder-panel-button";
import { summarizeRecorderStep } from "./recorder-panel-step-summary";
import { ensureRecorderPanelStyle } from "./recorder-panel-styles";

export type RecorderPanelStatus = "idle" | "recording" | "replaying";

export type RecorderPanelView = "sign-in" | "recorder" | "library";

export type RecorderPanelLibraryStatus = "idle" | "loading" | "ready";

export type RecorderPanelAuthState = {
  isAuthenticated: boolean;
  pendingEmail?: string | null;
  signInError?: string | null;
  sessionEmail?: string | null;
  canSignOut?: boolean;
};

export type RecorderPanelState = {
  recording: Recording | null;
  status: RecorderPanelStatus;
  draftTitle: string;
  draftVisibility?: RecordingVisibility;
  captureScreenshots?: boolean;
  replayIndex: number | null;
  defaultTitle: string;
  hasUnsavedChanges?: boolean;
  canSave?: boolean;
  /** Active panel view. Defaults to "recorder" when omitted. */
  view?: RecorderPanelView;
  /** Optional auth state for hosted recorder SDK flows. */
  auth?: RecorderPanelAuthState;
  /** Saved recordings rendered in the library view. */
  recordings?: Recording[];
  /** Async state for the saved-recordings library view. */
  libraryStatus?: RecorderPanelLibraryStatus;
};

type RecorderPanelActionResult = void | Promise<unknown>;

export type RecorderPanelHandlers = {
  onSendCode?: (email: string) => RecorderPanelActionResult;
  onVerifyCode?: (code: string) => RecorderPanelActionResult;
  onUseDifferentEmail?: () => RecorderPanelActionResult;
  onSignOut?: () => RecorderPanelActionResult;
  onStart: () => RecorderPanelActionResult;
  onStop: () => RecorderPanelActionResult;
  onReplay: () => RecorderPanelActionResult;
  onStopReplay: () => RecorderPanelActionResult;
  onSave?: () => RecorderPanelActionResult;
  onDiscard?: () => RecorderPanelActionResult;
  /** Called on every keystroke in the title input. */
  onTitleInput: (value: string) => void;
  /** Called when the title input commits (blur / change). */
  onTitleCommit: () => void;
  /** Called when the visibility select changes. */
  onVisibilityChange?: (value: RecordingVisibility) => void;
  /** Called when the screenshot capture toggle changes. */
  onCaptureScreenshotsChange?: (value: boolean) => RecorderPanelActionResult;
  /** Called on every keystroke in a step instruction textarea. */
  onStepInstructionInput: (stepId: string, value: string) => void;
  /** Called when a step instruction commits (blur / change). */
  onStepInstructionCommit: () => void;
  /** Remove a step from the recording. */
  onStepDelete?: (stepId: string) => void;
  /** Update how a navigation step determines that the destination has been reached. */
  onStepNavigationMatchModeChange?: (stepId: string, mode: NavigationStepMatchMode) => void;
  /**
   * Update or clear a step's skip condition. Pass `null` to remove the
   * condition entirely.
   */
  onStepSkipConditionChange?: (stepId: string, condition: StepSkipCondition | null) => void;
  /**
   * Activate a one-shot element picker on the host page. The recorder
   * runtime should suppress the next click, resolve the clicked element
   * to a {@link SelectorInfo}, and invoke `onPicked`. `onPicked(null)`
   * indicates the picker was canceled (e.g. user pressed Escape).
   */
  onPickElement?: (onPicked: (selector: SelectorInfo | null) => void) => void;
  /** Switch the panel to the saved-recordings library view. */
  onOpenLibrary?: () => RecorderPanelActionResult;
  /** Return from the library view back to the recorder view. */
  onCloseLibrary?: () => RecorderPanelActionResult;
  /** Load a saved recording into the active recorder slot. */
  onLoadRecording?: (recordingId: string) => RecorderPanelActionResult;
  /** Permanently delete a saved recording from the library. */
  onDeleteRecording?: (recordingId: string) => RecorderPanelActionResult;
  /** Replay a saved recording without first loading it as the active draft. */
  onReplayRecording?: (recordingId: string) => RecorderPanelActionResult;
  /** Refresh the saved-recordings library cache. */
  onReloadLibrary?: () => RecorderPanelActionResult;
};

const createSignOutIcon = (): SVGSVGElement => {
  const svgNs = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(svgNs, "svg");
  svg.setAttribute("viewBox", "0 0 20 20");
  svg.setAttribute("fill", "currentColor");
  svg.setAttribute("aria-hidden", "true");

  const path = document.createElementNS(svgNs, "path");
  path.setAttribute(
    "d",
    "M3 10a1 1 0 0 1 1-1h6a1 1 0 1 1 0 2H4a1 1 0 0 1-1-1Zm8.293-3.707a1 1 0 0 1 1.414 0l3 3a1 1 0 0 1 0 1.414l-3 3a1 1 0 1 1-1.414-1.414L12.586 11H10a1 1 0 1 1 0-2h2.586l-1.293-1.293a1 1 0 0 1 0-1.414ZM6 3a2 2 0 0 0-2 2v2a1 1 0 1 0 2 0V5h6v10H6v-2a1 1 0 1 0-2 0v2a2 2 0 0 0 2 2h7a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1H6Z",
  );
  svg.appendChild(path);
  return svg;
};
export type RecorderPanelOptions = {
  /** Element where the panel is rendered. Typically `bubble.panelEl`. */
  root: HTMLElement;
  handlers: RecorderPanelHandlers;
  theme?: SdkTheme;
};

export type RecorderPanelHandle = {
  render: (state: RecorderPanelState) => void;
  destroy: () => void;
};

const applyThemeVariables = (element: HTMLElement, theme?: SdkTheme): void => {
  if (!theme) {
    return;
  }

  const mappings: Array<[keyof SdkTheme, string]> = [
    ["fontFamily", "--flowr-sdk-font-family"],
    ["accentColor", "--flowr-sdk-accent"],
    ["accentForeground", "--flowr-sdk-accent-foreground"],
    ["panelBackground", "--flowr-sdk-panel-background"],
    ["surfaceBackground", "--flowr-sdk-surface-background"],
    ["surfaceMutedBackground", "--flowr-sdk-surface-muted-background"],
    ["panelForeground", "--flowr-sdk-panel-foreground"],
    ["panelBorderColor", "--flowr-sdk-panel-border"],
    ["mutedForeground", "--flowr-sdk-panel-muted"],
    ["overlayBackground", "--flowr-sdk-overlay-background"],
    ["overlayForeground", "--flowr-sdk-overlay-foreground"],
  ];

  mappings.forEach(([key, variableName]) => {
    const value = theme[key];
    if (typeof value === "string" && value.trim()) {
      element.style.setProperty(variableName, value.trim());
    }
  });
};

const normalizeLibrarySearch = (value: string): string => value.trim().toLowerCase();

const matchesLibrarySearch = (recording: Recording, query: string): boolean => {
  if (!query) {
    return true;
  }

  const haystack = [recording.title]
    .filter((value): value is string => typeof value === "string" && value.length > 0)
    .join(" ")
    .toLowerCase();
  return haystack.includes(query);
};

const createBrandIcon = (): HTMLSpanElement => {
  const icon = document.createElement("span");
  icon.className = "wr-brand-icon";
  icon.setAttribute("aria-hidden", "true");

  const image = document.createElement("img");
  image.src = FLOWR_DEFAULT_ICON_DATA_URL;
  image.alt = "";
  image.decoding = "async";
  icon.appendChild(image);

  return icon;
};

export const createRecorderPanel = ({
  root,
  handlers,
  theme,
}: RecorderPanelOptions): RecorderPanelHandle => {
  ensureRecorderPanelStyle(root);
  let lastState: RecorderPanelState | null = null;
  let previewStepId: string | null = null;
  let previewModalEl: HTMLDivElement | null = null;
  let librarySearch = "";
  let shouldRestoreLibrarySearchFocus = false;

  // Track which step rows have their advanced section open. Keyed by
  // step id so re-renders preserve the toggle state.
  const advancedOpen = new Set<string>();

  const resolveStepScreenshotSrc = (step: Step): string | null => {
    return step.screenshotDataUrl ?? step.screenshotUrl ?? null;
  };

  const rerender = (): void => {
    if (!lastState) {
      return;
    }

    render(lastState);
  };

  const removePreviewModal = (): void => {
    previewModalEl?.remove();
    previewModalEl = null;
  };

  const closePreviewModal = (): void => {
    previewStepId = null;
    removePreviewModal();
    rerender();
  };

  const resolvePreviewModalHost = (): ShadowRoot | HTMLElement => {
    const owner = root.getRootNode();
    if (owner instanceof ShadowRoot) {
      return owner;
    }

    return root.ownerDocument?.body ?? document.body ?? root;
  };

  const createPreviewModal = (): HTMLDivElement => {
    const modal = document.createElement("div");
    modal.className = "wr-screenshot-modal";
    modal.setAttribute("data-flowr-screenshot-modal", "");
    applyThemeVariables(modal, theme);
    modal.addEventListener("click", closePreviewModal);

    const modalCard = document.createElement("div");
    modalCard.className = "wr-screenshot-modal-card";
    modalCard.addEventListener("click", (event) => {
      event.stopPropagation();
    });

    const modalHeader = document.createElement("div");
    modalHeader.className = "wr-screenshot-modal-header";

    const modalTitle = document.createElement("strong");
    modalTitle.setAttribute("data-flowr-screenshot-modal-title", "");

    const closeButton = document.createElement("button");
    closeButton.type = "button";
    closeButton.className = "secondary";
    closeButton.textContent = "Close";
    closeButton.addEventListener("click", closePreviewModal);

    modalHeader.append(modalTitle, closeButton);

    const modalImage = document.createElement("img");
    modalImage.className = "wr-screenshot-modal-image";

    modalCard.append(modalHeader, modalImage);
    modal.appendChild(modalCard);
    return modal;
  };

  const syncPreviewModal = (state: RecorderPanelState): void => {
    const previewIndex = previewStepId
      ? (state.recording?.steps.findIndex((step) => step.id === previewStepId) ?? -1)
      : -1;
    const previewStep = previewIndex >= 0 ? state.recording?.steps[previewIndex] : null;
    const previewSrc = previewStep ? resolveStepScreenshotSrc(previewStep) : null;
    if (!previewStep || !previewSrc) {
      previewStepId = null;
      removePreviewModal();
      return;
    }

    if (!previewModalEl) {
      previewModalEl = createPreviewModal();
    }

    const modalTitle = previewModalEl.querySelector<HTMLElement>(
      "[data-flowr-screenshot-modal-title]",
    );
    const modalImage = previewModalEl.querySelector<HTMLImageElement>(".wr-screenshot-modal-image");
    const title = `Step ${previewIndex + 1} screenshot`;
    if (modalTitle) {
      modalTitle.textContent = title;
    }
    if (modalImage) {
      modalImage.src = previewSrc;
      modalImage.alt = title;
    }

    if (!previewModalEl.isConnected) {
      resolvePreviewModalHost().appendChild(previewModalEl);
    }
  };

  const renderAdvancedSection = (step: Step, recording: Recording): HTMLElement => {
    const wrap = document.createElement("div");
    wrap.className = "wr-step-advanced";
    wrap.setAttribute("data-flowr-step-advanced", "");

    const condition = step.skipCondition;
    const isNavigationStep = step.kind === "navigation";
    const stepIdx = recording.steps.findIndex((s) => s.id === step.id);
    const laterSteps = recording.steps.slice(stepIdx + 1);
    const referenceSteps = getStepSkipReferenceCandidates(recording, stepIdx);

    if (isNavigationStep) {
      const navigationLabel = document.createElement("label");
      navigationLabel.className = "wr-step-navigation-match-mode";
      const navigationSection = document.createElement("span");
      navigationSection.className = "wr-step-advanced-section-label";
      navigationSection.setAttribute("data-flowr-copy", "navigation-match-label");
      navigationSection.textContent = NAVIGATION_STEP_MATCH_MODE_SECTION_LABEL;

      const navigationSelect = document.createElement("select");
      navigationSelect.setAttribute("data-flowr-input", "step-navigation-match-mode");
      for (const option of NAVIGATION_STEP_MATCH_MODE_OPTIONS) {
        const opt = document.createElement("option");
        opt.value = option.value;
        opt.textContent = option.label;
        navigationSelect.appendChild(opt);
      }
      navigationSelect.value = getNavigationStepMatchMode(step);

      const navigationHint = document.createElement("div");
      navigationHint.className = "wr-step-advanced-hint";
      navigationHint.setAttribute("data-flowr-copy", "navigation-match-hint");

      const updateNavigationHint = (): void => {
        const option = NAVIGATION_STEP_MATCH_MODE_OPTIONS.find(
          (candidate) => candidate.value === navigationSelect.value,
        );
        navigationHint.textContent = option?.description ?? "";
      };

      navigationSelect.addEventListener("change", () => {
        updateNavigationHint();
        handlers.onStepNavigationMatchModeChange?.(
          step.id,
          navigationSelect.value as NavigationStepMatchMode,
        );
      });
      updateNavigationHint();

      navigationLabel.append(navigationSection, navigationSelect);
      wrap.appendChild(navigationLabel);
      wrap.appendChild(navigationHint);
    }

    const skipSection = document.createElement("div");
    skipSection.className = isNavigationStep
      ? "wr-step-advanced-skip-section has-navigation-match-mode"
      : "wr-step-advanced-skip-section";
    skipSection.setAttribute("data-flowr-step-skip-section", "");

    const typeLabel = document.createElement("label");
    const typeText = document.createElement("span");
    typeText.textContent = "Skip condition";
    const typeSelect = document.createElement("select");
    typeSelect.setAttribute("data-flowr-input", "skip-condition-type");
    const noneOpt = document.createElement("option");
    noneOpt.value = "";
    noneOpt.textContent = "None — always run";
    typeSelect.appendChild(noneOpt);
    for (const value of [
      "element-not-visible",
      "element-visible",
      "step-skipped",
      "step-not-skipped",
    ] as const) {
      const opt = document.createElement("option");
      opt.value = value;
      opt.textContent = value;
      typeSelect.appendChild(opt);
    }
    typeSelect.value = condition?.type ?? "";
    typeLabel.append(typeText, typeSelect);
    skipSection.appendChild(typeLabel);
    wrap.appendChild(skipSection);

    const buildJumpSelect = (): HTMLSelectElement => {
      const sel = document.createElement("select");
      sel.setAttribute("data-flowr-input", "skip-condition-jump-to");
      for (const s of laterSteps) {
        const opt = document.createElement("option");
        opt.value = s.id;
        const idx = recording.steps.findIndex((x) => x.id === s.id) + 1;
        opt.textContent = `Step ${idx} · ${s.kind}`;
        sel.appendChild(opt);
      }
      const endOpt = document.createElement("option");
      endOpt.value = "";
      endOpt.textContent = "End of recording";
      sel.appendChild(endOpt);
      return sel;
    };

    const buildReferenceSelect = (): HTMLSelectElement => {
      const sel = document.createElement("select");
      sel.setAttribute("data-flowr-input", "skip-condition-reference");
      for (const s of referenceSteps) {
        const opt = document.createElement("option");
        opt.value = s.id;
        const idx = recording.steps.findIndex((x) => x.id === s.id) + 1;
        opt.textContent = `Step ${idx} · ${s.kind}`;
        sel.appendChild(opt);
      }
      if (referenceSteps.length === 0) {
        const opt = document.createElement("option");
        opt.value = "";
        opt.textContent = "No prior conditional step available";
        sel.appendChild(opt);
        sel.disabled = true;
      }
      return sel;
    };

    let jumpSelect: HTMLSelectElement | null = null;
    let referenceSelect: HTMLSelectElement | null = null;
    let selectorInput: HTMLInputElement | null = null;
    // Held in a closure so the picker callback updates the live form
    // even after re-renders triggered by typeSelect changes.
    let pickedSelector: SelectorInfo | undefined =
      condition?.type === "element-visible" ? condition.selector : undefined;

    const renderConditionFields = (): void => {
      // Remove any previously-rendered fields.
      skipSection.querySelectorAll("[data-flowr-condition-field]").forEach((node) => node.remove());
      jumpSelect = null;
      referenceSelect = null;
      selectorInput = null;
      const type = typeSelect.value;
      if (!type) return;

      if (type === "element-visible") {
        const selectorLabel = document.createElement("label");
        selectorLabel.dataset.flowrConditionField = "selector";
        const selectorText = document.createElement("span");
        selectorText.textContent = "Watch this element";
        const row = document.createElement("div");
        row.className = "wr-pick-row";
        const cssInput = document.createElement("input");
        cssInput.type = "text";
        cssInput.setAttribute("data-flowr-input", "skip-condition-selector-css");
        cssInput.placeholder = "CSS selector — e.g. .toast--success";
        cssInput.value = pickedSelector?.css ?? step.selector?.css ?? "";
        const pickButton = document.createElement("button");
        pickButton.type = "button";
        pickButton.dataset.flowrAction = "skip-condition-pick";
        pickButton.textContent = "Pick";
        if (!handlers.onPickElement) {
          pickButton.disabled = true;
          pickButton.title = "Element picker is not available in this host.";
        }
        pickButton.addEventListener("click", () => {
          if (!handlers.onPickElement) return;
          pickButton.dataset.flowrPicking = "true";
          pickButton.textContent = "Click an element…";
          handlers.onPickElement((sel) => {
            pickButton.dataset.flowrPicking = "false";
            pickButton.textContent = "Pick";
            if (!sel) return;
            pickedSelector = sel;
            cssInput.value = sel.css ?? "";
            commitCondition();
          });
        });
        cssInput.addEventListener("input", () => {
          // Treat manual edits as overriding the picked selector. We
          // build a minimal SelectorInfo on commit to keep the contract
          // identical for the engine.
          pickedSelector = undefined;
        });
        cssInput.addEventListener("change", commitCondition);
        row.append(cssInput, pickButton);
        selectorLabel.append(selectorText, row);
        skipSection.appendChild(selectorLabel);
        selectorInput = cssInput;
      }

      if (type === "step-skipped" || type === "step-not-skipped") {
        const refLabel = document.createElement("label");
        refLabel.dataset.flowrConditionField = "reference";
        const refText = document.createElement("span");
        refText.textContent =
          type === "step-skipped" ? "When this step was skipped" : "When this step was not skipped";
        const refSel = buildReferenceSelect();
        refSel.value = condition?.referenceStepId ?? referenceSteps[0]?.id ?? "";
        refLabel.append(refText, refSel);
        skipSection.appendChild(refLabel);
        referenceSelect = refSel;
      }

      const jumpLabel = document.createElement("label");
      jumpLabel.dataset.flowrConditionField = "jump";
      const jumpText = document.createElement("span");
      jumpText.textContent = "Jump to step";
      const jumpSel = buildJumpSelect();
      jumpSel.value = condition?.jumpToStepId ?? laterSteps[0]?.id ?? "";
      jumpLabel.append(jumpText, jumpSel);
      skipSection.appendChild(jumpLabel);
      jumpSelect = jumpSel;
    };

    const commitCondition = (): void => {
      if (!handlers.onStepSkipConditionChange) return;
      const type = typeSelect.value as
        | ""
        | "element-not-visible"
        | "element-visible"
        | "step-skipped"
        | "step-not-skipped";
      if (!type) {
        handlers.onStepSkipConditionChange(step.id, null);
        return;
      }
      const jumpToStepId = jumpSelect?.value ?? "";
      const next: StepSkipCondition = {
        type,
        jumpToStepId,
      };
      if (type === "element-visible") {
        // Prefer the picked SelectorInfo (rich attributes) when available;
        // otherwise build a CSS-only SelectorInfo from the manual input.
        const css = selectorInput?.value.trim() ?? "";
        if (pickedSelector) {
          next.selector = pickedSelector;
        } else if (css) {
          next.selector = { css };
        } else if (step.selector) {
          next.selector = step.selector;
        }
        if (!next.selector) return;
      }
      if (type === "step-skipped" || type === "step-not-skipped") {
        const ref = referenceSelect?.value ?? "";
        if (!ref) return;
        next.referenceStepId = ref;
      }
      handlers.onStepSkipConditionChange(step.id, next);
    };

    typeSelect.addEventListener("change", () => {
      renderConditionFields();
      commitCondition();
      attachFieldListeners();
    });

    const attachFieldListeners = (): void => {
      if (jumpSelect) {
        jumpSelect.addEventListener("change", commitCondition);
      }
      if (referenceSelect) {
        referenceSelect.addEventListener("change", commitCondition);
      }
    };

    renderConditionFields();
    attachFieldListeners();

    return wrap;
  };

  const renderStepList = (container: HTMLElement, state: RecorderPanelState): void => {
    const list = document.createElement("div");
    list.className = "wr-steps";
    list.setAttribute("data-flowr-step-list", "");

    const recording = state.recording;
    if (!recording || recording.steps.length === 0) {
      const empty = document.createElement("div");
      empty.className = "wr-steps-empty";
      empty.textContent =
        "Recorded actions will appear here. Click, type, or right-click an element to capture hover, context-click, or instruction steps.";
      list.appendChild(empty);
      container.appendChild(list);
      return;
    }

    recording.steps.forEach((step, stepIndex) => {
      const row = document.createElement("div");
      row.className = "wr-step";
      row.setAttribute("data-flowr-step-row", "");
      row.setAttribute("data-active", state.replayIndex === stepIndex ? "true" : "false");

      const meta = document.createElement("div");
      meta.className = "wr-step-meta";

      const count = document.createElement("span");
      count.className = "wr-step-count";
      count.textContent = String(stepIndex + 1);

      const kind = document.createElement("span");
      kind.className = "wr-step-kind";
      kind.textContent = step.kind;

      meta.append(count, kind);

      const summary = document.createElement("div");
      summary.className = "wr-step-summary";
      summary.textContent = summarizeRecorderStep(step);

      const screenshotSrc = resolveStepScreenshotSrc(step);
      let screenshotPreviewButton: HTMLButtonElement | null = null;
      if (screenshotSrc) {
        screenshotPreviewButton = document.createElement("button");
        screenshotPreviewButton.type = "button";
        screenshotPreviewButton.className = "wr-step-screenshot-button";
        screenshotPreviewButton.dataset.flowrAction = "step-screenshot-preview";
        screenshotPreviewButton.setAttribute(
          "aria-label",
          `Preview screenshot for step ${stepIndex + 1}`,
        );
        screenshotPreviewButton.setAttribute(
          "title",
          `Preview screenshot for step ${stepIndex + 1}`,
        );

        const screenshotImg = document.createElement("img");
        screenshotImg.src = screenshotSrc;
        screenshotImg.alt = `Screenshot for step ${stepIndex + 1}`;

        screenshotPreviewButton.appendChild(screenshotImg);
        screenshotPreviewButton.addEventListener("click", () => {
          previewStepId = step.id;
          rerender();
        });
      }

      const instruction = document.createElement("textarea");
      instruction.className = "wr-step-instruction-input";
      instruction.setAttribute("data-flowr-input", "step-instruction");
      instruction.placeholder = "Tooltip instruction shown during replay";
      instruction.value = step.instruction ?? "";
      instruction.addEventListener("input", () => {
        handlers.onStepInstructionInput(step.id, instruction.value);
      });
      instruction.addEventListener("change", () => {
        handlers.onStepInstructionCommit();
      });

      const toolbar = document.createElement("div");
      toolbar.className = "wr-step-toolbar";

      const advancedToggle = document.createElement("button");
      advancedToggle.type = "button";
      advancedToggle.dataset.flowrAction = "step-toggle-advanced";
      const isOpen = advancedOpen.has(step.id) || Boolean(step.skipCondition);
      if (isOpen) advancedOpen.add(step.id);
      advancedToggle.textContent = isOpen ? "Hide advanced" : "Advanced";
      advancedToggle.addEventListener("click", () => {
        if (advancedOpen.has(step.id)) {
          advancedOpen.delete(step.id);
        } else {
          advancedOpen.add(step.id);
        }
        // Re-render only this row's advanced section.
        const existing = row.querySelector("[data-flowr-step-advanced]");
        if (existing) {
          existing.remove();
          advancedToggle.textContent = "Advanced";
        } else {
          row.appendChild(renderAdvancedSection(step, recording));
          advancedToggle.textContent = "Hide advanced";
        }
      });

      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.dataset.flowrAction = "step-delete";
      deleteButton.textContent = "Delete";
      deleteButton.addEventListener("click", () => {
        handlers.onStepDelete?.(step.id);
      });
      // Disable edits only while a replay is in flight. During an active
      // recording session the user can prune or annotate captured steps
      // (matching the FlowR extension's panel behavior).
      if (state.status === "replaying") {
        advancedToggle.disabled = true;
        deleteButton.disabled = true;
      }

      toolbar.append(advancedToggle, deleteButton);

      row.append(meta, summary);
      if (screenshotPreviewButton) {
        row.appendChild(screenshotPreviewButton);
      }
      row.append(instruction, toolbar);
      if (isOpen) {
        row.appendChild(renderAdvancedSection(step, recording));
      }
      list.appendChild(row);
    });

    container.appendChild(list);
  };

  const formatRecordingMeta = (recording: Recording): string => {
    const stepCount = recording.steps.length;
    const stepLabel = `${stepCount} step${stepCount === 1 ? "" : "s"}`;
    const updated = recording.updatedAt ? new Date(recording.updatedAt).toLocaleString() : null;
    return updated ? `${stepLabel} · ${updated}` : stepLabel;
  };

  const getFilteredLibraryRecordings = (recordings: Recording[]): Recording[] => {
    const normalizedQuery = normalizeLibrarySearch(librarySearch);
    const sorted = [...recordings].sort((a, b) => (b.updatedAt ?? 0) - (a.updatedAt ?? 0));
    return sorted.filter((recording) => matchesLibrarySearch(recording, normalizedQuery));
  };

  const renderLibraryList = (container: HTMLElement, state: RecorderPanelState): void => {
    const recordings = state.recordings ?? [];
    if (recordings.length > 0 || handlers.onReloadLibrary) {
      const controls = document.createElement("div");
      controls.className = "wr-library-controls";

      if (recordings.length > 0) {
        const searchLabel = document.createElement("label");
        searchLabel.className = "wr-field-label";
        searchLabel.textContent = "Search saved recordings";

        const searchRow = document.createElement("div");
        searchRow.className = "wr-library-search-row";

        const searchInput = document.createElement("input");
        searchInput.type = "search";
        searchInput.className = "wr-title-input wr-library-search-input";
        searchInput.placeholder = "Search saved recording titles";
        searchInput.value = librarySearch;
        searchInput.setAttribute("data-flowr-input", "library-search");
        searchInput.addEventListener("input", () => {
          librarySearch = searchInput.value;
          shouldRestoreLibrarySearchFocus = true;
          rerender();
        });
        searchRow.appendChild(searchInput);

        searchLabel.appendChild(searchRow);
        controls.appendChild(searchLabel);
      }

      if (handlers.onReloadLibrary) {
        const reload = createRecorderPanelButton(
          "Reload",
          () => handlers.onReloadLibrary?.(),
          "secondary",
        );
        reload.dataset.flowrAction = "library-reload";
        reload.disabled = state.libraryStatus === "loading" || !handlers.onReloadLibrary;
        controls.appendChild(reload);
      }

      container.appendChild(controls);
    }

    if (state.libraryStatus === "loading" && recordings.length === 0) {
      const loading = document.createElement("div");
      loading.className = "wr-library-loading";
      loading.setAttribute("data-flowr-library-loading", "");
      loading.textContent = "Loading saved recordings...";
      container.appendChild(loading);
      return;
    }

    const list = document.createElement("div");
    list.className = "wr-library";
    list.setAttribute("data-flowr-recording-list", "");

    if (recordings.length === 0) {
      const empty = document.createElement("div");
      empty.className = "wr-library-empty";
      empty.setAttribute("data-flowr-library-empty", "");
      empty.textContent = "No saved recordings yet. Record a flow to see it appear here.";
      list.appendChild(empty);
      container.appendChild(list);
      return;
    }

    const filteredRecordings = getFilteredLibraryRecordings(recordings);
    if (filteredRecordings.length === 0) {
      const empty = document.createElement("div");
      empty.className = "wr-library-empty";
      empty.setAttribute("data-flowr-library-empty", "");
      empty.textContent = `No saved recordings match "${librarySearch.trim()}".`;
      list.appendChild(empty);
      container.appendChild(list);
      return;
    }

    for (const rec of filteredRecordings) {
      const row = document.createElement("div");
      row.className = "wr-library-row";
      row.setAttribute("data-flowr-recording-row", "");
      row.setAttribute("data-recording-id", rec.id);
      row.setAttribute("data-active", state.recording?.id === rec.id ? "true" : "false");

      const titleEl = document.createElement("div");
      titleEl.className = "wr-library-title";
      titleEl.setAttribute("data-flowr-recording-title", "");
      titleEl.textContent = rec.title || "Untitled recording";

      const meta = document.createElement("div");
      meta.className = "wr-library-meta";
      meta.textContent = formatRecordingMeta(rec);

      const toolbar = document.createElement("div");
      toolbar.className = "wr-library-toolbar";

      const replay = createRecorderPanelButton(
        "Replay",
        () => handlers.onReplayRecording?.(rec.id),
        "secondary",
      );
      replay.dataset.flowrAction = "library-replay";
      replay.disabled = rec.steps.length === 0 || !handlers.onReplayRecording;

      const load = createRecorderPanelButton(
        "Open",
        () => handlers.onLoadRecording?.(rec.id),
        "secondary",
      );
      load.dataset.flowrAction = "library-load";
      load.disabled = !handlers.onLoadRecording;

      const del = createRecorderPanelButton(
        "Delete",
        () => handlers.onDeleteRecording?.(rec.id),
        "secondary",
      );
      del.dataset.flowrAction = "library-delete";
      del.disabled = !handlers.onDeleteRecording;

      toolbar.append(replay, load, del);
      row.append(titleEl, meta, toolbar);
      list.appendChild(row);
    }

    container.appendChild(list);
  };

  const renderSignInPanel = (container: HTMLElement, state: RecorderPanelState): void => {
    const authState = state.auth;
    const pendingEmail = authState?.pendingEmail?.trim() ?? "";

    const helper = document.createElement("div");
    helper.className = "wr-auth-copy";
    helper.textContent = authState?.sessionEmail
      ? `Continue as ${authState.sessionEmail} by entering the emailed code.`
      : "Sign in to save and replay recordings. We’ll email you a one-time code.";
    container.appendChild(helper);

    if (!pendingEmail) {
      const emailLabel = document.createElement("label");
      emailLabel.className = "wr-field-label";
      emailLabel.textContent = "Email";

      const emailInput = document.createElement("input");
      emailInput.type = "email";
      emailInput.className = "wr-title-input";
      emailInput.setAttribute("data-flowr-input", "email");
      emailInput.placeholder = "name@example.com";
      emailLabel.appendChild(emailInput);
      container.appendChild(emailLabel);

      const actions = document.createElement("div");
      actions.className = "wr-auth-actions";
      const sendCode = createRecorderPanelButton(
        "Send code",
        () => {
          const email = emailInput.value.trim();
          if (!email || !handlers.onSendCode) {
            return;
          }
          return handlers.onSendCode(email);
        },
        "primary",
      );
      sendCode.dataset.span = "full";
      sendCode.disabled = !handlers.onSendCode;
      emailInput.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" || sendCode.disabled) {
          return;
        }
        event.preventDefault();
        sendCode.click();
      });
      actions.appendChild(sendCode);
      container.appendChild(actions);
    } else {
      const codeLabel = document.createElement("label");
      codeLabel.className = "wr-field-label";
      codeLabel.textContent = "Verification code";

      const codeInput = document.createElement("input");
      codeInput.type = "text";
      codeInput.inputMode = "numeric";
      codeInput.className = "wr-title-input";
      codeInput.setAttribute("data-flowr-input", "code");
      codeInput.placeholder = "Enter 6-digit code";
      codeLabel.appendChild(codeInput);
      container.appendChild(codeLabel);

      const actions = document.createElement("div");
      actions.className = "wr-auth-actions";

      const verify = createRecorderPanelButton(
        "Verify",
        () => {
          const code = codeInput.value.trim();
          if (!code || !handlers.onVerifyCode) {
            return;
          }
          return handlers.onVerifyCode(code);
        },
        "primary",
      );
      verify.disabled = !handlers.onVerifyCode;
      codeInput.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" || verify.disabled) {
          return;
        }
        event.preventDefault();
        verify.click();
      });

      const useDifferentEmail = createRecorderPanelButton(
        "Use a different email",
        () => handlers.onUseDifferentEmail?.(),
        "secondary",
      );
      useDifferentEmail.disabled = !handlers.onUseDifferentEmail;

      actions.append(verify, useDifferentEmail);
      container.appendChild(actions);
    }

    if (authState?.signInError) {
      const error = document.createElement("div");
      error.className = "wr-auth-error";
      error.textContent = authState.signInError;
      container.appendChild(error);
    }
  };

  const createTabButton = (
    label: "Recorder" | "Library",
    action: () => RecorderPanelActionResult,
    isActive: boolean,
  ): HTMLButtonElement => {
    const button = createRecorderPanelButton(label, action, "secondary");
    button.dataset.flowrAction = label === "Recorder" ? "tab-recorder" : "tab-library";
    button.dataset.active = isActive ? "true" : "false";
    button.setAttribute("role", "tab");
    button.setAttribute("aria-selected", isActive ? "true" : "false");
    return button;
  };

  const renderTabs = (view: RecorderPanelView): HTMLDivElement => {
    const tabs = document.createElement("div");
    tabs.className = "wr-tabs";
    tabs.setAttribute("role", "tablist");

    const recorderTab = createTabButton(
      "Recorder",
      () => handlers.onCloseLibrary?.(),
      view === "recorder",
    );
    const libraryTab = createTabButton(
      "Library",
      () => handlers.onOpenLibrary?.(),
      view === "library",
    );

    recorderTab.disabled = view === "recorder";
    libraryTab.disabled = view === "library" || !handlers.onOpenLibrary;

    tabs.append(recorderTab, libraryTab);
    return tabs;
  };

  /**
   * Per-instance auto-scroll bookkeeping. Each panel handle owns its
   * own tracker so multiple SDK panels mounted in the same realm don't
   * cross-talk, and `destroy()` can reset the state cleanly.
   */
  const autoScroll = createAutoScrollTracker();

  const render = (state: RecorderPanelState): void => {
    lastState = state;
    // Capture the existing step list scroll position before we tear down
    // the panel so we can restore it on re-renders that did NOT add a
    // step (advanced edits, instruction edits, deletions, etc.).
    const prevStepListEl = root.querySelector<HTMLElement>("[data-flowr-step-list]");
    const prevScrollTop = prevStepListEl ? prevStepListEl.scrollTop : 0;

    root.innerHTML = "";
    ensureRecorderPanelStyle(root);

    const view: RecorderPanelView =
      state.auth && !state.auth.isAuthenticated && !state.recording
        ? "sign-in"
        : (state.view ?? "recorder");
    const isRecordingActive = state.status === "recording";

    root.dataset.flowrRecordingActive = isRecordingActive ? "true" : "false";

    if (view !== "library" && librarySearch) {
      librarySearch = "";
    }

    const wrap = document.createElement("div");
    wrap.className = "wr-panel";
    wrap.setAttribute("data-flowr-view", view);
    applyThemeVariables(wrap, theme);

    const brand = document.createElement("div");
    brand.className = "wr-brand";
    const icon = createBrandIcon();
    const heading = document.createElement("h4");
    heading.textContent = view === "library" ? "FlowR Library" : "FlowR Recorder";
    brand.append(icon, heading);

    if (handlers.onSignOut && state.auth?.canSignOut && state.auth?.isAuthenticated) {
      const brandActions = document.createElement("div");
      brandActions.className = "wr-brand-actions";

      const signOut = createRecorderPanelButton(
        "Sign out",
        () => handlers.onSignOut?.(),
        "secondary",
        {
          renderIdleContent: (button) => {
            button.classList.add("wr-icon-button");
            button.classList.add("wr-sign-out-button");
            button.setAttribute("aria-label", "Logout");
            button.setAttribute("title", "Logout");
            button.textContent = "";
            button.appendChild(createSignOutIcon());
          },
        },
      );
      brandActions.appendChild(signOut);
      brand.appendChild(brandActions);
    }

    const tabs = renderTabs(view);

    if (view === "sign-in") {
      removePreviewModal();
      wrap.appendChild(brand);
      renderSignInPanel(wrap, state);
      root.appendChild(wrap);
      return;
    }

    if (view === "library") {
      removePreviewModal();
      const status = document.createElement("div");
      status.className = "wr-status";
      const totalCount = state.recordings?.length ?? 0;
      const filteredCount = getFilteredLibraryRecordings(state.recordings ?? []).length;
      if (state.libraryStatus === "loading" && totalCount === 0) {
        status.textContent = "Loading saved recordings...";
      } else if (librarySearch.trim()) {
        status.textContent = `${filteredCount} of ${totalCount} saved recording${totalCount === 1 ? "" : "s"}`;
      } else {
        status.textContent = `${totalCount} saved recording${totalCount === 1 ? "" : "s"}`;
      }

      wrap.append(brand, tabs, status);
      renderLibraryList(wrap, state);
      root.appendChild(wrap);
      if (shouldRestoreLibrarySearchFocus) {
        const searchInput = wrap.querySelector<HTMLInputElement>(
          '[data-flowr-input="library-search"]',
        );
        if (searchInput) {
          searchInput.focus();
          const length = searchInput.value.length;
          searchInput.setSelectionRange(length, length);
        }
      }
      shouldRestoreLibrarySearchFocus = false;
      return;
    }

    const fieldRow = document.createElement("div");
    fieldRow.className = "wr-field-row";

    const titleLabel = document.createElement("label");
    titleLabel.className = "wr-field-label";
    titleLabel.textContent = "Title";

    const title = document.createElement("input");
    title.type = "text";
    title.className = "wr-title-input";
    title.setAttribute("data-flowr-input", "recording-title");
    title.placeholder = state.defaultTitle;
    title.value = state.recording?.title ?? state.draftTitle;
    title.addEventListener("input", () => {
      handlers.onTitleInput(title.value);
    });
    title.addEventListener("change", () => {
      handlers.onTitleCommit();
    });
    titleLabel.appendChild(title);

    const visibilityLabel = document.createElement("label");
    visibilityLabel.className = "wr-field-label";
    visibilityLabel.textContent = "Visibility";

    const visibility = document.createElement("select");
    visibility.className = "wr-select-input";
    visibility.setAttribute("data-flowr-input", "recording-visibility");
    for (const optionValue of ["private", "public", "internal"] as const) {
      const option = document.createElement("option");
      option.value = optionValue;
      option.textContent =
        optionValue === "public" ? "Public" : optionValue === "internal" ? "Internal" : "Private";
      visibility.appendChild(option);
    }
    visibility.value = state.recording?.visibility ?? state.draftVisibility ?? "private";
    visibility.disabled = !handlers.onVisibilityChange;
    visibility.addEventListener("change", () => {
      handlers.onVisibilityChange?.(visibility.value as RecordingVisibility);
    });
    visibilityLabel.appendChild(visibility);

    const screenshotLabel = document.createElement("label");
    screenshotLabel.className = "wr-toggle-field";
    screenshotLabel.dataset.disabled = handlers.onCaptureScreenshotsChange ? "false" : "true";

    const screenshotCopy = document.createElement("span");
    screenshotCopy.className = "wr-toggle-copy";

    const screenshotTitle = document.createElement("span");
    screenshotTitle.className = "wr-toggle-title";
    screenshotTitle.textContent = "Step screenshots";

    const screenshotHint = document.createElement("span");
    screenshotHint.className = "wr-toggle-hint";
    screenshotHint.textContent = "Attach a screenshot to each new recorded step.";

    screenshotCopy.append(screenshotTitle, screenshotHint);

    const screenshotToggle = document.createElement("input");
    screenshotToggle.type = "checkbox";
    screenshotToggle.className = "wr-toggle-checkbox";
    screenshotToggle.checked = state.captureScreenshots === true;
    screenshotToggle.disabled = !handlers.onCaptureScreenshotsChange;
    screenshotToggle.setAttribute("data-flowr-input", "capture-screenshots");
    screenshotToggle.addEventListener("change", () => {
      handlers.onCaptureScreenshotsChange?.(screenshotToggle.checked);
    });

    screenshotLabel.append(screenshotCopy, screenshotToggle);

    fieldRow.append(titleLabel, visibilityLabel);
    if (!isRecordingActive) {
      fieldRow.appendChild(screenshotLabel);
    }

    const actions = document.createElement("div");
    actions.className = "wr-actions";
    const hasUnsavedChanges = Boolean(state.hasUnsavedChanges);
    if (state.status === "recording" || hasUnsavedChanges) {
      const save = createRecorderPanelButton("Save", () => handlers.onSave?.(), "primary");
      save.disabled = !state.canSave || !handlers.onSave;
      actions.appendChild(save);

      const discard = createRecorderPanelButton(
        "Discard",
        () => handlers.onDiscard?.(),
        "secondary",
      );
      discard.disabled = !handlers.onDiscard;
      actions.appendChild(discard);
    } else if (state.status === "replaying") {
      const stop = createRecorderPanelButton("Stop replay", handlers.onStopReplay, "secondary");
      stop.dataset.span = "full";
      actions.appendChild(stop);
    } else {
      const start = createRecorderPanelButton("Record", handlers.onStart, "primary");
      actions.appendChild(start);
      const replay = createRecorderPanelButton("Replay", handlers.onReplay, "secondary");
      const canReplay = Boolean(state.recording && state.recording.steps.length > 0);
      if (!canReplay) replay.disabled = true;
      actions.appendChild(replay);
    }

    const status = document.createElement("div");
    status.className = "wr-status";
    if (state.recording) {
      const stepCount = state.recording.steps.length;
      const label =
        state.status === "recording"
          ? "Recording"
          : state.status === "replaying"
            ? state.replayIndex !== null
              ? `Replaying step ${state.replayIndex + 1}`
              : "Replaying"
            : "Saved";
      status.textContent = `${label} · ${stepCount} step${stepCount === 1 ? "" : "s"}`;
    } else {
      status.textContent =
        state.status === "recording"
          ? "Recording started — interact with the page."
          : "Name the recording, then press Record.";
    }

    if (isRecordingActive) {
      wrap.append(brand, fieldRow, actions, status);
    } else {
      wrap.append(brand, tabs, fieldRow, actions, status);
    }
    renderStepList(wrap, state);

    root.appendChild(wrap);
    syncPreviewModal(state);

    if (view === "library" && shouldRestoreLibrarySearchFocus) {
      const searchInput = wrap.querySelector<HTMLInputElement>(
        '[data-flowr-input="library-search"]',
      );
      if (searchInput) {
        searchInput.focus();
        const length = searchInput.value.length;
        searchInput.setSelectionRange(length, length);
      }
    }
    shouldRestoreLibrarySearchFocus = false;

    autoScroll.apply({
      stepListEl: wrap.querySelector<HTMLElement>("[data-flowr-step-list]"),
      root,
      currentId: state.recording?.id ?? null,
      currentCount: state.recording?.steps.length ?? 0,
      activeIndex: state.replayIndex,
      prevScrollTop,
    });
  };

  return {
    render,
    destroy: () => {
      autoScroll.reset();
      removePreviewModal();
      lastState = null;
      previewStepId = null;
      librarySearch = "";
      shouldRestoreLibrarySearchFocus = false;
      delete root.dataset.flowrRecordingActive;
      root.innerHTML = "";
    },
  };
};
