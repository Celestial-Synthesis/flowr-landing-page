/**
 * @flowr/sdk-ui — one-line summary helper for recorder steps.
 *
 * Used by the recorder panel step list and the library row footer.
 */
import type { Step } from "@flowr/sdk-core";

export const summarizeRecorderStep = (step: Step): string => {
  if (step.kind === "input") {
    return step.value ? `Value: ${step.value}` : "Field update";
  }
  if (step.kind === "input password") {
    return "Password field";
  }
  if (step.kind === "click") {
    return step.textContent ? `Target: ${step.textContent}` : "Click target";
  }
  if (step.kind === "hover") {
    return step.textContent ? `Hover: ${step.textContent}` : "Hover target";
  }
  if (step.kind === "context-click") {
    return step.textContent ? `Right click: ${step.textContent}` : "Right click target";
  }
  if (step.kind === "scroll") {
    return step.textContent ? `Scroll to: ${step.textContent}` : "Scroll target";
  }
  if (step.kind === "key enter") return "Press Enter";
  if (step.kind === "key tab") return "Press Tab";
  if (step.kind === "key shift+tab") return "Press Shift+Tab";
  return step.kind;
};
