/**
 * @flowr/sdk-ui — recorder-interaction
 * --------------------------------------------------------------------------
 * Shared logic for the recorder's right-click context menu and the
 * instruction-prompt tooltip flow.
 *
 * Extension is the source of truth: this module is the verbatim port of
 * `src/content/context-menu.ts` and `src/content/instruction-prompt.ts`,
 * with two minimal seams for SDK consumers:
 *   - `documentRoot` may be a `Document` (extension) or `ShadowRoot` (SDK).
 *   - `buildButtons` is injectable so SDK consumers can present a different
 *     action set; the default matches the extension exactly.
 *
 * Stable test contract (assert in Playwright):
 *   - .wr-context-menu button[data-action="record-right-click"]
 *   - .wr-context-menu button[data-action="record-hover"]            (desktop)
 *   - .wr-context-menu button[data-action="add-instruction-to-section"]
 *   - .wr-context-menu button[data-action="cancel"]
 *   - .wr-tooltip textarea
 *   - .wr-tooltip button[data-action="save"]
 *   - .wr-tooltip button[data-action="cancel"]
 */

import { trackAnchoredTooltip } from "@flowr/sdk-core/anchored-tooltip-layout";

// ---------------------------------------------------------------------------
// Context menu controller
// ---------------------------------------------------------------------------

export type ContextMenuButtonSpec = {
  action: string;
  label: string;
};

export type ContextMenuActionHandlers = {
  onRecordHover: (target: Element) => Promise<void> | void;
  onAddInstructionToSection: (target: Element) => Promise<void> | void;
  onRecordRightClick: (target: Element) => Promise<void> | void;
  onCancel?: (target: Element) => Promise<void> | void;
};

export type ContextMenuControllerArgs = {
  contextMenu: HTMLElement;
  /** Mobile-aware label override; defaults to a no-op (desktop labels). */
  isMobile?: () => boolean;
  /**
   * Optional builder for the action buttons. When omitted, the extension's
   * exact button set is rendered.
   */
  buildButtons?: (args: { target: Element; isMobile: boolean }) => ContextMenuButtonSpec[];
};

export type ContextMenuController = {
  isOpen: () => boolean;
  close: () => void;
  show: (x: number, y: number, target: Element) => void;
  contains: (target: Element | null) => boolean;
  bindActions: (handlers: ContextMenuActionHandlers) => void;
};

const defaultBuildButtons = ({
  isMobile,
}: {
  target: Element;
  isMobile: boolean;
}): ContextMenuButtonSpec[] => {
  const buttons: ContextMenuButtonSpec[] = [
    {
      action: "record-right-click",
      label: isMobile ? "Record long hold" : "Record right click",
    },
  ];
  if (!isMobile) {
    buttons.push({ action: "record-hover", label: "Record hover" });
  }
  buttons.push({ action: "add-instruction-to-section", label: "Add instruction to section" });
  buttons.push({ action: "cancel", label: "Cancel" });
  return buttons;
};

export const createContextMenuController = ({
  contextMenu,
  isMobile,
  buildButtons,
}: ContextMenuControllerArgs): ContextMenuController => {
  let isOpen = false;
  let currentTarget: Element | null = null;

  const close = (): void => {
    if (!isOpen) return;
    contextMenu.hidden = false;
    contextMenu.style.display = "none";
    contextMenu.style.visibility = "hidden";
    contextMenu.replaceChildren();
    isOpen = false;
    currentTarget = null;
  };

  const show = (x: number, y: number, target: Element): void => {
    currentTarget = target;
    contextMenu.replaceChildren();

    const mobile = isMobile?.() ?? false;
    const specs = (buildButtons ?? defaultBuildButtons)({ target, isMobile: mobile });
    const buttons = specs.map((spec) => {
      const button = document.createElement("button");
      button.type = "button";
      button.dataset.action = spec.action;
      button.textContent = spec.label;
      return button;
    });
    contextMenu.append(...buttons);

    // Position at mouse coordinates, then clamp to viewport so the menu
    // never extends beyond the visible area.
    contextMenu.style.left = `${x}px`;
    contextMenu.style.top = `${y}px`;
    contextMenu.hidden = false;
    contextMenu.style.display = "flex";
    contextMenu.style.visibility = "visible";

    const rect = contextMenu.getBoundingClientRect();
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;

    if (rect.right > viewportWidth) {
      contextMenu.style.left = `${Math.max(0, x - (rect.right - viewportWidth))}px`;
    }
    if (rect.bottom > viewportHeight) {
      contextMenu.style.top = `${Math.max(0, y - (rect.bottom - viewportHeight))}px`;
    }

    isOpen = true;
  };

  const contains = (target: Element | null): boolean => {
    return !!target && contextMenu.contains(target);
  };

  const bindActions = (handlers: ContextMenuActionHandlers): void => {
    contextMenu.addEventListener("click", (event) => {
      const button = (event.target as Element | null)?.closest("button[data-action]");
      if (!button) return;
      const action = button.getAttribute("data-action");
      const target = currentTarget;
      close();
      if (!target) return;

      if (action === "record-hover") {
        void handlers.onRecordHover(target);
        return;
      }
      if (action === "add-instruction-to-section" || action === "add-instruction") {
        void handlers.onAddInstructionToSection(target);
        return;
      }
      if (action === "record-right-click") {
        void handlers.onRecordRightClick(target);
        return;
      }
      if (action === "cancel") {
        void handlers.onCancel?.(target);
      }
    });
  };

  return {
    isOpen: () => isOpen,
    close,
    show,
    contains,
    bindActions,
  };
};

// ---------------------------------------------------------------------------
// Instruction prompt controller
// ---------------------------------------------------------------------------

export type InstructionPromptControllerArgs = {
  /** Document or ShadowRoot used for `createElement` and capture-phase listeners. */
  documentRoot: Document | ShadowRoot;
  /** Element whose contents (and the tooltip's contents) should not be blocked. */
  panel: HTMLElement;
  /** Tooltip host element; will be repopulated each prompt and shown/hidden. */
  tooltip: HTMLElement;
  /** Caller-provided hide hook (called on cleanup). */
  hideTooltip: () => void;
};

export type InstructionPromptOptions = {
  /** Returned when the user saves with empty text. Defaults to a generic label. */
  defaultInstruction?: string;
  /** Optional title text shown above the textarea. Defaults to "Instruction". */
  title?: string;
  /** Optional copy/help text rendered between title and textarea. */
  copy?: string;
  /** Optional placeholder for the textarea. */
  placeholder?: string;
};

export type InstructionPromptController = {
  isPrompting: () => boolean;
  isPromptElement: (target: Element | null) => boolean;
  blockWhilePrompting: (event: Event) => void;
  promptInstruction: (
    anchor: Element,
    options?: InstructionPromptOptions | string,
  ) => Promise<string | null>;
};

const createElementInRoot = (documentRoot: Document | ShadowRoot, tag: string): HTMLElement => {
  const ownerDocument =
    documentRoot instanceof Document ? documentRoot : documentRoot.ownerDocument;
  if (!ownerDocument) {
    throw new Error("InstructionPromptController: documentRoot has no ownerDocument");
  }
  return ownerDocument.createElement(tag);
};

export const createInstructionPromptController = ({
  documentRoot,
  panel,
  tooltip,
  hideTooltip,
}: InstructionPromptControllerArgs): InstructionPromptController => {
  let isPrompting = false;

  const isPromptElement = (target: Element | null): boolean => {
    if (!target) return false;
    return panel.contains(target) || tooltip.contains(target);
  };

  const blockWhilePrompting = (event: Event): void => {
    if (!isPrompting) return;
    const target = event.target as Element | null;
    if (isPromptElement(target)) return;
    event.preventDefault();
    if ("stopImmediatePropagation" in event) {
      event.stopImmediatePropagation();
    }
    event.stopPropagation();
  };

  const promptInstruction = (
    anchor: Element,
    options?: InstructionPromptOptions | string,
  ): Promise<string | null> => {
    const opts: InstructionPromptOptions =
      typeof options === "string" ? { defaultInstruction: options } : (options ?? {});
    const defaultInstruction = opts.defaultInstruction ?? "Click the highlighted element";
    const titleText = opts.title ?? "Instruction";
    const copyText = opts.copy ?? "";
    const placeholder = opts.placeholder ?? "Type instruction...";

    return new Promise((resolve) => {
      isPrompting = true;
      documentRoot.addEventListener("click", blockWhilePrompting, true);

      let stopTrackingTooltip: (() => void) | null = null;

      const cleanup = (): void => {
        tooltip.removeEventListener("click", onTooltipClick, true);
        tooltip.removeEventListener("keydown", onTooltipKeydown, true);
        documentRoot.removeEventListener("click", blockWhilePrompting, true);
        stopTrackingTooltip?.();
        stopTrackingTooltip = null;
        hideTooltip();
        isPrompting = false;
      };

      const submit = (): void => {
        const input = tooltip.querySelector<HTMLTextAreaElement>("textarea");
        const text = input?.value.trim() ?? "";
        cleanup();
        resolve(text || defaultInstruction);
      };

      const cancel = (): void => {
        cleanup();
        resolve(null);
      };

      const onTooltipClick = (event: MouseEvent): void => {
        const target = event.target as Element | null;
        const action = target?.closest("button[data-action]")?.getAttribute("data-action");
        if (!action) return;
        event.preventDefault();
        event.stopPropagation();
        if (action === "save") submit();
        if (action === "cancel") cancel();
      };

      const onTooltipKeydown = (event: KeyboardEvent): void => {
        if (event.key === "Escape") {
          event.preventDefault();
          event.stopPropagation();
          cancel();
        }
        if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
          event.preventDefault();
          submit();
        }
      };

      tooltip.replaceChildren();

      const title = createElementInRoot(documentRoot, "div");
      title.style.marginBottom = "6px";
      title.style.fontWeight = "600";
      title.textContent = titleText;

      const children: HTMLElement[] = [title];

      if (copyText) {
        const copy = createElementInRoot(documentRoot, "div");
        copy.style.marginBottom = "6px";
        copy.style.fontSize = "12px";
        copy.style.opacity = "0.85";
        copy.textContent = copyText;
        children.push(copy);
      }

      const input = createElementInRoot(documentRoot, "textarea") as HTMLTextAreaElement;
      input.placeholder = placeholder;
      children.push(input);

      const actions = createElementInRoot(documentRoot, "div");
      actions.style.display = "flex";
      actions.style.gap = "8px";
      actions.style.marginTop = "8px";

      const saveButton = createElementInRoot(documentRoot, "button") as HTMLButtonElement;
      saveButton.dataset.action = "save";
      saveButton.type = "button";
      saveButton.textContent = "Save";

      const cancelButton = createElementInRoot(documentRoot, "button") as HTMLButtonElement;
      cancelButton.dataset.action = "cancel";
      cancelButton.type = "button";
      cancelButton.textContent = "Cancel";

      actions.append(saveButton, cancelButton);
      children.push(actions);
      tooltip.append(...children);

      tooltip.style.display = "block";
      tooltip.style.visibility = "hidden";
      stopTrackingTooltip = trackAnchoredTooltip(tooltip, anchor);
      tooltip.style.visibility = "visible";

      tooltip.addEventListener("click", onTooltipClick, true);
      tooltip.addEventListener("keydown", onTooltipKeydown, true);

      input.focus();
    });
  };

  return {
    isPrompting: () => isPrompting,
    isPromptElement,
    blockWhilePrompting,
    promptInstruction,
  };
};
