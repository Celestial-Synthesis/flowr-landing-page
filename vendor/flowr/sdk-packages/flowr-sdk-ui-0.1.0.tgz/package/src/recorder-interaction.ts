/**
 * @flowr/sdk-ui — recorder-interaction
 * --------------------------------------------------------------------------
 * Shared logic for the recorder's right-click context menu and the
 * instruction-prompt tooltip flow.
 *
 * Extension is the source of truth: this module is the verbatim port of
 * `src/content/context-menu.ts` and `src/content/instruction-prompt.ts`,
 * with two minimal seams for SDK consumers:
 *   - `documentRoot` may be a `Document` (extension) or `ShadowRoot` (SDK).
 *   - `buildButtons` is injectable so SDK consumers can present a different
 *     action set; the default matches the extension exactly.
 *
 * Stable test contract (assert in Playwright):
 *   - .wr-context-menu button[data-action="record-right-click"]
 *   - .wr-context-menu button[data-action="record-hover"]            (desktop)
 *   - .wr-context-menu button[data-action="add-instruction-to-section"]
 *   - .wr-context-menu button[data-action="cancel"]
 *   - .wr-tooltip textarea
 *   - .wr-tooltip button[data-action="save"]
 *   - .wr-tooltip button[data-action="cancel"]
 */

import { trackAnchoredTooltip } from "@flowr/sdk-core/anchored-tooltip-layout";

// ---------------------------------------------------------------------------
// Context menu controller
// ---------------------------------------------------------------------------

export type ContextMenuButtonSpec = {
  action: string;
  label: string;
};

export type ContextMenuActionHandlers = {
  onRecordHover: (target: Element) => Promise<void> | void;
  onAddInstructionToSection: (target: Element) => Promise<void> | void;
  onRecordRightClick: (target: Element) => Promise<void> | void;
  onBlurSection?: (target: Element) => Promise<void> | void;
  onCancel?: (target: Element) => Promise<void> | void;
};

export type ContextMenuControllerArgs = {
  contextMenu: HTMLElement;
  /** Mobile-aware label override; defaults to a no-op (desktop labels). */
  isMobile?: () => boolean;
  /** Whether screenshots are enabled, allowing blur options when supported. */
  isCaptureScreenshotsEnabled?: () => boolean;
  /**
   * Optional builder for the action buttons. When omitted, the extension's
   * exact button set is rendered.
   */
  buildButtons?: (args: {
    target: Element;
    isMobile: boolean;
    isCaptureScreenshotsEnabled: boolean;
    canBlurSection: boolean;
  }) => ContextMenuButtonSpec[];
};

export type ContextMenuController = {
  isOpen: () => boolean;
  close: () => void;
  show: (x: number, y: number, target: Element) => void;
  contains: (target: Element | null) => boolean;
  bindActions: (handlers: ContextMenuActionHandlers) => void;
};

const defaultBuildButtons = ({
  isMobile,
  canBlurSection,
}: {
  target: Element;
  isMobile: boolean;
  isCaptureScreenshotsEnabled: boolean;
  canBlurSection: boolean;
}): ContextMenuButtonSpec[] => {
  const buttons: ContextMenuButtonSpec[] = [
    {
      action: "record-right-click",
      label: isMobile ? "Record long hold" : "Record right click",
    },
  ];
  if (!isMobile) {
    buttons.push({ action: "record-hover", label: "Record hover" });
  }
  buttons.push({ action: "add-instruction-to-section", label: "Add instruction to section" });
  if (canBlurSection) {
    buttons.push({ action: "blur-section", label: "Blur section" });
  }
  buttons.push({ action: "cancel", label: "Cancel" });
  return buttons;
};

export const createContextMenuController = ({
  contextMenu,
  isMobile,
  isCaptureScreenshotsEnabled,
  buildButtons,
}: ContextMenuControllerArgs): ContextMenuController => {
  let isOpen = false;
  let currentTarget: Element | null = null;
  let boundHandlers: ContextMenuActionHandlers | null = null;

  const close = (): void => {
    if (!isOpen) return;
    contextMenu.hidden = false;
    contextMenu.style.display = "none";
    contextMenu.style.visibility = "hidden";
    contextMenu.replaceChildren();
    isOpen = false;
    currentTarget = null;
  };

  const show = (x: number, y: number, target: Element): void => {
    currentTarget = target;
    contextMenu.replaceChildren();

    const mobile = isMobile?.() ?? false;
    const captureEnabled = isCaptureScreenshotsEnabled?.() ?? false;
    const canBlurSection = captureEnabled && typeof boundHandlers?.onBlurSection === "function";
    const specs = (buildButtons ?? defaultBuildButtons)({
      target,
      isMobile: mobile,
      isCaptureScreenshotsEnabled: captureEnabled,
      canBlurSection,
    });
    const buttons = specs.map((spec) => {
      const button = document.createElement("button");
      button.type = "button";
      button.dataset.action = spec.action;
      button.textContent = spec.label;
      return button;
    });
    contextMenu.append(...buttons);

    // Position at mouse coordinates, then clamp to viewport so the menu
    // never extends beyond the visible area.
    contextMenu.style.left = `${x}px`;
    contextMenu.style.top = `${y}px`;
    contextMenu.hidden = false;
    contextMenu.style.display = "flex";
    contextMenu.style.visibility = "visible";

    const rect = contextMenu.getBoundingClientRect();
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;

    if (rect.right > viewportWidth) {
      contextMenu.style.left = `${Math.max(0, x - (rect.right - viewportWidth))}px`;
    }
    if (rect.bottom > viewportHeight) {
      contextMenu.style.top = `${Math.max(0, y - (rect.bottom - viewportHeight))}px`;
    }

    isOpen = true;
  };

  const contains = (target: Element | null): boolean => {
    return !!target && contextMenu.contains(target);
  };

  const bindActions = (handlers: ContextMenuActionHandlers): void => {
    boundHandlers = handlers;
    contextMenu.addEventListener("click", (event) => {
      const button = (event.target as Element | null)?.closest("button[data-action]");
      if (!button) return;
      const action = button.getAttribute("data-action");
      const target = currentTarget;
      close();
      if (!target) return;

      if (action === "record-hover") {
        void handlers.onRecordHover(target);
        return;
      }
      if (action === "add-instruction-to-section" || action === "add-instruction") {
        void handlers.onAddInstructionToSection(target);
        return;
      }
      if (action === "record-right-click") {
        void handlers.onRecordRightClick(target);
        return;
      }
      if (action === "blur-section") {
        void handlers.onBlurSection?.(target);
        return;
      }
      if (action === "cancel") {
        void handlers.onCancel?.(target);
      }
    });
  };

  return {
    isOpen: () => isOpen,
    close,
    show,
    contains,
    bindActions,
  };
};

// ---------------------------------------------------------------------------
// Instruction prompt controller
// ---------------------------------------------------------------------------

export type InstructionPromptControllerArgs = {
  /** Document or ShadowRoot used for `createElement` and capture-phase listeners. */
  documentRoot: Document | ShadowRoot;
  /** Element whose contents (and the tooltip's contents) should not be blocked. */
  panel: HTMLElement;
  /** Tooltip host element; will be repopulated each prompt and shown/hidden. */
  tooltip: HTMLElement;
  /** Caller-provided hide hook (called on cleanup). */
  hideTooltip: () => void;
};

export type InstructionPromptOptions = {
  /** Returned when the user saves with empty text. Defaults to a generic label. */
  defaultInstruction?: string;
  /** Optional title text shown above the textarea. Defaults to "Instruction". */
  title?: string;
  /** Optional copy/help text rendered between title and textarea. */
  copy?: string;
  /** Optional placeholder for the textarea. */
  placeholder?: string;
  /** When false, do not autofocus the textarea after opening the prompt. */
  autoFocus?: boolean;
  /** Optional hook that runs after Save is clicked but before the prompt cleans up. */
  onBeforeSubmit?: () => Promise<void> | void;
  /** When true, prompt cleanup waits until the registered deferred cleanup runs. */
  deferCleanupOnSubmit?: boolean;
  /** Receives the deferred cleanup callback when deferCleanupOnSubmit is true. */
  registerDeferredCleanup?: (finishCleanup: () => void) => void;
  /**
   * When true, Save/Cancel press events are guarded from page-level outside-press
   * dismissal handlers until the prompt action runs.
   */
  protectActionButtonsFromOutsidePressDismissal?: boolean;
  /** @deprecated Use protectActionButtonsFromOutsidePressDismissal. */
  captureActionButtonsOnPress?: boolean;
  /**
   * When true, suppress outside hover/focus leave events while prompt is open
   * so page-level dismiss handlers cannot collapse transient menus mid-edit.
   */
  suppressOutsideHoverDismissal?: boolean;
  /**
   * Optional viewport-space bounds that the prompt should stay inside when
   * interacting with hover-backed overlays. This keeps the real pointer inside
   * the page's hover region while the user edits the instruction.
   */
  constrainToViewportRect?: {
    top: number;
    left: number;
    right: number;
    bottom: number;
  };
};

export type InstructionPromptController = {
  isPrompting: () => boolean;
  isPromptElement: (target: Element | null) => boolean;
  blockWhilePrompting: (event: Event) => void;
  promptInstruction: (
    anchor: Element,
    options?: InstructionPromptOptions | string,
  ) => Promise<string | null>;
  finishDeferredPromptCleanup: () => void;
};

const createElementInRoot = (documentRoot: Document | ShadowRoot, tag: string): HTMLElement => {
  const ownerDocument =
    documentRoot instanceof Document ? documentRoot : documentRoot.ownerDocument;
  if (!ownerDocument) {
    throw new Error("InstructionPromptController: documentRoot has no ownerDocument");
  }
  return ownerDocument.createElement(tag);
};

const clamp = (value: number, min: number, max: number): number => {
  if (max < min) {
    return min;
  }
  return Math.min(Math.max(value, min), max);
};

const positionTooltipWithinViewportRect = (
  tooltip: HTMLElement,
  anchor: Element,
  rect: NonNullable<InstructionPromptOptions["constrainToViewportRect"]>,
): (() => void) | null => {
  const tooltipRect = tooltip.getBoundingClientRect();
  const tooltipWidth = tooltipRect.width || tooltip.offsetWidth;
  const tooltipHeight = tooltipRect.height || tooltip.offsetHeight;
  const boundsWidth = rect.right - rect.left;
  const boundsHeight = rect.bottom - rect.top;
  const inset = 8;

  if (boundsWidth < tooltipWidth + inset * 2 || boundsHeight < tooltipHeight + inset * 2) {
    return null;
  }


  const apply = (): void => {
    const anchorRect = anchor.getBoundingClientRect();
    const preferredLeft = anchorRect.left + anchorRect.width / 2 - tooltipWidth / 2;
    const preferredTop =
      anchorRect.bottom + inset + tooltipHeight <= rect.bottom - inset
        ? anchorRect.bottom + inset
        : rect.bottom - tooltipHeight - inset;
    const left = clamp(preferredLeft, rect.left + inset, rect.right - tooltipWidth - inset);
    const top = clamp(preferredTop, rect.top + inset, rect.bottom - tooltipHeight - inset);

    tooltip.classList.remove("is-above");
    tooltip.style.setProperty(
      "--wr-tooltip-arrow-left",
      `${anchorRect.left + anchorRect.width / 2 - left}px`,
    );
    tooltip.style.top = `${top}px`;
    tooltip.style.left = `${left}px`;
  };

  apply();
  return apply;
};

type PromptActionPressGuardArgs = {
  enabled: boolean;
  tooltip: HTMLElement;
  windowRoot: Window | null;
  onAction: (action: string) => void;
};

type PromptActionPressGuard = {
  attach: () => void;
  detach: () => void;
};

const suppressPromptActionEvent = (event: Event): void => {
  event.preventDefault();
  if ("stopImmediatePropagation" in event) {
    event.stopImmediatePropagation();
  }
  event.stopPropagation();
};

const createPromptActionPressGuard = ({
  enabled,
  tooltip,
  windowRoot,
  onAction,
}: PromptActionPressGuardArgs): PromptActionPressGuard => {
  let isAttached = false;
  let handledActionButton: HTMLButtonElement | null = null;
  let handledAction: string | null = null;

  const getTooltipElement = (target: EventTarget | null): Element | null => {
    const targetElement = target as Element | null;
    return targetElement && tooltip.contains(targetElement) ? targetElement : null;
  };

  const getActionButton = (target: EventTarget | null): HTMLButtonElement | null => {
    const targetElement = getTooltipElement(target);
    const actionButton = targetElement?.closest("button[data-action]");
    if (!(actionButton instanceof HTMLButtonElement)) {
      return null;
    }

    return actionButton;
  };

  const suppressTooltipPressPropagation = (event: Event): void => {
    if ("stopImmediatePropagation" in event) {
      event.stopImmediatePropagation();
    }
    event.stopPropagation();
  };

  const shouldSuppressHandledAction = (target: EventTarget | null): boolean => {
    if (!handledActionButton) {
      return false;
    }

    const targetElement = target as Element | null;
    return !!targetElement && handledActionButton.contains(targetElement);
  };

  const onPointerDownCapture = (event: PointerEvent): void => {
    if (event.button !== 0) {
      return;
    }

    const actionButton = getActionButton(event.target);
    if (!actionButton) {
      if (getTooltipElement(event.target)) {
        suppressTooltipPressPropagation(event);
      }
      return;
    }

    handledActionButton = actionButton;
    handledAction = actionButton.getAttribute("data-action");
    suppressPromptActionEvent(event);
  };

  const onPointerEventCapture = (event: PointerEvent): void => {
    if (shouldSuppressHandledAction(event.target)) {
      suppressPromptActionEvent(event);
      return;
    }

    if (getTooltipElement(event.target)) {
      suppressTooltipPressPropagation(event);
    }
  };

  const onMouseEventCapture = (event: MouseEvent): void => {
    if (!shouldSuppressHandledAction(event.target)) {
      if (getTooltipElement(event.target)) {
        suppressTooltipPressPropagation(event);
      }
      return;
    }

    suppressPromptActionEvent(event);
    if (event.type === "click" && handledAction) {
      onAction(handledAction);
    }
  };

  const onFocusInCapture = (event: FocusEvent): void => {
    if (getTooltipElement(event.target)) {
      suppressTooltipPressPropagation(event);
    }
  };

  const onFocusOutCapture = (event: FocusEvent): void => {
    const focusTarget = event.target as Element | null;
    if (!focusTarget || tooltip.contains(focusTarget)) {
      return;
    }

    const relatedTarget = event.relatedTarget as Element | null;
    if (relatedTarget && tooltip.contains(relatedTarget)) {
      suppressTooltipPressPropagation(event);
    }
  };

  const attach = (): void => {
    if (!enabled || !windowRoot || isAttached) {
      return;
    }

    isAttached = true;
    windowRoot.addEventListener("pointerdown", onPointerDownCapture, true);
    windowRoot.addEventListener("mousedown", onMouseEventCapture, true);
    windowRoot.addEventListener("pointerup", onPointerEventCapture, true);
    windowRoot.addEventListener("mouseup", onMouseEventCapture, true);
    windowRoot.addEventListener("click", onMouseEventCapture, true);
    windowRoot.addEventListener("focusin", onFocusInCapture, true);
    windowRoot.addEventListener("focusout", onFocusOutCapture, true);
  };

  const detach = (): void => {
    if (!windowRoot || !isAttached) {
      handledActionButton = null;
      handledAction = null;
      return;
    }

    windowRoot.removeEventListener("pointerdown", onPointerDownCapture, true);
    windowRoot.removeEventListener("mousedown", onMouseEventCapture, true);
    windowRoot.removeEventListener("pointerup", onPointerEventCapture, true);
    windowRoot.removeEventListener("mouseup", onMouseEventCapture, true);
    windowRoot.removeEventListener("click", onMouseEventCapture, true);
    windowRoot.removeEventListener("focusin", onFocusInCapture, true);
    windowRoot.removeEventListener("focusout", onFocusOutCapture, true);
    isAttached = false;
    handledActionButton = null;
    handledAction = null;
  };

  return { attach, detach };
};

export const createInstructionPromptController = ({
  documentRoot,
  panel,
  tooltip,
  hideTooltip,
}: InstructionPromptControllerArgs): InstructionPromptController => {
  let isPrompting = false;
  let deferredPromptCleanup: (() => void) | null = null;

  const finishDeferredPromptCleanup = (): void => {
    deferredPromptCleanup?.();
    deferredPromptCleanup = null;
  };

  const isPromptElement = (target: Element | null): boolean => {
    if (!target) return false;
    return panel.contains(target) || tooltip.contains(target);
  };

  const blockWhilePrompting = (event: Event): void => {
    if (!isPrompting) return;
    const target = event.target as Element | null;
    if (isPromptElement(target)) return;
    event.preventDefault();
    if ("stopImmediatePropagation" in event) {
      event.stopImmediatePropagation();
    }
    event.stopPropagation();
  };

  const promptInstruction = (
    anchor: Element,
    options?: InstructionPromptOptions | string,
  ): Promise<string | null> => {
    const opts: InstructionPromptOptions =
      typeof options === "string" ? { defaultInstruction: options } : (options ?? {});
    const defaultInstruction = opts.defaultInstruction ?? "Click the highlighted element";
    const titleText = opts.title ?? "Instruction";
    const copyText = opts.copy ?? "";
    const placeholder = opts.placeholder ?? "Type instruction...";
    const shouldAutoFocus = opts.autoFocus !== false;
    const shouldProtectActionButtonsFromOutsidePressDismissal =
      opts.protectActionButtonsFromOutsidePressDismissal === true ||
      opts.captureActionButtonsOnPress === true;
    const ownerDocument =
      documentRoot instanceof Document ? documentRoot : documentRoot.ownerDocument;
    const windowRoot = ownerDocument?.defaultView ?? null;
    let isResolving = false;

    return new Promise((resolve) => {
      isPrompting = true;
      documentRoot.addEventListener("click", blockWhilePrompting, true);

      let stopTrackingTooltip: (() => void) | null = null;
      let actionPressGuard: PromptActionPressGuard | null = null;
      let stopOutsideHoverDismissalGuard: (() => void) | null = null;

      const cleanup = (): void => {
        tooltip.removeEventListener("mousedown", onTooltipMouseDown, true);
        tooltip.removeEventListener("click", onTooltipClick, true);
        tooltip.removeEventListener("keydown", onTooltipKeydown, true);
        actionPressGuard?.detach();
        actionPressGuard = null;
        stopOutsideHoverDismissalGuard?.();
        stopOutsideHoverDismissalGuard = null;
        documentRoot.removeEventListener("click", blockWhilePrompting, true);
        stopTrackingTooltip?.();
        stopTrackingTooltip = null;
        hideTooltip();
        isPrompting = false;
      };

      const submit = async (): Promise<void> => {
        if (isResolving) {
          return;
        }
        isResolving = true;
        const input = tooltip.querySelector<HTMLTextAreaElement>("textarea");
        const text = input?.value.trim() ?? "";
        await opts.onBeforeSubmit?.();
        if (opts.deferCleanupOnSubmit) {
          if (opts.registerDeferredCleanup) {
            opts.registerDeferredCleanup(cleanup);
          } else {
            deferredPromptCleanup = cleanup;
          }
          resolve(text || defaultInstruction);
          return;
        }
        cleanup();
        resolve(text || defaultInstruction);
      };

      const cancel = (): void => {
        deferredPromptCleanup = null;
        cleanup();
        resolve(null);
      };

      const handleAction = (action: string): void => {
        if (action === "save") {
          void submit();
          return;
        }

        if (action === "cancel") {
          cancel();
        }
      };

      const onTooltipClick = (event: MouseEvent): void => {
        const target = event.target as Element | null;
        const action = target?.closest("button[data-action]")?.getAttribute("data-action");
        if (!action) return;
        event.preventDefault();
        event.stopPropagation();
        handleAction(action);
      };

      const onTooltipMouseDown = (event: MouseEvent): void => {
        const target = event.target as Element | null;
        const actionButton = target?.closest("button[data-action]");
        if (!actionButton) {
          return;
        }

        // Keep focus on the page overlay until the user explicitly clicks
        // elsewhere, so Cancel leaves overlay-driven menus available.
        event.preventDefault();
        event.stopPropagation();
      };

      const onTooltipKeydown = (event: KeyboardEvent): void => {
        if (event.key === "Escape") {
          event.preventDefault();
          event.stopPropagation();
          cancel();
        }
        if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
          event.preventDefault();
          submit();
        }
      };

      tooltip.replaceChildren();

      const title = createElementInRoot(documentRoot, "div");
      title.style.marginBottom = "6px";
      title.style.fontWeight = "600";
      title.textContent = titleText;

      const children: HTMLElement[] = [title];

      if (copyText) {
        const copy = createElementInRoot(documentRoot, "div");
        copy.style.marginBottom = "6px";
        copy.style.fontSize = "12px";
        copy.style.opacity = "0.85";
        copy.textContent = copyText;
        children.push(copy);
      }

      const input = createElementInRoot(documentRoot, "textarea") as HTMLTextAreaElement;
      input.placeholder = placeholder;
      children.push(input);

      const actions = createElementInRoot(documentRoot, "div");
      actions.style.display = "flex";
      actions.style.gap = "8px";
      actions.style.marginTop = "8px";

      const saveButton = createElementInRoot(documentRoot, "button") as HTMLButtonElement;
      saveButton.dataset.action = "save";
      saveButton.type = "button";
      saveButton.textContent = "Save";

      const cancelButton = createElementInRoot(documentRoot, "button") as HTMLButtonElement;
      cancelButton.dataset.action = "cancel";
      cancelButton.type = "button";
      cancelButton.textContent = "Cancel";

      actions.append(saveButton, cancelButton);
      children.push(actions);
      tooltip.append(...children);

      tooltip.style.display = "block";
      tooltip.style.visibility = "hidden";
      const constrainedPositioner = opts.constrainToViewportRect
        ? positionTooltipWithinViewportRect(tooltip, anchor, opts.constrainToViewportRect)
        : null;
      if (constrainedPositioner) {
        const relayout = (): void => constrainedPositioner();
        windowRoot?.addEventListener("resize", relayout);
        windowRoot?.addEventListener("scroll", relayout, true);
        stopTrackingTooltip = () => {
          windowRoot?.removeEventListener("resize", relayout);
          windowRoot?.removeEventListener("scroll", relayout, true);
        };
      } else {
        stopTrackingTooltip = trackAnchoredTooltip(tooltip, anchor);
      }
      tooltip.style.visibility = "visible";

      tooltip.addEventListener("mousedown", onTooltipMouseDown, true);
      tooltip.addEventListener("click", onTooltipClick, true);
      tooltip.addEventListener("keydown", onTooltipKeydown, true);

      actionPressGuard = createPromptActionPressGuard({
        enabled: shouldProtectActionButtonsFromOutsidePressDismissal,
        tooltip,
        windowRoot,
        onAction: handleAction,
      });
      actionPressGuard.attach();

      if (opts.suppressOutsideHoverDismissal) {
        const suppressOutsideDismissEvent = (event: Event): void => {
          const relatedTarget = "relatedTarget" in event ? (event as FocusEvent | MouseEvent | PointerEvent).relatedTarget : null;
          if (!(relatedTarget instanceof Element) || !tooltip.contains(relatedTarget)) {
            return;
          }

          if ("stopImmediatePropagation" in event) {
            event.stopImmediatePropagation();
          }
          event.stopPropagation();
        };

        const listeners: Array<{ target: EventTarget; type: string; listener: EventListener }> = [
          { target: documentRoot, type: "pointerout", listener: suppressOutsideDismissEvent as EventListener },
          { target: documentRoot, type: "mouseout", listener: suppressOutsideDismissEvent as EventListener },
          { target: documentRoot, type: "mouseleave", listener: suppressOutsideDismissEvent as EventListener },
          { target: documentRoot, type: "pointerleave", listener: suppressOutsideDismissEvent as EventListener },
          { target: windowRoot ?? documentRoot, type: "focusout", listener: suppressOutsideDismissEvent as EventListener },
        ];

        for (const { target, type, listener } of listeners) {
          target.addEventListener(type, listener, true);
        }

        stopOutsideHoverDismissalGuard = () => {
          for (const { target, type, listener } of listeners) {
            target.removeEventListener(type, listener, true);
          }
        };
      }

      if (shouldAutoFocus) {
        input.focus();
      }
    });
  };

  return {
    isPrompting: () => isPrompting,
    isPromptElement,
    blockWhilePrompting,
    promptInstruction,
    finishDeferredPromptCleanup,
  };
};
