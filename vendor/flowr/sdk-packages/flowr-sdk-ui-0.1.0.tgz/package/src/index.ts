/**
 * @flowr/sdk-ui
 * --------------------------------------------------------------------------
 * Shared web-safe UI primitives for FlowR recorder/replay SDK consumers.
 *
 * Modules:
 *   - recorder-overlay: shadow-DOM context menu + instruction prompt + highlight.
 *   - recorder-panel: shared state-driven recorder panel rendered into a
 *     bubble's `panelEl`.
 *   - recorder-interaction: shared interaction handling and utilities.
 *
 * No dependency on chrome.runtime or networking. The package can render
 * auth-related UI state, but the actual OTP transport stays in the host SDK.
 * It is intended to be consumed by every recorder-style SDK package and
 * eventually by the FlowR extension content script as it migrates away
 * from extension-only state plumbing.
 */

export * from "./recorder-overlay";
export * from "./recorder-panel";
export * from "./recorder-interaction";
