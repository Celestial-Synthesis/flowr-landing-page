/**
 * @flowr/sdk-ui — per-panel auto-scroll controller for the step list.
 *
 * Pins the step list to the bottom when a new step lands; preserves
 * scroll position across re-renders that don't grow the list (advanced
 * edits, instruction edits, etc.). One tracker per recorder panel
 * instance — `destroy()` should call `reset()` to drop ID memory.
 */

export type AutoScrollApplyArgs = {
  stepListEl: HTMLElement | null;
  root: HTMLElement;
  currentId: string | null;
  currentCount: number;
  activeIndex: number | null;
  prevScrollTop: number;
};

export type AutoScrollTracker = {
  apply(args: AutoScrollApplyArgs): void;
  reset(): void;
};

export const createAutoScrollTracker = (): AutoScrollTracker => {
  let prevStepCount = 0;
  let prevRecordingId: string | null = null;
  let prevActiveIndex: number | null = null;

  return {
    apply({ stepListEl, root, currentId, currentCount, activeIndex, prevScrollTop }) {
      if (stepListEl) {
        const isSameRecording = currentId !== null && currentId === prevRecordingId;
        const grew = isSameRecording && currentCount > prevStepCount;
        const activeStepChanged =
          activeIndex !== null && (!isSameRecording || activeIndex !== prevActiveIndex);
        if (activeStepChanged) {
          const scrollActiveStepIntoView = (targetRoot: ParentNode): void => {
            const list = targetRoot.querySelector<HTMLElement>("[data-flowr-step-list]");
            const activeRow = targetRoot.querySelector<HTMLElement>(
              '[data-flowr-step-row][data-active="true"]',
            );
            if (!list || !activeRow) {
              return;
            }
            activeRow.scrollIntoView({ block: "nearest" });
          };

          scrollActiveStepIntoView(root);
          if (typeof requestAnimationFrame === "function") {
            requestAnimationFrame(() => {
              scrollActiveStepIntoView(root);
            });
          }
        } else if (grew) {
          const pinToBottom = (): void => {
            stepListEl.scrollTop = stepListEl.scrollHeight;
          };
          pinToBottom();
          if (typeof requestAnimationFrame === "function") {
            requestAnimationFrame(() => {
              const fresh = root.querySelector<HTMLElement>("[data-flowr-step-list]");
              if (fresh) {
                fresh.scrollTop = fresh.scrollHeight;
              }
            });
          }
        } else if (isSameRecording && prevScrollTop > 0) {
          stepListEl.scrollTop = prevScrollTop;
        }
      }
      prevStepCount = currentCount;
      prevRecordingId = currentId;
      prevActiveIndex = activeIndex;
    },
    reset() {
      prevStepCount = 0;
      prevRecordingId = null;
      prevActiveIndex = null;
    },
  };
};
