/**
 * @flowr/sdk-ui — per-panel auto-scroll controller for the step list.
 *
 * Pins the step list to the bottom when a new step lands; preserves
 * scroll position across re-renders that don't grow the list (advanced
 * edits, instruction edits, etc.). One tracker per recorder panel
 * instance — `destroy()` should call `reset()` to drop ID memory.
 */

export type AutoScrollApplyArgs = {
  stepListEl: HTMLElement | null;
  root: HTMLElement;
  currentId: string | null;
  currentCount: number;
  prevScrollTop: number;
};

export type AutoScrollTracker = {
  apply(args: AutoScrollApplyArgs): void;
  reset(): void;
};

export const createAutoScrollTracker = (): AutoScrollTracker => {
  let prevStepCount = 0;
  let prevRecordingId: string | null = null;

  return {
    apply({ stepListEl, root, currentId, currentCount, prevScrollTop }) {
      if (stepListEl) {
        const isSameRecording = currentId !== null && currentId === prevRecordingId;
        const grew = isSameRecording && currentCount > prevStepCount;
        if (grew) {
          const pinToBottom = (): void => {
            stepListEl.scrollTop = stepListEl.scrollHeight;
          };
          pinToBottom();
          if (typeof requestAnimationFrame === "function") {
            requestAnimationFrame(() => {
              const fresh = root.querySelector<HTMLElement>("[data-flowr-step-list]");
              if (fresh) {
                fresh.scrollTop = fresh.scrollHeight;
              }
            });
          }
        } else if (isSameRecording && prevScrollTop > 0) {
          stepListEl.scrollTop = prevScrollTop;
        }
      }
      prevStepCount = currentCount;
      prevRecordingId = currentId;
    },
    reset() {
      prevStepCount = 0;
      prevRecordingId = null;
    },
  };
};
