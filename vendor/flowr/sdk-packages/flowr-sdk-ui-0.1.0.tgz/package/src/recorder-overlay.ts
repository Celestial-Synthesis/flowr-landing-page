/**
 * @flowr/sdk-ui — recorder-overlay
 * --------------------------------------------------------------------------
 * Shared shadow-DOM overlay used by FlowR recorder SDK consumers to author
 * hover, context-click, and instruction steps.
 *
 * Internally delegates to the shared interaction controllers
 * (`createContextMenuController`, `createInstructionPromptController`) so
 * the SDK and the FlowR extension share one logic surface
 * (extension-as-source-of-truth).
 *
 * Stable test contract (assert in Playwright):
 *   - [data-flowr-context-menu]
 *   - [data-flowr-context-menu] button[data-action="record-hover"]
 *   - [data-flowr-context-menu] button[data-action="record-right-click"]
 *   - [data-flowr-context-menu] button[data-action="add-instruction"]
 *   - [data-flowr-context-menu] button[data-action="cancel"]
 *   - [data-flowr-instruction-prompt]
 *   - [data-flowr-instruction-prompt] textarea
 *   - [data-flowr-instruction-prompt] button[data-action="save"]
 *   - [data-flowr-instruction-prompt] button[data-action="cancel"]
 */

import { WR_HIGHLIGHT_AND_TOOLTIP_CSS } from "@flowr/sdk-core";
import {
  createContextMenuController,
  createInstructionPromptController,
} from "./recorder-interaction";

export type RecorderOverlayOptions = {
  shadowRoot: ShadowRoot;
  isCaptureScreenshotsEnabled?: boolean | (() => boolean);
  onRecordHover: (target: Element) => void;
  onRecordContextClick: (target: Element) => void;
  onSaveInstruction: (target: Element, instruction: string) => void;
  onBlurSection?: (target: Element) => void;
};

export type RecorderOverlayHandle = {
  showContextMenu: (args: { target: Element; x: number; y: number }) => void;
  hideAll: () => void;
  isActive: () => boolean;
  isPromptingInstruction: () => boolean;
  showInstructionPrompt: (args: {
    target: Element;
    title?: string;
    copy?: string;
    placeholder?: string;
    defaultInstruction?: string;
  }) => Promise<string | null>;
  showInputFocusHint: (args: { target: Element; text: string }) => void;
  hideInputFocusHint: () => void;
  destroy: () => void;
};

const STYLE_ID = "flowr-sdk-ui-recorder-overlay-style";

const SDK_OVERLAY_CSS = `
  .flowr-overlay-host {
    position: fixed;
    inset: 0;
    pointer-events: none;
    z-index: 2147483647;
    font: 13px var(--flowr-sdk-font-family, "Segoe UI", system-ui, -apple-system, Roboto, sans-serif);
    color: var(--flowr-sdk-panel-foreground, #5a1c24);
  }
  .wr-highlight {
    /* SDK manages visibility via style.display; force opacity:1 when shown.
     * No position/size transition — the rAF tick repositions every frame
     * during scroll/resize and any easing here causes visible lag. */
    display: none;
    opacity: 1;
    transition: none;
  }
  [data-flowr-context-menu],
  [data-flowr-instruction-prompt] {
    position: fixed;
    box-sizing: border-box;
    min-width: 220px;
    max-width: min(320px, calc(100vw - 24px));
    padding: 12px;
    background: var(--flowr-sdk-surface-background, #ffffff);
    color: var(--flowr-sdk-panel-foreground, #5a1c24);
    border: 1px solid var(--flowr-sdk-panel-border, #e5d3d6);
    border-radius: 12px;
    box-shadow: 0 12px 32px color-mix(in srgb, var(--flowr-sdk-accent, #8d2e3a) 18%, transparent), 0 2px 8px rgba(0, 0, 0, 0.08);
    pointer-events: auto;
    z-index: 2147483647;
  }
  [data-flowr-context-menu] {
    display: none;
    flex-direction: column;
    gap: 6px;
  }
  [data-flowr-instruction-prompt] {
    display: none;
  }
  [data-flowr-context-menu] button,
  [data-flowr-instruction-prompt] button {
    width: 100%;
    box-sizing: border-box;
    padding: 8px 10px;
    border: 1px solid var(--flowr-sdk-panel-border, #e5d3d6);
    border-radius: 8px;
    background: var(--flowr-sdk-surface-background, #ffffff);
    color: var(--flowr-sdk-panel-foreground, #5a1c24);
    font-family: inherit;
    font-size: 13px;
    font-weight: 600;
    text-align: left;
    cursor: pointer;
  }
  [data-flowr-context-menu] button:hover,
  [data-flowr-instruction-prompt] button:hover {
    background: var(--flowr-sdk-surface-muted-background, #faf2f3);
    border-color: color-mix(in srgb, var(--flowr-sdk-accent, #8d2e3a) 22%, var(--flowr-sdk-panel-border, #e5d3d6) 78%);
  }
  [data-flowr-context-menu] button:active,
  [data-flowr-instruction-prompt] button:active {
    transform: scale(0.97);
  }
  [data-flowr-instruction-prompt] textarea {
    width: 100%;
    box-sizing: border-box;
    min-height: 72px;
    resize: vertical;
    padding: 8px 10px;
    border: 1px solid var(--flowr-sdk-panel-border, #e5d3d6);
    border-radius: 8px;
    background: var(--flowr-sdk-surface-muted-background, #fffdfd);
    color: var(--flowr-sdk-panel-foreground, #5a1c24);
    font-family: inherit;
    font-size: 13px;
    line-height: 1.45;
  }
  [data-flowr-instruction-prompt] button {
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
  }
  [data-flowr-instruction-prompt] button[data-action="save"] {
    background: var(--flowr-sdk-accent, #8d2e3a);
    border-color: var(--flowr-sdk-accent, #8d2e3a);
    color: var(--flowr-sdk-accent-foreground, #ffffff);
  }
  .wr-input-focus-tooltip {
    /* SDK toggles via style.display; add opacity transition for fade. */
    display: none;
    opacity: 0;
    transition: opacity .18s ease;
  }
`;

const STYLE_TEXT = `${WR_HIGHLIGHT_AND_TOOLTIP_CSS}\n${SDK_OVERLAY_CSS}`;

const ensureStyle = (shadowRoot: ShadowRoot): void => {
  if (shadowRoot.getElementById(STYLE_ID)) {
    return;
  }
  const style = document.createElement("style");
  style.id = STYLE_ID;
  style.textContent = STYLE_TEXT;
  shadowRoot.appendChild(style);
};

const clamp = (value: number, min: number, max: number): number => {
  if (max <= min) return min;
  return Math.min(Math.max(value, min), max);
};

export const createRecorderOverlay = ({
  shadowRoot,
  isCaptureScreenshotsEnabled,
  onRecordHover,
  onRecordContextClick,
  onSaveInstruction,
  onBlurSection,
}: RecorderOverlayOptions): RecorderOverlayHandle => {
  ensureStyle(shadowRoot);

  const getIsCaptureScreenshotsEnabled = (): boolean => {
    if (typeof isCaptureScreenshotsEnabled === "function") {
      return isCaptureScreenshotsEnabled();
    }
    return isCaptureScreenshotsEnabled === true;
  };

  const host = document.createElement("div");
  host.className = "flowr-overlay-host";
  shadowRoot.appendChild(host);

  const highlight = document.createElement("div");
  highlight.className = "wr-highlight";
  host.appendChild(highlight);

  const contextMenu = document.createElement("div");
  contextMenu.className = "wr-context-menu";
  contextMenu.setAttribute("data-flowr-context-menu", "");
  host.appendChild(contextMenu);

  const instructionPrompt = document.createElement("div");
  instructionPrompt.className = "wr-tooltip";
  instructionPrompt.setAttribute("data-flowr-instruction-prompt", "");
  instructionPrompt.style.display = "none";
  host.appendChild(instructionPrompt);

  const inputFocusHint = document.createElement("div");
  inputFocusHint.className = "wr-input-focus-tooltip";
  inputFocusHint.setAttribute("data-flowr-input-focus-hint", "");
  host.appendChild(inputFocusHint);

  let activeTarget: Element | null = null;
  let highlightFrameId: number | null = null;
  let inputFocusAnchor: Element | null = null;
  let inputFocusFrameId: number | null = null;

  const hideTooltip = (): void => {
    instructionPrompt.style.display = "none";
    instructionPrompt.replaceChildren();
  };

  const promptController = createInstructionPromptController({
    documentRoot: shadowRoot,
    panel: host,
    tooltip: instructionPrompt,
    hideTooltip,
  });

  const menuController = createContextMenuController({
    contextMenu,
    isMobile: () => false,
    isCaptureScreenshotsEnabled: getIsCaptureScreenshotsEnabled,
    buildButtons: ({ canBlurSection }) => {
      const btns: Array<{ action: string; label: string }> = [
        { action: "record-right-click", label: "Record right click" },
        { action: "record-hover", label: "Record hover" },
        { action: "add-instruction", label: "Add instruction" },
      ];
      if (canBlurSection) {
        btns.push({ action: "blur-section", label: "Blur section" });
      }
      btns.push({ action: "cancel", label: "Cancel" });
      return btns;
    },
  });

  const stopHighlightTracking = (): void => {
    if (highlightFrameId !== null) {
      window.cancelAnimationFrame(highlightFrameId);
      highlightFrameId = null;
    }
  };

  const applyHighlight = (): void => {
    const rect = activeTarget?.getBoundingClientRect();
    if (!rect) {
      highlight.style.display = "none";
      return;
    }
    highlight.style.display = "block";
    highlight.style.top = `${rect.top}px`;
    highlight.style.left = `${rect.left}px`;
    highlight.style.width = `${Math.max(rect.width, 4)}px`;
    highlight.style.height = `${Math.max(rect.height, 4)}px`;
  };

  const tickHighlight = (): void => {
    applyHighlight();
    if (activeTarget && (menuController.isOpen() || promptController.isPrompting())) {
      highlightFrameId = window.requestAnimationFrame(tickHighlight);
      return;
    }
    stopHighlightTracking();
  };

  const startHighlightTracking = (): void => {
    if (highlightFrameId !== null) return;
    highlightFrameId = window.requestAnimationFrame(tickHighlight);
  };

  const isActive = (): boolean => menuController.isOpen() || promptController.isPrompting();

  const hideAll = (): void => {
    menuController.close();
    hideTooltip();
    activeTarget = null;
    highlight.style.display = "none";
    stopHighlightTracking();
  };

  const openInstructionPromptFromMenu = (target: Element): void => {
    activeTarget = target;
    applyHighlight();
    startHighlightTracking();
    void promptController
      .promptInstruction(target, {
        title: "Add instruction",
        placeholder: "Type instruction...",
      })
      .then((value) => {
        if (value !== null) {
          onSaveInstruction(target, value);
        }
        activeTarget = null;
        highlight.style.display = "none";
        stopHighlightTracking();
      });
  };

  menuController.bindActions({
    onRecordHover: (target) => {
      onRecordHover(target);
      hideAll();
    },
    onRecordRightClick: (target) => {
      onRecordContextClick(target);
      hideAll();
    },
    ...(onBlurSection
      ? {
          onBlurSection: (target: Element) => {
            onBlurSection(target);
            hideAll();
          },
        }
      : {}),
    onAddInstructionToSection: (target) => {
      // Bridge: shared controller routes both `add-instruction` and
      // `add-instruction-to-section` into this handler.
      openInstructionPromptFromMenu(target);
    },
    onCancel: () => {
      hideAll();
    },
  });

  const positionInputFocusHint = (): void => {
    if (!inputFocusAnchor || inputFocusHint.style.display === "none") return;
    const rect = inputFocusAnchor.getBoundingClientRect();
    const hintRect = inputFocusHint.getBoundingClientRect();
    const width = hintRect.width || 200;
    const height = hintRect.height || 36;
    const desiredTop = rect.top + rect.height + 10;
    const fitsBelow = desiredTop + height + 10 < window.innerHeight;
    inputFocusHint.classList.toggle("is-above", !fitsBelow);
    const top = fitsBelow ? desiredTop : Math.max(rect.top - height - 10, 8);
    const left = clamp(rect.left, 8, window.innerWidth - width - 8);
    inputFocusHint.style.top = `${top}px`;
    inputFocusHint.style.left = `${left}px`;
  };

  const startInputFocusTracking = (): void => {
    if (inputFocusFrameId !== null) return;
    const tickHint = (): void => {
      positionInputFocusHint();
      if (inputFocusAnchor && inputFocusHint.style.display === "block") {
        inputFocusFrameId = window.requestAnimationFrame(tickHint);
        return;
      }
      inputFocusFrameId = null;
    };
    inputFocusFrameId = window.requestAnimationFrame(tickHint);
  };

  const hideInputFocusHint = (): void => {
    inputFocusAnchor = null;
    inputFocusHint.style.opacity = "0";
    inputFocusHint.style.display = "none";
    if (inputFocusFrameId !== null) {
      window.cancelAnimationFrame(inputFocusFrameId);
      inputFocusFrameId = null;
    }
  };

  return {
    showContextMenu: ({ target, x, y }) => {
      activeTarget = target;
      hideTooltip();
      menuController.show(x, y, target);
      applyHighlight();
      startHighlightTracking();
    },
    hideAll,
    isActive,
    isPromptingInstruction: () => promptController.isPrompting(),
    showInstructionPrompt: ({ target, title, copy, placeholder, defaultInstruction }) => {
      menuController.close();
      activeTarget = target;
      applyHighlight();
      startHighlightTracking();
      return promptController
        .promptInstruction(target, {
          title,
          copy,
          placeholder,
          defaultInstruction,
        })
        .then((value) => {
          activeTarget = null;
          highlight.style.display = "none";
          stopHighlightTracking();
          return value;
        });
    },
    showInputFocusHint: ({ target, text }) => {
      inputFocusAnchor = target;
      inputFocusHint.textContent = text;
      inputFocusHint.style.display = "block";
      inputFocusHint.style.opacity = "0";
      positionInputFocusHint();
      // Force reflow so the opacity transition runs.
      void inputFocusHint.offsetHeight;
      inputFocusHint.style.opacity = "1";
      startInputFocusTracking();
    },
    hideInputFocusHint,
    destroy: () => {
      hideAll();
      hideInputFocusHint();
      host.remove();
    },
  };
};
