/**
 * @flowr/sdk-ui — recorder panel CSS + style injection.
 *
 * Visual styles mirror the FlowR browser-extension content-script panel
 * (`src/panel.css` `.wr-panel` family) so SDK consumers see the exact
 * same recorder look as the extension. Class names are namespaced to
 * `wr-*` to make the parity obvious — the cream/burgundy palette,
 * pill-shaped step kind/count chips, 8px button radii, and 13px
 * step-card typography all come from the extension stylesheet.
 *
 * Style injection is idempotent and scoped to the recorder panel's
 * owning root (typically a `ShadowRoot` mounted by `mountBubble`),
 * so multiple panel mounts never duplicate the stylesheet.
 */

export const RECORDER_PANEL_STYLE_ID = "flowr-sdk-ui-recorder-panel-style";

export const RECORDER_PANEL_STYLE = `
  .wr-panel {
    --wr-panel-bg: #faf7f7;
    --wr-panel-fg: #5a1c24;
    --wr-panel-accent: #8d2e3a;
    --wr-panel-border: #e5d3d6;
    --wr-panel-scrollbar: rgba(141, 46, 58, 0.25);
    --wr-panel-scrollbar-hover: rgba(141, 46, 58, 0.45);
    box-sizing: border-box;
    background: var(--wr-panel-bg);
    color: var(--wr-panel-fg);
    border: 1px solid var(--wr-panel-border);
    border-radius: 12px;
    padding: 16px;
    font-family: "Segoe UI", system-ui, sans-serif;
    font-size: 13px;
    line-height: 1.4;
    display: flex;
    flex-direction: column;
    gap: 12px;
    width: 100%;
    min-width: 0;
    max-width: min(360px, 100%);
  }
  .wr-panel * { box-sizing: border-box; }
  .wr-brand {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
  }
  .wr-brand-actions {
    margin-left: auto;
    display: inline-flex;
    align-items: center;
  }
  .wr-brand-icon {
    width: 18px;
    height: 18px;
    border-radius: 4px;
    background: var(--wr-panel-accent);
    color: #fff;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.02em;
  }
  .wr-brand h4 {
    margin: 0;
    font-size: 13px;
    font-weight: 700;
    color: var(--wr-panel-fg);
  }
  .wr-title-input {
    width: 100%;
    border-radius: 8px;
    border: 1px solid var(--wr-panel-border);
    background: #fffdfd;
    color: var(--wr-panel-fg);
    padding: 8px;
    font-size: 13px;
    font-family: inherit;
  }
  .wr-field-row {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 120px;
    gap: 8px;
    align-items: end;
  }
  .wr-field-label {
    display: flex;
    flex-direction: column;
    gap: 4px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.02em;
    text-transform: uppercase;
    color: #7b4750;
  }
  .wr-auth-copy {
    font-size: 12px;
    color: var(--wr-panel-fg);
    opacity: 0.76;
  }
  .wr-auth-actions {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 8px;
  }
  .wr-auth-error {
    padding: 8px 10px;
    border-radius: 10px;
    background: #fff0f1;
    border: 1px solid #f2c8cf;
    color: #9f1239;
    font-size: 12px;
  }
  .wr-select-input {
    width: 100%;
    border-radius: 8px;
    border: 1px solid var(--wr-panel-border);
    background: #fffdfd;
    color: var(--wr-panel-fg);
    padding: 8px;
    font-size: 13px;
    font-family: inherit;
  }
  .wr-toggle-field {
    grid-column: 1 / -1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 10px 12px;
    border-radius: 10px;
    border: 1px solid var(--wr-panel-border);
    background: #fffdfd;
    color: var(--wr-panel-fg);
  }
  .wr-toggle-field[data-disabled="true"] {
    opacity: 0.7;
  }
  .wr-toggle-copy {
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .wr-toggle-title {
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.02em;
    text-transform: uppercase;
    color: #7b4750;
  }
  .wr-toggle-hint {
    font-size: 12px;
    font-weight: 400;
    letter-spacing: normal;
    text-transform: none;
    color: var(--wr-panel-fg);
    opacity: 0.76;
  }
  .wr-toggle-checkbox {
    width: 16px;
    height: 16px;
    margin: 0;
    flex-shrink: 0;
    accent-color: var(--wr-panel-accent);
  }
  .wr-actions {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 8px;
  }
  .wr-panel button {
    border: none;
    padding: 8px 10px;
    border-radius: 8px;
    background: #ffffff;
    color: var(--wr-panel-fg);
    cursor: pointer;
    font-family: inherit;
    font-size: 14px;
    font-weight: 600;
    line-height: 1.2;
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }
  .wr-panel button.primary {
    background: var(--wr-panel-accent);
    color: #ffffff;
  }
  .wr-panel button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
  .wr-panel button:active:not(:disabled) {
    transform: scale(0.95);
  }
  .wr-panel button[data-span="full"] {
    grid-column: 1 / -1;
  }
  .wr-panel button.wr-icon-button {
    width: 32px;
    height: 32px;
    padding: 0;
    border: 1px solid var(--wr-panel-border);
    background: #fffdfd;
    color: var(--wr-panel-accent);
  }
  .wr-panel button.wr-icon-button svg {
    width: 16px;
    height: 16px;
  }
  .wr-panel button.wr-icon-button[data-loading="true"] {
    color: transparent;
  }
  .wr-panel button.wr-icon-button[data-loading="true"] svg {
    opacity: 0;
  }
  .wr-status {
    padding: 8px 10px;
    border-radius: 10px;
    background: #f6eded;
    border: 1px solid #e8d7da;
    font-size: 12px;
    color: var(--wr-panel-fg);
  }
  .wr-steps {
    flex: 1;
    min-height: 0;
    max-height: 320px;
    overflow-y: auto;
    border: 1px solid var(--wr-panel-border);
    border-radius: 10px;
    background: #fffdfd;
    padding: 10px 10px 14px;
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  .wr-steps::-webkit-scrollbar { width: 8px; }
  .wr-steps::-webkit-scrollbar-track { background: transparent; }
  .wr-steps::-webkit-scrollbar-thumb {
    background: var(--wr-panel-scrollbar);
    border-radius: 999px;
  }
  .wr-steps::-webkit-scrollbar-thumb:hover {
    background: var(--wr-panel-scrollbar-hover);
  }
  .wr-steps-empty {
    color: var(--wr-panel-fg);
    opacity: 0.7;
    font-size: 12px;
    padding: 6px 2px;
  }
  .wr-step {
    border: 1px solid var(--wr-panel-border);
    border-radius: 8px;
    padding: 8px;
    font-size: 13px;
    background: #ffffff;
    display: flex;
    flex-direction: column;
    gap: 6px;
  }
  .wr-step[data-active="true"] {
    border-left: 3px solid var(--wr-panel-accent);
  }
  .wr-step-meta {
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .wr-step-count,
  .wr-step-kind {
    display: inline-flex;
    align-items: center;
    border-radius: 999px;
    padding: 2px 8px;
    font-size: 10px;
    font-weight: 700;
    line-height: 1.2;
    text-transform: uppercase;
    letter-spacing: 0.02em;
  }
  .wr-step-count {
    background: #f6eded;
    color: var(--wr-panel-fg);
  }
  .wr-step-kind {
    background: #f3e3e6;
    color: var(--wr-panel-accent);
  }
  .wr-step-summary {
    font-size: 12px;
    opacity: 0.7;
    overflow-wrap: anywhere;
    word-break: break-word;
  }
  .wr-step-screenshot-button {
    padding: 0;
    overflow: hidden;
    border: 1px solid var(--wr-panel-border);
    border-radius: 10px;
    background: #fff7f8;
    text-align: left;
  }
  .wr-step-screenshot-button img {
    display: block;
    width: 100%;
    max-height: 164px;
    object-fit: cover;
    background: #f6eded;
  }
  .wr-step-instruction-input {
    width: 100%;
    border-radius: 8px;
    border: 1px solid var(--wr-panel-border);
    background: #fffdfd;
    color: var(--wr-panel-fg);
    padding: 6px 8px;
    font-size: 13px;
    font-family: inherit;
    resize: vertical;
    min-height: 56px;
  }
  .wr-step-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 6px;
  }
  .wr-step-toolbar button {
    background: transparent;
    border: 1px solid var(--wr-panel-border);
    color: var(--wr-panel-fg);
    font-size: 11px;
    font-weight: 600;
    padding: 4px 8px;
    border-radius: 999px;
    cursor: pointer;
  }
  .wr-step-toolbar button[data-flowr-action="step-delete"] {
    color: #b3261e;
    border-color: #ecc4c0;
  }
  .wr-step-toolbar button:hover {
    background: #faf2f3;
  }
  .wr-step-advanced {
    border-top: 1px dashed var(--wr-panel-border);
    padding-top: 8px;
    display: flex;
    flex-direction: column;
    gap: 6px;
    font-size: 12px;
  }
  .wr-step-advanced label {
    display: flex;
    flex-direction: column;
    gap: 4px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: var(--wr-panel-accent);
  }
  .wr-step-advanced select,
  .wr-step-advanced input[type="text"] {
    width: 100%;
    box-sizing: border-box;
    padding: 6px 8px;
    border-radius: 6px;
    border: 1px solid var(--wr-panel-border);
    background: #fffdfd;
    color: var(--wr-panel-fg);
    font-family: inherit;
    font-size: 12px;
    text-transform: none;
    letter-spacing: normal;
  }
  .wr-step-advanced .wr-pick-row {
    display: flex;
    gap: 6px;
    align-items: stretch;
  }
  .wr-step-advanced .wr-pick-row input[type="text"] {
    flex: 1;
  }
  .wr-step-advanced .wr-pick-row button {
    background: transparent;
    border: 1px solid var(--wr-panel-border);
    color: var(--wr-panel-fg);
    font-size: 11px;
    font-weight: 600;
    padding: 4px 10px;
    border-radius: 6px;
    cursor: pointer;
    white-space: nowrap;
  }
  .wr-step-advanced .wr-pick-row button:hover {
    background: #faf2f3;
  }
  .wr-step-advanced .wr-pick-row button[data-flowr-picking="true"] {
    background: var(--wr-panel-accent);
    color: #fff;
    border-color: var(--wr-panel-accent);
  }
  .wr-library-empty {
    color: var(--wr-panel-fg);
    opacity: 0.7;
    font-size: 12px;
    padding: 6px 2px;
  }
  .wr-library {
    flex: 1;
    min-height: 0;
    max-height: 320px;
    overflow-y: auto;
    border: 1px solid var(--wr-panel-border);
    border-radius: 10px;
    background: #fffdfd;
    padding: 10px;
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  .wr-library::-webkit-scrollbar { width: 8px; }
  .wr-library::-webkit-scrollbar-track { background: transparent; }
  .wr-library::-webkit-scrollbar-thumb {
    background: var(--wr-panel-scrollbar);
    border-radius: 999px;
  }
  .wr-library-row {
    border: 1px solid var(--wr-panel-border);
    border-radius: 8px;
    padding: 8px;
    background: #ffffff;
    display: flex;
    flex-direction: column;
    gap: 6px;
  }
  .wr-library-row[data-active="true"] {
    border-left: 3px solid var(--wr-panel-accent);
  }
  .wr-library-title {
    font-size: 13px;
    font-weight: 600;
    color: var(--wr-panel-fg);
    overflow-wrap: anywhere;
  }
  .wr-library-meta {
    font-size: 11px;
    color: var(--wr-panel-fg);
    opacity: 0.7;
  }
  .wr-library-toolbar {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
  }
  .wr-library-toolbar button {
    background: transparent;
    border: 1px solid var(--wr-panel-border);
    color: var(--wr-panel-fg);
    font-size: 11px;
    font-weight: 600;
    padding: 4px 10px;
    border-radius: 999px;
    cursor: pointer;
  }
  .wr-library-toolbar button:hover {
    background: #faf2f3;
  }
  .wr-library-toolbar button[data-flowr-action="library-delete"] {
    color: #b3261e;
    border-color: #ecc4c0;
  }
  .wr-library-toolbar button[data-flowr-action="library-replay"] {
    background: var(--wr-panel-accent);
    color: #fff;
    border-color: var(--wr-panel-accent);
  }
  .wr-screenshot-modal {
    position: fixed;
    inset: 0;
    z-index: 2147483647;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 8px;
    background: rgba(90, 28, 36, 0.46);
  }
  .wr-screenshot-modal-card {
    width: min(1360px, calc(100vw - 16px));
    max-height: calc(100vh - 16px);
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding: 12px;
    border-radius: 16px;
    background: #fffdfd;
    border: 1px solid var(--wr-panel-border);
    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.24);
  }
  .wr-screenshot-modal-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
  }
  .wr-screenshot-modal-header strong {
    font-size: 13px;
    color: var(--wr-panel-fg);
  }
  .wr-screenshot-modal-image {
    display: block;
    width: 100%;
    max-height: calc(100vh - 72px);
    object-fit: contain;
    border-radius: 12px;
    background: #f6eded;
  }
  @media (max-width: 420px) {
    .wr-panel {
      padding: 12px;
      gap: 10px;
      border-radius: 10px;
    }
    .wr-field-row,
    .wr-auth-actions,
    .wr-actions {
      grid-template-columns: 1fr;
    }
    .wr-toggle-field {
      align-items: flex-start;
    }
    .wr-steps,
    .wr-library {
      max-height: min(320px, 42vh);
      padding: 8px;
    }
    .wr-library-toolbar,
    .wr-step-toolbar {
      align-items: stretch;
      flex-direction: column;
    }
    .wr-library-toolbar button,
    .wr-step-toolbar button {
      width: 100%;
    }
  }
`;

/**
 * Inject the recorder panel stylesheet exactly once into the panel
 * root's owning document or shadow root. Calling repeatedly is a no-op.
 */
export const ensureRecorderPanelStyle = (root: HTMLElement): void => {
  const owner = root.getRootNode() as ShadowRoot | Document;
  const existing =
    "getElementById" in owner
      ? (owner as Document | ShadowRoot).getElementById(RECORDER_PANEL_STYLE_ID)
      : null;
  if (existing) {
    return;
  }
  const style = document.createElement("style");
  style.id = RECORDER_PANEL_STYLE_ID;
  style.textContent = RECORDER_PANEL_STYLE;
  // Document does not accept appendChild for arbitrary elements ("Only one
  // element on document allowed"), so when the root lives in the light DOM
  // we inject into <head>. Shadow roots accept appendChild directly.
  if (owner instanceof ShadowRoot) {
    owner.appendChild(style);
  } else if (typeof document !== "undefined" && document.head) {
    document.head.appendChild(style);
  } else {
    root.prepend(style);
  }
};
