/**
 * @flowr/sdk-ui — recorder panel CSS + style injection.
 *
 * Visual styles mirror the FlowR browser-extension content-script panel
 * (`src/panel.css` `.wr-panel` family) so SDK consumers see the exact
 * same recorder look as the extension. Class names are namespaced to
 * `wr-*` to make the parity obvious — the cream/burgundy palette,
 * pill-shaped step kind/count chips, 8px button radii, and 13px
 * step-card typography all come from the extension stylesheet.
 *
 * Style injection is idempotent and scoped to the recorder panel's
 * owning root (typically a `ShadowRoot` mounted by `mountBubble`),
 * so multiple panel mounts never duplicate the stylesheet.
 */

export const RECORDER_PANEL_STYLE_ID = "flowr-sdk-ui-recorder-panel-style";

export const RECORDER_PANEL_STYLE = `
  .wr-panel {
    --wr-panel-bg: var(--flowr-sdk-panel-background, #ffffff);
    --wr-panel-fg: var(--flowr-sdk-panel-foreground, #111827);
    --wr-panel-accent: var(--flowr-sdk-accent, #8d2e3a);
    --wr-panel-accent-fg: var(--flowr-sdk-accent-foreground, #ffffff);
    --wr-panel-border: var(--flowr-sdk-panel-border, #e5e7eb);
    --wr-panel-muted: var(--flowr-sdk-panel-muted, #6b7280);
    --wr-panel-surface: var(--flowr-sdk-surface-muted-background, #f8fafc);
    --wr-panel-raised: var(--flowr-sdk-surface-background, #ffffff);
    --wr-panel-soft: color-mix(in srgb, var(--wr-panel-accent) 7%, var(--wr-panel-raised) 93%);
    --wr-panel-soft-strong: color-mix(in srgb, var(--wr-panel-accent) 12%, var(--wr-panel-raised) 88%);
    --wr-panel-danger: color-mix(in srgb, var(--wr-panel-accent) 82%, black 18%);
    --wr-panel-danger-border: color-mix(in srgb, var(--wr-panel-accent) 28%, var(--wr-panel-border) 72%);
    --wr-panel-overlay-scrim: color-mix(in srgb, var(--flowr-sdk-overlay-background, var(--wr-panel-accent)) 42%, transparent);
    --wr-panel-scrollbar: color-mix(in srgb, var(--wr-panel-accent) 25%, transparent);
    --wr-panel-scrollbar-hover: color-mix(in srgb, var(--wr-panel-accent) 45%, transparent);
    box-sizing: border-box;
    background-color: var(--wr-panel-bg);
    background-image:
      radial-gradient(circle at top left, color-mix(in srgb, var(--wr-panel-accent) 10%, transparent) 0%, transparent 40%),
      linear-gradient(180deg, color-mix(in srgb, var(--wr-panel-raised) 76%, var(--wr-panel-bg) 24%) 0%, color-mix(in srgb, var(--wr-panel-accent) 4%, var(--wr-panel-bg) 96%) 100%);
    color: var(--wr-panel-fg);
    border: 1px solid color-mix(in srgb, var(--wr-panel-accent) 10%, var(--wr-panel-border) 90%);
    border-radius: 22px;
    padding: 18px;
    box-shadow: 0 24px 60px rgba(15, 23, 42, 0.16), inset 0 1px 0 rgba(255, 255, 255, 0.7);
    backdrop-filter: blur(18px);
    -webkit-backdrop-filter: blur(18px);
    font-family: var(--flowr-sdk-font-family, "Avenir Next", "Segoe UI", "Helvetica Neue", sans-serif);
    font-size: 13px;
    line-height: 1.4;
    display: flex;
    flex-direction: column;
    gap: 16px;
    width: 100%;
    min-width: 0;
    max-width: min(392px, 100%);
  }
  .wr-panel * { box-sizing: border-box; }
  .wr-brand {
    display: flex;
    align-items: center;
    gap: 10px;
    width: 100%;
    min-height: 38px;
  }
  .wr-brand-actions {
    margin-left: auto;
    display: inline-flex;
    align-items: center;
  }
  .wr-brand-icon {
    width: 20px;
    height: 20px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
  }
  .wr-brand-icon img {
    width: 20px;
    height: 20px;
    display: block;
    object-fit: contain;
  }
  .wr-brand h4 {
    margin: 0;
    font-size: 15px;
    font-weight: 760;
    letter-spacing: -0.01em;
    color: var(--wr-panel-fg);
  }
  .wr-tabs {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 8px;
    padding: 5px;
    border: 1px solid var(--wr-panel-border);
    border-radius: 16px;
    background-color: var(--wr-panel-surface);
    background-image: linear-gradient(180deg, rgba(255,255,255,.52), rgba(255,255,255,.12));
  }
  .wr-tabs button {
    border: 1px solid transparent;
    border-radius: 12px;
    background: transparent;
    color: var(--wr-panel-muted);
    min-height: 38px;
    font-weight: 650;
  }
  .wr-tabs button[data-active="true"] {
    background-color: var(--wr-panel-raised);
    background-image: linear-gradient(180deg, rgba(255,255,255,.82), rgba(255,255,255,.12));
    border-color: var(--wr-panel-border);
    color: var(--wr-panel-fg);
    box-shadow: 0 12px 28px color-mix(in srgb, var(--wr-panel-accent) 14%, transparent);
  }
  .wr-tabs button:disabled[data-active="true"] {
    opacity: 1;
  }
  .wr-title-input {
    width: 100%;
    border-radius: 14px;
    border: 1px solid var(--wr-panel-border);
    background-color: var(--wr-panel-raised);
    background-image: linear-gradient(180deg, rgba(255,255,255,.64), rgba(255,255,255,.08));
    color: var(--wr-panel-fg);
    padding: 10px 12px;
    font-size: 13px;
    font-family: inherit;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.6);
  }
  .wr-title-input:focus,
  .wr-select-input:focus,
  .wr-library-search-input:focus {
    outline: none;
    border-color: color-mix(in srgb, var(--wr-panel-accent) 72%, var(--wr-panel-border) 28%);
    box-shadow: 0 0 0 3px color-mix(in srgb, var(--wr-panel-accent) 16%, transparent);
  }
  .wr-field-row {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 120px;
    gap: 8px;
    align-items: end;
  }
  .wr-field-label {
    display: flex;
    flex-direction: column;
    gap: 4px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.02em;
    text-transform: uppercase;
    color: var(--wr-panel-muted);
  }
  .wr-auth-copy {
    font-size: 12px;
    color: var(--wr-panel-fg);
    opacity: 0.76;
  }
  .wr-auth-actions {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 8px;
  }
  .wr-auth-error {
    padding: 9px 11px;
    border-radius: 12px;
    background: var(--wr-panel-soft);
    border: 1px solid var(--wr-panel-danger-border);
    color: var(--wr-panel-danger);
    font-size: 12px;
  }
  .wr-select-input {
    width: 100%;
    border-radius: 14px;
    border: 1px solid var(--wr-panel-border);
    background-color: var(--wr-panel-raised);
    background-image: linear-gradient(180deg, rgba(255,255,255,.64), rgba(255,255,255,.08));
    color: var(--wr-panel-fg);
    padding: 10px 12px;
    font-size: 13px;
    font-family: inherit;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.6);
  }
  .wr-toggle-field {
    grid-column: 1 / -1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 10px 12px;
    border-radius: 12px;
    border: 1px solid var(--wr-panel-border);
    background: var(--wr-panel-surface);
    color: var(--wr-panel-fg);
  }
  .wr-toggle-field[data-disabled="true"] {
    opacity: 0.7;
  }
  .wr-toggle-copy {
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .wr-toggle-title {
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.02em;
    text-transform: uppercase;
    color: var(--wr-panel-muted);
  }
  .wr-toggle-hint {
    font-size: 12px;
    font-weight: 400;
    letter-spacing: normal;
    text-transform: none;
    color: var(--wr-panel-fg);
    opacity: 0.76;
  }
  .wr-toggle-checkbox {
    width: 16px;
    height: 16px;
    margin: 0;
    flex-shrink: 0;
    accent-color: var(--wr-panel-accent);
  }
  .wr-actions {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 8px;
  }
  .wr-panel button {
    border: 1px solid var(--wr-panel-border);
    padding: 10px 12px;
    min-height: 40px;
    border-radius: 14px;
    background-color: var(--wr-panel-raised);
    background-image: linear-gradient(180deg, rgba(255,255,255,.78), rgba(255,255,255,.12));
    color: var(--wr-panel-fg);
    cursor: pointer;
    font-family: inherit;
    font-size: 13px;
    font-weight: 650;
    letter-spacing: 0.01em;
    line-height: 1.2;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    transition: transform .16s ease, box-shadow .16s ease, border-color .16s ease, background-color .16s ease;
  }
  .wr-panel button.primary {
    background-color: var(--wr-panel-accent);
    background-image: linear-gradient(180deg, color-mix(in srgb, white 18%, transparent), transparent);
    border-color: var(--wr-panel-accent);
    color: var(--wr-panel-accent-fg);
    box-shadow: 0 14px 28px color-mix(in srgb, var(--wr-panel-accent) 22%, transparent);
  }
  .wr-panel button:not(:disabled):hover {
    border-color: color-mix(in srgb, var(--wr-panel-accent) 24%, var(--wr-panel-border) 76%);
    background-color: var(--wr-panel-soft);
    transform: translateY(-1px);
  }
  .wr-panel button.primary:not(:disabled):hover {
    background-color: color-mix(in srgb, var(--wr-panel-accent) 92%, black 8%);
    border-color: color-mix(in srgb, var(--wr-panel-accent) 92%, black 8%);
  }
  .wr-panel button:focus-visible {
    outline: 2px solid color-mix(in srgb, var(--wr-panel-accent) 70%, white 30%);
    outline-offset: 2px;
  }
  .wr-panel button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
  .wr-panel button:active:not(:disabled) {
    transform: scale(0.98);
  }
  .wr-panel button[data-span="full"] {
    grid-column: 1 / -1;
  }
  .wr-panel button.wr-icon-button {
    width: 36px;
    height: 36px;
    padding: 0;
    border: 1px solid var(--wr-panel-border);
    border-radius: 14px;
    background-color: var(--wr-panel-surface);
    background-image: linear-gradient(180deg, rgba(255,255,255,.72), rgba(255,255,255,.10));
    color: var(--wr-panel-fg);
  }
  .wr-panel button.wr-sign-out-button {
    position: relative;
  }
  .wr-panel button.wr-sign-out-button::after {
    content: attr(title);
    position: absolute;
    top: calc(100% + 8px);
    right: 0;
    z-index: 3;
    padding: 6px 8px;
    border-radius: 10px;
    background: color-mix(in srgb, var(--wr-panel-fg) 92%, black 8%);
    color: var(--wr-panel-bg);
    box-shadow: 0 10px 24px rgba(15, 23, 42, 0.20);
    font-size: 11px;
    font-weight: 700;
    line-height: 1;
    letter-spacing: 0;
    text-transform: none;
    white-space: nowrap;
    opacity: 0;
    visibility: hidden;
    pointer-events: none;
    transform: translateY(-2px);
    transition: opacity .14s ease, transform .14s ease, visibility .14s ease;
  }
  .wr-panel button.wr-sign-out-button:hover::after,
  .wr-panel button.wr-sign-out-button:focus-visible::after {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
  }
  .wr-panel button.wr-sign-out-button:hover:not(:disabled) {
    color: var(--wr-panel-accent);
  }
  .wr-panel button.wr-icon-button svg {
    width: 16px;
    height: 16px;
  }
  .wr-panel button.wr-icon-button[data-loading="true"] {
    color: transparent;
  }
  .wr-panel button.wr-icon-button[data-loading="true"] svg {
    opacity: 0;
  }
  .wr-status {
    padding: 10px 12px;
    border-radius: 16px;
    background-color: var(--wr-panel-surface);
    background-image: linear-gradient(180deg, rgba(255,255,255,.58), rgba(255,255,255,.08));
    border: 1px solid color-mix(in srgb, var(--wr-panel-accent) 18%, var(--wr-panel-border) 82%);
    border-left: 3px solid color-mix(in srgb, var(--wr-panel-accent) 70%, var(--wr-panel-border) 30%);
    font-size: 12px;
    color: var(--wr-panel-fg);
  }

  [data-flowr-panel][data-flowr-recording-active="true"] {
    overflow: hidden;
    display: flex;
    flex-direction: column;
    max-height: min(70vh, calc(100vh - 96px));
  }
  [data-flowr-panel][data-flowr-recording-active="true"] .wr-panel {
    flex: 1;
    min-height: 0;
    overflow: hidden;
  }
  [data-flowr-panel][data-flowr-recording-active="true"] .wr-steps {
    flex: 1 1 auto;
    min-height: 0;
    max-height: none;
    overflow-y: auto;
  }

  .wr-steps {
    flex: 1;
    min-height: 0;
    max-height: 320px;
    overflow-y: auto;
    border: 1px solid var(--wr-panel-border);
    border-radius: 16px;
    background-color: var(--wr-panel-surface);
    background-image: linear-gradient(180deg, rgba(255,255,255,.52), rgba(255,255,255,.10));
    padding: 12px;
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  .wr-steps::-webkit-scrollbar { width: 8px; }
  .wr-steps::-webkit-scrollbar-track { background: transparent; }
  .wr-steps::-webkit-scrollbar-thumb {
    background: var(--wr-panel-scrollbar);
    border-radius: 999px;
  }
  .wr-steps::-webkit-scrollbar-thumb:hover {
    background: var(--wr-panel-scrollbar-hover);
  }
  .wr-steps-empty {
    color: var(--wr-panel-fg);
    opacity: 0.7;
    font-size: 12px;
    padding: 6px 2px;
  }
  .wr-step {
    border: 1px solid var(--wr-panel-border);
    border-radius: 16px;
    padding: 12px;
    font-size: 13px;
    background-color: var(--wr-panel-raised);
    background-image: linear-gradient(180deg, rgba(255,255,255,.84), rgba(255,255,255,.08));
    box-shadow: 0 12px 28px color-mix(in srgb, var(--wr-panel-fg) 8%, transparent);
    display: flex;
    flex-direction: column;
    gap: 6px;
  }
  .wr-step[data-active="true"] {
    border-left: 3px solid var(--wr-panel-accent);
  }
  .wr-step-meta {
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .wr-step-count,
  .wr-step-kind {
    display: inline-flex;
    align-items: center;
    border-radius: 999px;
    padding: 4px 9px;
    font-size: 10px;
    font-weight: 700;
    line-height: 1.2;
    text-transform: uppercase;
    letter-spacing: 0.02em;
  }
  .wr-step-count {
    background: var(--wr-panel-bg);
    border: 1px solid var(--wr-panel-border);
    color: var(--wr-panel-fg);
  }
  .wr-step-kind {
    background: var(--wr-panel-bg);
    border: 1px solid var(--wr-panel-border);
    color: var(--wr-panel-accent);
  }
  .wr-step-summary {
    font-size: 12px;
    opacity: 0.7;
    overflow-wrap: anywhere;
    word-break: break-word;
  }
  .wr-step-screenshot-button {
    padding: 0;
    overflow: hidden;
    border: 1px solid var(--wr-panel-border);
    border-radius: 14px;
    background-color: var(--wr-panel-soft);
    text-align: left;
  }
  .wr-step-screenshot-button img {
    display: block;
    width: 100%;
    max-height: 164px;
    object-fit: cover;
    background: var(--wr-panel-surface);
  }
  .wr-step-instruction-input {
    width: 100%;
    border-radius: 14px;
    border: 1px solid var(--wr-panel-border);
    background-color: var(--wr-panel-raised);
    background-image: linear-gradient(180deg, rgba(255,255,255,.64), rgba(255,255,255,.08));
    color: var(--wr-panel-fg);
    padding: 10px 12px;
    font-size: 13px;
    font-family: inherit;
    resize: vertical;
    min-height: 56px;
  }
  .wr-step-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 6px;
  }
  .wr-step-toolbar button {
    background: transparent;
    border: 1px solid var(--wr-panel-border);
    color: var(--wr-panel-fg);
    font-size: 11px;
    font-weight: 600;
    padding: 4px 8px;
    border-radius: 999px;
    cursor: pointer;
  }
  .wr-step-toolbar button[data-flowr-action="step-delete"] {
    color: var(--wr-panel-danger);
    border-color: var(--wr-panel-danger-border);
  }
  .wr-step-toolbar button:hover {
    background: var(--wr-panel-soft);
  }
  .wr-step-advanced {
    border-top: 1px dashed var(--wr-panel-border);
    padding-top: 8px;
    display: flex;
    flex-direction: column;
    gap: 6px;
    font-size: 12px;
  }
  .wr-step-advanced .wr-step-advanced-section-label {
    font-size: 11px;
    font-weight: 700;
    color: var(--wr-panel-accent);
    text-transform: none;
    letter-spacing: normal;
  }
  .wr-step-advanced label {
    display: flex;
    flex-direction: column;
    gap: 4px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: var(--wr-panel-accent);
  }
  .wr-step-advanced select,
  .wr-step-advanced input[type="text"] {
    width: 100%;
    box-sizing: border-box;
    padding: 6px 8px;
    border-radius: 6px;
    border: 1px solid var(--wr-panel-border);
    background: var(--wr-panel-raised);
    color: var(--wr-panel-fg);
    font-family: inherit;
    font-size: 12px;
    text-transform: none;
    letter-spacing: normal;
  }
  .wr-step-advanced .wr-pick-row {
    display: flex;
    gap: 6px;
    align-items: stretch;
  }
  .wr-step-advanced .wr-pick-row input[type="text"] {
    flex: 1;
  }
  .wr-step-advanced .wr-pick-row button {
    background: transparent;
    border: 1px solid var(--wr-panel-border);
    color: var(--wr-panel-fg);
    font-size: 11px;
    font-weight: 600;
    padding: 4px 10px;
    border-radius: 6px;
    cursor: pointer;
    white-space: nowrap;
  }
  .wr-step-advanced .wr-pick-row button:hover {
    background: var(--wr-panel-soft);
  }
  .wr-step-advanced .wr-pick-row button[data-flowr-picking="true"] {
    background: var(--wr-panel-accent);
    color: var(--wr-panel-accent-fg);
    border-color: var(--wr-panel-accent);
  }
  .wr-step-advanced .wr-step-advanced-hint {
    color: var(--wr-panel-muted);
    font-size: 11px;
    line-height: 1.4;
    text-transform: none;
    letter-spacing: normal;
  }
  .wr-step-advanced .wr-step-navigation-match-mode + .wr-step-advanced-hint {
    padding-top: 4px;
  }
  .wr-step-advanced .wr-step-advanced-skip-section.has-navigation-match-mode {
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid var(--wr-panel-border);
  }
  .wr-library-empty {
    color: var(--wr-panel-fg);
    opacity: 0.7;
    font-size: 12px;
    padding: 6px 2px;
  }
  .wr-library-controls {
    display: flex;
    align-items: end;
    gap: 8px;
  }
  .wr-library-controls .wr-field-label {
    flex: 1;
  }
  .wr-library-controls button[data-flowr-action="library-reload"] {
    border: 1px solid var(--wr-panel-border);
    background: var(--wr-panel-raised);
    color: var(--wr-panel-fg);
    white-space: nowrap;
  }
  .wr-library-search-row {
    display: flex;
    align-items: center;
  }
  .wr-library-loading {
    padding: 10px 12px;
    border-radius: 16px;
    border: 1px solid var(--wr-panel-border);
    background-color: var(--wr-panel-surface);
    background-image: linear-gradient(180deg, rgba(255,255,255,.52), rgba(255,255,255,.08));
    color: var(--wr-panel-muted);
    font-size: 12px;
  }
  .wr-library-search-input {
    flex: 1;
  }
  .wr-library-search-input::-webkit-search-cancel-button {
    -webkit-appearance: none;
    width: 14px;
    height: 14px;
    cursor: pointer;
    border-radius: 999px;
    background:
      linear-gradient(45deg, transparent 42%, var(--wr-panel-accent) 42%, var(--wr-panel-accent) 58%, transparent 58%),
      linear-gradient(-45deg, transparent 42%, var(--wr-panel-accent) 42%, var(--wr-panel-accent) 58%, transparent 58%);
    opacity: 0.85;
  }
  .wr-library-search-input::-webkit-search-cancel-button:hover { opacity: 1; }
  .wr-library {
    flex: 1;
    min-height: 0;
    max-height: 320px;
    overflow-y: auto;
    border: 1px solid var(--wr-panel-border);
    border-radius: 16px;
    background-color: var(--wr-panel-surface);
    background-image: linear-gradient(180deg, rgba(255,255,255,.52), rgba(255,255,255,.08));
    padding: 12px;
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  .wr-library::-webkit-scrollbar { width: 8px; }
  .wr-library::-webkit-scrollbar-track { background: transparent; }
  .wr-library::-webkit-scrollbar-thumb {
    background: var(--wr-panel-scrollbar);
    border-radius: 999px;
  }
  .wr-library-row {
    border: 1px solid var(--wr-panel-border);
    border-radius: 16px;
    padding: 12px;
    background-color: var(--wr-panel-raised);
    background-image: linear-gradient(180deg, rgba(255,255,255,.84), rgba(255,255,255,.08));
    box-shadow: 0 12px 28px color-mix(in srgb, var(--wr-panel-fg) 8%, transparent);
    display: flex;
    flex-direction: column;
    gap: 6px;
  }
  .wr-library-row[data-active="true"] {
    border-left: 3px solid var(--wr-panel-accent);
  }
  .wr-library-title {
    font-size: 13px;
    font-weight: 600;
    color: var(--wr-panel-fg);
    overflow-wrap: anywhere;
  }
  .wr-library-meta {
    font-size: 11px;
    color: var(--wr-panel-fg);
    opacity: 0.7;
  }
  .wr-library-toolbar {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
  }
  .wr-library-toolbar button {
    background: transparent;
    border: 1px solid var(--wr-panel-border);
    color: var(--wr-panel-fg);
    font-size: 11px;
    font-weight: 600;
    padding: 4px 10px;
    border-radius: 999px;
    cursor: pointer;
  }
  .wr-library-toolbar button:hover {
    background: var(--wr-panel-soft);
  }
  .wr-library-toolbar button[data-flowr-action="library-delete"] {
    color: var(--wr-panel-danger);
    border-color: var(--wr-panel-danger-border);
  }
  .wr-library-toolbar button[data-flowr-action="library-replay"] {
    background: var(--wr-panel-raised);
    color: var(--wr-panel-fg);
    border-color: var(--wr-panel-border);
  }
  .wr-screenshot-modal {
    position: fixed;
    inset: 0;
    z-index: 2147483647;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 8px;
    background: var(--wr-panel-overlay-scrim);
  }
  .wr-screenshot-modal-card {
    width: min(1360px, calc(100vw - 16px));
    max-height: calc(100vh - 16px);
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding: 16px;
    border-radius: 24px;
    background: var(--wr-panel-raised);
    border: 1px solid var(--wr-panel-border);
    box-shadow: 0 28px 72px rgba(15, 23, 42, 0.22);
  }
  .wr-screenshot-modal-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
  }
  .wr-screenshot-modal-header strong {
    font-size: 13px;
    color: var(--wr-panel-fg);
  }
  .wr-screenshot-modal-image {
    display: block;
    width: 100%;
    max-height: calc(100vh - 72px);
    object-fit: contain;
    border-radius: 12px;
    background: var(--wr-panel-surface);
  }
  @media (max-width: 420px) {
    .wr-panel {
      padding: 12px;
      gap: 10px;
      border-radius: 18px;
    }
    .wr-field-row,
    .wr-auth-actions,
    .wr-actions {
      grid-template-columns: 1fr;
    }
    .wr-toggle-field {
      align-items: flex-start;
    }
    .wr-steps,
    .wr-library {
      max-height: min(320px, 42vh);
      padding: 8px;
    }
    .wr-library-toolbar,
    .wr-step-toolbar {
      align-items: stretch;
      flex-direction: column;
    }
    .wr-library-toolbar button,
    .wr-step-toolbar button {
      width: 100%;
    }
  }
`;

/**
 * Inject the recorder panel stylesheet exactly once into the panel
 * root's owning document or shadow root. Calling repeatedly is a no-op.
 */
export const ensureRecorderPanelStyle = (root: HTMLElement): void => {
  const owner = root.getRootNode() as ShadowRoot | Document;
  const existing =
    "getElementById" in owner
      ? (owner as Document | ShadowRoot).getElementById(RECORDER_PANEL_STYLE_ID)
      : null;
  if (existing) {
    return;
  }
  const style = document.createElement("style");
  style.id = RECORDER_PANEL_STYLE_ID;
  style.textContent = RECORDER_PANEL_STYLE;
  // Document does not accept appendChild for arbitrary elements ("Only one
  // element on document allowed"), so when the root lives in the light DOM
  // we inject into <head>. Shadow roots accept appendChild directly.
  if (owner instanceof ShadowRoot) {
    owner.appendChild(style);
  } else if (typeof document !== "undefined" && document.head) {
    document.head.appendChild(style);
  } else {
    root.prepend(style);
  }
};
