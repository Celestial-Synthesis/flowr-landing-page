/**
 * @flowr/sdk-ui — recorder panel button factory.
 *
 * Wraps `<button>` creation so every action button in the recorder
 * panel gets:
 *   - the same primary/secondary visual variants,
 *   - a stable `data-flowr-action` attribute (slugified label) for
 *     Playwright assertions and CSS selectors,
 *   - automatic disable + loading-label swap during async actions,
 *   - automatic group-disable so siblings can't be activated while one
 *     button is in flight.
 *
 * Loading labels are looked up by `data-flowr-action`, not by visible
 * label text, so renaming or translating buttons doesn't break the
 * loading copy.
 */

export type RecorderPanelButtonVariant = "primary" | "secondary";

export type RecorderPanelButtonAction = () => void | Promise<unknown>;

export type RecorderPanelButtonOptions = {
  renderIdleContent?: (button: HTMLButtonElement) => void;
};

/** Loading-state label keyed by stable `data-flowr-action` attribute. */
export const RECORDER_PANEL_BUTTON_LOADING_LABELS: Record<string, string> = {
  back: "Loading...",
  delete: "Deleting...",
  discard: "Discarding...",
  open: "Opening...",
  record: "Recording...",
  replay: "Replaying...",
  save: "Saving...",
  "send-code": "Sending...",
  "sign-out": "Signing out...",
  verify: "Verifying...",
};

export const createRecorderPanelButton = (
  label: string,
  action: RecorderPanelButtonAction,
  variant: RecorderPanelButtonVariant = "primary",
  options?: RecorderPanelButtonOptions,
): HTMLButtonElement => {
  const button = document.createElement("button");
  button.type = "button";
  button.textContent = label;
  if (variant === "primary") {
    button.className = "primary";
  }
  button.dataset.variant = variant;
  button.dataset.flowrAction = label.toLowerCase().replace(/\s+/g, "-");

  const applyIdleContent = (): void => {
    button.textContent = label;
    options?.renderIdleContent?.(button);
  };

  applyIdleContent();

  button.addEventListener("click", () => {
    if (button.disabled) return;
    const result = action();
    if (!result || typeof (result as PromiseLike<unknown>).then !== "function") {
      return;
    }

    const group = button.parentElement;
    const buttons = group
      ? Array.from(group.querySelectorAll<HTMLButtonElement>("button"))
      : [button];
    const previousDisabled = new Map(buttons.map((item) => [item, item.disabled]));

    for (const item of buttons) {
      item.disabled = true;
    }

    button.dataset.loading = "true";
    button.setAttribute("aria-busy", "true");
    const actionKey = button.dataset.flowrAction ?? "";
    button.textContent = RECORDER_PANEL_BUTTON_LOADING_LABELS[actionKey] ?? `${label}...`;

    void Promise.resolve(result)
      .catch(() => undefined)
      .finally(() => {
        for (const item of buttons) {
          if (!item.isConnected) continue;
          item.disabled = previousDisabled.get(item) ?? false;
        }
        if (!button.isConnected) return;
        delete button.dataset.loading;
        button.removeAttribute("aria-busy");
        applyIdleContent();
      });
  });
  return button;
};
